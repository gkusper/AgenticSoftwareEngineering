# Author decisions before describing this as complete public replication

## Align the professional dataset and the manuscript

The available source XLSX matches the advertised Zenodo v1 MD5. Its eligible N=200 responses give Q25 = 175/188 = 93.1%, Q33 = 178/200 = 89.0%, and 132 respondents with at least six years of experience. The reviewed manuscript instead reports 92.6%, 88.5%, and conflicting 132/133 experience totals. Several scale/correlation results differ as well. The source must not be silently edited to force a match. Confirm the intended data version, then revise either the archived version identifier or the manuscript consistently.

The original locally available survey contains 230 records. Its previously identified block has 25 answer-identical records with different timestamps. Removing all 25 gives the 205-row public archive; excluding five provenance-ineligible submissions gives 200. The earlier PDF-only interpretation that “one of 25 was retained” is not supported by these actual source files. Correct the manuscript's cleaning account to the verified sequence, or document a different source if that is the intended analysis.

## Confirm scale definitions and models

H19's traditional-engineering and AI-literacy item sets are missing. Add the exact lists to `config/analysis_plan.json`; until then, those two composite tests remain uncomputed. Confirm complete-case scoring, the ordinal treatment of Q16, and the seven generated-artifact definition of verification breadth. Confirm the reconstructed classroom C123–C129 and C055–C058 blocks. The original AI-as-collaborator scale remains out of scope without its item list.

The H14 ordered-logit adjustment set was unspecified. This release supplies a clearly labelled new sensitivity with Q5, Q1 and Q6; it must not be represented as the original model unless confirmed. Recover or document the original complete exploratory search and multiplicity families. BH applied after exploratory selection is not equivalent to preregistered evidence.

## Check an additional classroom discrepancy

The three Table 5 primary results are reproduced at their reported precision, including their unrounded-p Holm values. However, Quality Gate/V&V versus `The final solution worked correctly` gives Spearman rho approximately 0.436, not the 0.371 stated in the text. Check which question was intended; the current program uses the question that directly states correctness and leaves the discrepancy visible.

Baseline-adjusted primary HC3 coefficients are nominally significant before adjustment. When the newly added three-model Holm sensitivity is applied, the p-values are approximately 0.066. Distinguish that new sensitivity from the manuscript's unadjusted sensitivity claims.

## Freeze and publish the classroom analysis input

The exact v3 98-row classroom data were available locally. The public location of that precise release was not verified. Confirm the proposed DOI or deposit the analysis-only columns with a frozen version DOI and checksums. The public GitHub code archive deliberately does not contain respondent rows. The separate local input bundle removes private call signs, timestamps and open-ended text, but public release still requires the authors' data/consent/license review.

## Release metadata

Choose a software license and confirm that it does not purport to relicense the source datasets. Add the actual repository URL and software DOI when available; none has been invented here. Review `CITATION.cff`. Keep the source/target mismatch report visible until all discrepancies are reconciled. Test the download commands from a fresh environment and run the GitHub workflow after uploading the repository.
