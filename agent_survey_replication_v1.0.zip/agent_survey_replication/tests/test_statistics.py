import numpy as np
import pandas as pd
import pytest
from scipy import stats

from replication.statistics import (adjust, composite, cronbach_alpha, friedman, group_test,
    independent_groups, odds_ratio, partial_spearman, regression, signed_rank, spearman, wilson)


def test_wilson_paper_example():
    lo, hi = wilson(155, 177)
    assert lo == pytest.approx(0.8190, abs=0.0001)
    assert hi == pytest.approx(0.9164, abs=0.0001)


def test_wilson_empty_and_invalid():
    assert np.isnan(wilson(0, 0)[0])
    with pytest.raises(ValueError):
        wilson(3, 2)


def test_holm_uses_unrounded_values():
    np.testing.assert_allclose(adjust([0.0064, 0.0118, 0.0100], "holm"), [0.0192, 0.0200, 0.0200])


def test_bh_preserves_missing_planned_slots():
    out = adjust([0.01, np.nan, 0.03], "fdr_bh")
    np.testing.assert_allclose(out, [0.03, np.nan, 0.045], equal_nan=True)
    assert adjust([0.12, 0.01, 0.03], "fdr_bh")[0] >= 0.12


def test_signed_rank_ties_zeros():
    r = signed_rank([5, 4, 3, 2, 1, np.nan], midpoint=3)
    assert (r["n"], r["n_zero"], r["n_nonzero"]) == (5, 1, 4)
    assert r["rank_biserial"] == 0
    assert r["p"] == 1 and r["sign_p"] == 1


def test_signed_rank_all_neutral_and_empty():
    assert signed_rank([3, 3, 3], 3)["status"] == "all_zero_differences"
    assert signed_rank([3, 3, 3], 3)["p"] == 1
    assert np.isnan(signed_rank([])["p"])


def test_signed_rank_positive_direction():
    r = signed_rank([1, 2, 3, 4, 5])
    assert r["rank_biserial"] == 1
    assert r["sign_p"] == pytest.approx(0.0625)


def test_alpha_complete_cases():
    frame = pd.DataFrame({"x": [1, 2, 3, np.nan], "y": [1, 2, 3, 4]})
    r = cronbach_alpha(frame)
    assert r["n"] == 3
    assert r["alpha"] == pytest.approx(1)
    assert composite(frame, ["x", "y"], 2).isna().sum() == 1


def test_friedman_and_kendall_w():
    frame = pd.DataFrame([[1, 2, 3], [1, 3, 2], [2, 2, 3], [1, 2, 3]])
    r = friedman(frame)
    assert r["statistic"] == pytest.approx(stats.friedmanchisquare(*frame.to_numpy().T).statistic)
    assert r["kendall_w"] == pytest.approx(r["statistic"] / (4 * 2))


def test_spearman_pairwise_complete():
    r = spearman([1, 2, 3, np.nan], [4, 6, 9, 20])
    assert r["n"] == 3 and r["rho"] == pytest.approx(1)
    assert np.isnan(spearman([1, 1, 1], [2, 3, 4])["rho"])


def test_welch_cohen_d_and_reversal():
    a, b = [1, 2, 5, 7, 8], [1, 2, 2, 3]
    r, reversed_r = independent_groups(a, b), independent_groups(b, a)
    assert r["p"] == pytest.approx(stats.ttest_ind(a, b, equal_var=False).pvalue)
    assert r["cohen_d"] == pytest.approx(-reversed_r["cohen_d"])
    assert r["difference_ci_low"] < r["difference"] < r["difference_ci_high"]


def test_odds_ratio_and_zero_cell_correction():
    r = odds_ratio(45, 58, 20, 68)
    assert r["or"] == pytest.approx(45 * 68 / (58 * 20))
    assert r["cell_correction"] == 0
    assert odds_ratio(0, 5, 4, 6)["cell_correction"] == 0.5


def test_identical_group_values():
    assert group_test([[3, 3], [3, 3]])["p"] == 1


def test_partial_rank_residuals():
    rng = np.random.default_rng(12)
    z = rng.normal(size=100)
    x = z + rng.normal(size=100)
    y = 0.7 * x + z + rng.normal(size=100)
    data = pd.DataFrame({"x": x, "y": y, "z": z})
    r = partial_spearman(data, "x", "y", ["z"])
    assert r["status"] == "ok" and r["rho"] > 0.3 and r["n"] == 100


def test_regression_complete_case_and_collinearity():
    rng = np.random.default_rng(2)
    d = pd.DataFrame({"x": rng.normal(size=100), "z": rng.normal(size=100)})
    d["y"] = 1 + 2 * d.x + rng.normal(size=100)
    d.loc[0, "z"] = np.nan
    r = regression(d, "y", "x", ["z"])
    assert r["n"] == 99 and r["status"] == "ok" and r["coefficient"] > 1
    d["z"] = d.x
    assert regression(d, "y", "x", ["z"])["status"] == "rank_deficient_design"


def test_ordinal_logit_has_no_intercept():
    rng = np.random.default_rng(72)
    x = rng.normal(size=150)
    z = rng.normal(size=150)
    y = np.digitize(x + rng.logistic(size=150), [-1.5, -0.5, 0.5, 1.5]) + 1
    r = regression(pd.DataFrame({"y": y, "x": x, "z": z}), "y", "x", ["z"], ordinal=True)
    assert r["status"] == "ok" and r["coefficient"] > 0
