import csv
import json

import numpy as np
import pandas as pd
import pytest

from replication.io import (DataError, clean_survey, encode_ordinal, json_safe, load_csv,
                           numeric_items, remap_columns, signature)
from replication.classroom import clean_counts
from replication.survey import parse_multiple


def test_multiselect_internal_commas():
    labels = ["General cost reduction unrelated to AI", "Lower demand, revenue pressure, or market conditions", "Other"]
    text = "General cost reduction unrelated to AI, Lower demand, revenue pressure, or market conditions"
    assert parse_multiple(text, labels) == set(labels[:2])
    with pytest.raises(DataError):
        parse_multiple("Unrecognized option", labels)


def test_csv_escaped_quotes_unicode_and_embedded_newlines(tmp_path):
    path = tmp_path / "sample.csv"
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([" Q1.  Item ", "Q2. Item"])
        writer.writerow(['An answer with "quotes", and commas', "Árvíztűrő\ntükörfúrógép"])
    d = load_csv(path)
    assert d.columns[0] == "Q1. Item"
    assert d.iloc[0, 0] == 'An answer with "quotes", and commas'
    assert len(d) == 1


def test_unknown_ordinal_label_fails():
    d = pd.DataFrame({"Q1": ["Agree", "Agre"]})
    with pytest.raises(DataError):
        encode_ordinal(d, {"Q1": {"mapping": {"Agree": 4}}}, [""])


def test_missing_neutral_and_zero_are_distinct():
    d = pd.DataFrame({"Q1": ["Neutral", "N/A", "", "Never"]})
    out = encode_ordinal(d, {"Q1": {"mapping": {"Neutral": 3, "Never": 0}}}, ["N/A", ""])
    assert out.Q1.tolist()[0] == 3 and out.Q1.iloc[3] == 0
    assert out.Q1.isna().sum() == 2


def test_header_matching_does_not_depend_on_column_order():
    fields = {"Q1": {"header": "Question one"}, "Q2": {"header": "Question two"}}
    d = pd.DataFrame({"Question two": ["b"], "Question one": ["a"]})
    assert remap_columns(d, fields).iloc[0].tolist() == ["a", "b"]


def test_documented_duplicate_block_not_generic_deduplication():
    data = pd.DataFrame({"Q1": ["X", "X", "Y", "Z"], "Q39": ["human", "human", "human", "AI"]})
    archived = data.iloc[2:]
    plan = {"documented_excluded_answer_block": {"sha256": signature(["X", "human"]), "expected_count": 2},
            "archived_semantic_sha256": signature(archived.values.tolist()),
            "eligible_provenance": "human", "expected_included_n": 1}
    out, audit, exclusions = clean_survey(data, plan)
    assert out.Q1.tolist() == ["Y"]
    assert audit["documented_block_removed"] == 2 and audit["provenance_excluded"] == 1
    assert len(exclusions) == 3
    with pytest.raises(DataError):
        clean_survey(data.iloc[1:], plan)


def test_cr_counts_do_not_remove_whole_rows():
    values = pd.Series([0, 8, 9, -1, 1.5, np.nan])
    cleaned = clean_counts(values, 8)
    assert len(cleaned) == 6 and cleaned.notna().sum() == 2
    assert cleaned.iloc[0] == 0 and cleaned.iloc[1] == 8


def test_numeric_missing_grade_is_not_imputed():
    result = numeric_items(pd.DataFrame({"grade": ["5", "Prefer not to answer", ""]}),
                           ["grade"], ["Prefer not to answer", ""])
    assert result.grade.notna().sum() == 1
    assert result.grade.iloc[0] == 5


def test_json_has_null_not_nan_and_preserves_bool():
    text = json.dumps(json_safe({"value": np.nan, "ok": True, "n": np.int64(3)}), allow_nan=False)
    assert json.loads(text) == {"value": None, "ok": True, "n": 3}
