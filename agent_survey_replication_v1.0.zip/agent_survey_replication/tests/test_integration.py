import os
from pathlib import Path

import pandas as pd
import pytest

from analysis_pipeline import main


def test_missing_input_is_error_and_leaves_no_partial_results(tmp_path):
    out = tmp_path / "result"
    assert main(["--survey", str(tmp_path / "missing.csv"), "--out", str(out)]) == 1
    assert not out.exists()


def test_existing_output_is_never_overwritten(tmp_path):
    out = tmp_path / "result"
    out.mkdir()
    sentinel = out / "keep.txt"
    sentinel.write_text("keep")
    with pytest.raises(SystemExit):
        main(["--survey", "missing.csv", "--out", str(out)])
    assert sentinel.read_text() == "keep"


def test_real_data_regression_when_supplied(tmp_path):
    survey = os.environ.get("REPLICATION_SURVEY_CSV")
    classroom = os.environ.get("REPLICATION_CLASSROOM_CSV")
    if not survey or not classroom:
        pytest.skip("Real data are optional locally and are not bundled into public CI.")
    out = tmp_path / "results"
    assert main(["--survey", survey, "--classroom", classroom, "--no-figures", "--out", str(out)]) == 0
    items = pd.read_csv(out / "survey/item_descriptives.csv").set_index("item")
    assert items.loc["Q25", "count"] == 175
    assert items.loc["Q33", "count"] == 178
    groups = pd.read_csv(out / "classroom/primary_outcomes.csv").set_index("outcome")
    assert groups.loc["completed_per_prompt", "n_notebook"] == 58
    assert groups.loc["quality_gate", "mean_notebook"] == pytest.approx(4.145238095238095)
    assert groups.loc["failed_tests", "p_holm"] == pytest.approx(0.0200882323462169)
    differences = pd.read_csv(out / "manuscript_comparison.csv")
    assert (differences.status == "differs").any()
