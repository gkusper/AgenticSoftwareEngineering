import hashlib
import io

import pytest

from scripts import download_data


def test_verified_download_and_existing_file(tmp_path, monkeypatch):
    payload = b"a,b\n1,2\n"
    digest = hashlib.md5(payload).hexdigest()
    monkeypatch.setattr(download_data, "request", lambda url: io.BytesIO(payload))
    target = tmp_path / "data.csv"
    download_data.fetch("https://example.invalid/data.csv", target, digest)
    assert target.read_bytes() == payload
    download_data.fetch("https://example.invalid/data.csv", target, digest)
    assert len(list(tmp_path.iterdir())) == 1


def test_checksum_failure_leaves_no_input(tmp_path, monkeypatch):
    monkeypatch.setattr(download_data, "request", lambda url: io.BytesIO(b"<html>error</html>"))
    with pytest.raises(ValueError):
        download_data.fetch("https://example.invalid/data.csv", tmp_path / "data.csv", "0" * 32)
    assert not list(tmp_path.iterdir())


def test_existing_different_input_is_preserved(tmp_path):
    path = tmp_path / "data.csv"
    path.write_bytes(b"original")
    with pytest.raises(ValueError):
        download_data.fetch("https://example.invalid/data.csv", path, "0" * 32)
    assert path.read_bytes() == b"original"
