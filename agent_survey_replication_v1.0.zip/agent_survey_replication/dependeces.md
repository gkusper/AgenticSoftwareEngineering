# Dependencies

The complete dependency, input-data and download instructions are in [dependencies.md](dependencies.md).

This filename is retained to match the originally requested `dependeces.md` name. There is only one maintained specification.
