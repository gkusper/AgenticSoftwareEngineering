from __future__ import annotations

import warnings
from typing import Any, Sequence

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
import statsmodels.api as sm
from statsmodels.miscmodels.ordinal_model import OrderedModel


def valid(values: Sequence[float]) -> np.ndarray:
    a = np.asarray(values, dtype=float)
    return a[np.isfinite(a)]


def wilson(successes: int, n: int, confidence: float = 0.95) -> tuple[float, float]:
    if n < 0 or successes < 0 or successes > n:
        raise ValueError("Wilson interval requires 0 <= successes <= n.")
    if n == 0:
        return np.nan, np.nan
    z = stats.norm.ppf((1 + confidence) / 2)
    p = successes / n
    denominator = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denominator
    radius = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denominator
    return float(center - radius), float(center + radius)


def proportion(values: Sequence[float], threshold: float = 4) -> dict[str, Any]:
    a = valid(values)
    n, count = len(a), int(np.sum(a >= threshold))
    lo, hi = wilson(count, n)
    return {"n": n, "count": count, "proportion": count / n if n else np.nan,
            "ci_low": lo, "ci_high": hi,
            "median": float(np.median(a)) if n else np.nan}


def signed_rank(values: Sequence[float], midpoint: float = 0,
                settings: dict[str, Any] | None = None) -> dict[str, Any]:
    a = valid(values) - midpoint
    d = a[a != 0]
    result: dict[str, Any] = {"n": len(a), "n_nonzero": len(d), "n_zero": len(a) - len(d)}
    if not len(a):
        return result | {"statistic": np.nan, "p": np.nan, "rank_biserial": np.nan,
                         "sign_p": np.nan, "status": "no_valid_observations"}
    if not len(d):
        return result | {"statistic": 0.0, "p": 1.0, "rank_biserial": 0.0,
                         "sign_p": 1.0, "status": "all_zero_differences"}
    options = settings or {"zero_method": "wilcox", "correction": False, "method": "approx"}
    if options.get("zero_method") != "wilcox":
        raise ValueError("This implementation requires zero_method=wilcox for its effect size convention.")
    test = stats.wilcoxon(a, alternative="two-sided", **options)
    ranks = stats.rankdata(abs(d))
    effect = (ranks[d > 0].sum() - ranks[d < 0].sum()) / ranks.sum()
    sign_p = stats.binomtest(int(np.sum(d > 0)), len(d), p=0.5).pvalue
    return result | {"statistic": float(test.statistic), "p": float(test.pvalue),
                     "rank_biserial": float(effect), "sign_p": float(sign_p), "status": "ok"}


def adjust(values: Sequence[float], method: str) -> np.ndarray:
    a = np.asarray(values, dtype=float)
    if np.any(np.isfinite(a) & ((a < 0) | (a > 1))):
        raise ValueError("A p-value is outside [0, 1].")
    if not len(a):
        return a.copy()
    missing = ~np.isfinite(a)
    # Undefined planned tests retain a slot without being reported as observed p=1.
    out = multipletests(np.where(missing, 1.0, a), method=method)[1]
    out[missing] = np.nan
    return out


def spearman(x: Sequence[float], y: Sequence[float]) -> dict[str, Any]:
    a, b = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    mask = np.isfinite(a) & np.isfinite(b)
    a, b = a[mask], b[mask]
    n = len(a)
    if n < 3 or np.unique(a).size < 2 or np.unique(b).size < 2:
        return {"n": n, "rho": np.nan, "p": np.nan, "status": "insufficient_variation"}
    r = stats.spearmanr(a, b, alternative="two-sided")
    return {"n": n, "rho": float(r.statistic), "p": float(r.pvalue), "status": "ok"}


def partial_spearman(frame: pd.DataFrame, x: str, y: str, controls: list[str]) -> dict[str, Any]:
    d = frame[[x, y] + controls].replace([np.inf, -np.inf], np.nan).dropna()
    n = len(d)
    if n <= len(controls) + 3:
        return {"n": n, "rho": np.nan, "p": np.nan, "status": "insufficient_observations"}
    ranked = d.rank(method="average")
    design = np.column_stack([np.ones(n), ranked[controls].to_numpy()])
    rank = np.linalg.matrix_rank(design)
    if rank != design.shape[1]:
        return {"n": n, "rho": np.nan, "p": np.nan, "status": "rank_deficient_controls"}
    residuals = []
    for key in [x, y]:
        a = ranked[key].to_numpy()
        residuals.append(a - design @ np.linalg.lstsq(design, a, rcond=None)[0])
    if any(np.std(a) < 1e-12 for a in residuals):
        return {"n": n, "rho": np.nan, "p": np.nan, "status": "constant_residuals"}
    rho = float(np.corrcoef(*residuals)[0, 1])
    df = n - rank - 1
    t = rho * np.sqrt(df / max(1 - rho * rho, np.finfo(float).eps))
    return {"n": n, "rho": rho, "p": float(2 * stats.t.sf(abs(t), df)),
            "df": df, "status": "ok", "p_method": "approximate_t_on_rank_residuals"}


def cronbach_alpha(frame: pd.DataFrame) -> dict[str, Any]:
    d = frame.replace([np.inf, -np.inf], np.nan).dropna()
    n, k = d.shape
    if n < 2 or k < 2:
        return {"n": n, "k": k, "alpha": np.nan, "status": "insufficient_observations"}
    total_variance = d.sum(axis=1).var(ddof=1)
    if total_variance <= 0:
        return {"n": n, "k": k, "alpha": np.nan, "status": "zero_total_variance"}
    a = k / (k - 1) * (1 - d.var(ddof=1).sum() / total_variance)
    return {"n": n, "k": k, "alpha": float(a), "status": "ok"}


def composite(frame: pd.DataFrame, items: list[str], minimum_items: int) -> pd.Series:
    if not items or not 1 <= minimum_items <= len(items) or len(set(items)) != len(items):
        raise ValueError("A composite requires unique items and a valid minimum_items value.")
    d = frame[items]
    return d.mean(axis=1).where(d.notna().sum(axis=1) >= minimum_items)


def friedman(frame: pd.DataFrame) -> dict[str, Any]:
    d = frame.dropna()
    n, k = d.shape
    if n < 2 or k < 3 or np.all(np.ptp(d.to_numpy(), axis=1) == 0):
        return {"n": n, "k": k, "statistic": np.nan, "p": np.nan,
                "kendall_w": np.nan, "status": "insufficient_variation"}
    t = stats.friedmanchisquare(*(d[c].to_numpy() for c in d))
    return {"n": n, "k": k, "df": k - 1, "statistic": float(t.statistic),
            "p": float(t.pvalue), "kendall_w": float(t.statistic / (n * (k - 1))),
            "status": "ok"}


def group_test(groups: list[Sequence[float]]) -> dict[str, Any]:
    groups = [valid(a) for a in groups]
    if any(len(a) < 1 for a in groups):
        return {"statistic": np.nan, "p": np.nan, "status": "empty_group"}
    if np.unique(np.concatenate(groups)).size < 2:
        return {"statistic": 0.0, "p": 1.0, "status": "all_values_identical"}
    if len(groups) == 2:
        t = stats.mannwhitneyu(*groups, alternative="two-sided", method="asymptotic",
                              use_continuity=True)
    elif len(groups) > 2:
        t = stats.kruskal(*groups)
    else:
        raise ValueError("At least two groups are required.")
    return {"statistic": float(t.statistic), "p": float(t.pvalue), "status": "ok"}


def independent_groups(x: Sequence[float], y: Sequence[float]) -> dict[str, Any]:
    a, b = valid(x), valid(y)
    nx, ny = len(a), len(b)
    if min(nx, ny) < 2:
        return {"n_notebook": nx, "n_unstructured": ny, "p": np.nan,
                "status": "insufficient_observations"}
    mx, my = a.mean(), b.mean()
    vx, vy = a.var(ddof=1), b.var(ddof=1)
    se2 = vx / nx + vy / ny
    pooled = ((nx - 1) * vx + (ny - 1) * vy) / (nx + ny - 2)
    if se2 <= 0:
        return {"n_notebook": nx, "n_unstructured": ny, "p": np.nan,
                "status": "zero_within_group_variance"}
    df = se2**2 / ((vx / nx)**2 / (nx - 1) + (vy / ny)**2 / (ny - 1))
    t = (mx - my) / np.sqrt(se2)
    p = 2 * stats.t.sf(abs(t), df)
    half = stats.t.ppf(0.975, df) * np.sqrt(se2)
    mw = group_test([a, b])
    d = (mx - my) / np.sqrt(pooled) if pooled > 0 else np.nan
    return {"n_notebook": nx, "n_unstructured": ny,
            "mean_notebook": float(mx), "sd_notebook": float(np.sqrt(vx)),
            "mean_unstructured": float(my), "sd_unstructured": float(np.sqrt(vy)),
            "difference": float(mx - my), "difference_ci_low": float(mx - my - half),
            "difference_ci_high": float(mx - my + half), "welch_t": float(t),
            "welch_df": float(df), "p": float(p), "cohen_d": float(d),
            "mann_whitney_u": mw["statistic"], "mann_whitney_p": mw["p"], "status": "ok"}


def odds_ratio(a: int, b: int, c: int, d: int) -> dict[str, Any]:
    cells = np.asarray([a, b, c, d], dtype=float)
    if np.any(cells < 0) or np.any(cells != np.floor(cells)):
        raise ValueError("Contingency counts must be non-negative integers.")
    if (a + b) == 0 or (c + d) == 0:
        return {"or": np.nan, "ci_low": np.nan, "ci_high": np.nan, "status": "empty_group"}
    correction = 0.5 if np.any(cells == 0) else 0.0
    aa, bb, cc, dd = cells + correction
    odds = aa * dd / (bb * cc)
    se = np.sqrt(np.sum(1 / (cells + correction)))
    z = stats.norm.ppf(0.975)
    lo, hi = np.exp(np.log(odds) + np.array([-1, 1]) * z * se)
    fisher_p = stats.fisher_exact([[a, b], [c, d]], alternative="two-sided").pvalue
    return {"or": float(odds), "ci_low": float(lo), "ci_high": float(hi),
            "fisher_p": float(fisher_p), "cell_correction": correction, "status": "ok"}


def regression(frame: pd.DataFrame, outcome: str, predictor: str, controls: list[str],
               ordinal: bool = False) -> dict[str, Any]:
    d = frame[[outcome, predictor] + controls].replace([np.inf, -np.inf], np.nan).dropna()
    n = len(d)
    result: dict[str, Any] = {"outcome": outcome, "predictor": predictor, "n": n,
                              "controls": ";".join(controls), "p": np.nan}
    if n <= len(controls) + 4 or d[outcome].nunique() < 2:
        return result | {"status": "insufficient_observations"}
    x = d[[predictor] + controls].astype(float)
    design = np.column_stack([np.ones(n), x])
    if np.linalg.matrix_rank(design) != design.shape[1]:
        return result | {"status": "rank_deficient_design"}
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        if ordinal:
            fitted = OrderedModel(d[outcome].astype(float), x, distr="logit").fit(
                method="bfgs", disp=False, maxiter=1000)
            converged = bool(fitted.mle_retvals.get("converged", False))
        else:
            fitted = sm.OLS(d[outcome].astype(float), sm.add_constant(x)).fit(cov_type="HC3")
            converged = True
    lo, hi = fitted.conf_int().loc[predictor]
    return result | {"coefficient": float(fitted.params[predictor]),
                     "se": float(fitted.bse[predictor]), "p": float(fitted.pvalues[predictor]),
                     "ci_low": float(lo), "ci_high": float(hi),
                     "model": "ordered_logit" if ordinal else "OLS_HC3",
                     "status": "ok" if converged else "not_converged",
                     "warnings": " | ".join(str(w.message) for w in caught)}
