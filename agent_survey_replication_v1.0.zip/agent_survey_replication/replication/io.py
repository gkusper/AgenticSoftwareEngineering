from __future__ import annotations

import csv
import hashlib
import json
import re
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


class DataError(ValueError):
    pass


def normalize(value: Any) -> str:
    if value is None or (not isinstance(value, str) and pd.isna(value)):
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def signature(values: Any) -> str:
    text = json.dumps(values, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_csv(path: Path) -> pd.DataFrame:
    if path.suffix.lower() != ".csv":
        raise DataError("Use the archived UTF-8 CSV, not an XLSX/ODS workbook. See dependencies.md.")
    try:
        with path.open(encoding="utf-8-sig", newline="") as stream:
            sample = stream.read(20000)
            stream.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
            except csv.Error:
                dialect = csv.excel
            rows = list(csv.reader(stream, delimiter=dialect.delimiter, quotechar='"', doublequote=True))
    except UnicodeError as exc:
        raise DataError("The input must be UTF-8 or UTF-8 with BOM.") from exc
    if len(rows) < 2:
        raise DataError("The CSV has no data records.")
    header = [normalize(c) for c in rows[0]]
    if len(set(header)) != len(header):
        raise DataError("CSV headers are duplicated after whitespace normalization.")
    malformed = [i + 2 for i, row in enumerate(rows[1:]) if len(row) != len(header)]
    if malformed:
        raise DataError(f"Inconsistent CSV field counts at record numbers {malformed[:10]}.")
    frame = pd.DataFrame(rows[1:], columns=header).map(normalize)
    if frame.eq("").all(axis=1).any():
        raise DataError("Blank records must be resolved explicitly before analysis.")
    return frame


def remap_columns(frame: pd.DataFrame, fields: dict[str, Any], required: list[str] | None = None) -> pd.DataFrame:
    wanted = list(fields) if required is None else required
    missing = [fields[key]["header"] for key in wanted if fields[key]["header"] not in frame]
    if missing:
        raise DataError("Missing required columns: " + " | ".join(missing[:8]))
    present = {fields[key]["header"]: key for key in wanted}
    return frame[list(present)].rename(columns=present)


def encode_ordinal(frame: pd.DataFrame, fields: dict[str, Any], missing_labels: list[str]) -> pd.DataFrame:
    numeric = pd.DataFrame(index=frame.index)
    for key, definition in fields.items():
        if "mapping" not in definition:
            continue
        mapping = definition["mapping"]
        unknown = set(frame[key]) - set(mapping) - set(missing_labels)
        if unknown:
            raise DataError(f"Unrecognized response labels in {key}: {sorted(unknown)}")
        numeric[key] = frame[key].map(mapping).astype(float)
    return numeric


def numeric_items(frame: pd.DataFrame, keys: list[str], missing_labels: list[str]) -> pd.DataFrame:
    columns = {}
    for key in keys:
        s = frame[key].replace({x: np.nan for x in missing_labels})
        converted = pd.to_numeric(s, errors="coerce")
        bad = s.notna() & converted.isna()
        if bad.any():
            raise DataError(f"Unexpected non-numeric values in {key}: {sorted(set(s[bad]))}")
        if np.isinf(converted).any():
            raise DataError(f"Infinite values in {key}.")
        columns[key] = converted.astype(float)
    return pd.DataFrame(columns, index=frame.index)


def clean_survey(frame: pd.DataFrame, plan: dict[str, Any], allow_change: bool = False) -> tuple[pd.DataFrame, dict, pd.DataFrame]:
    raw_n = len(frame)
    hashes = frame.apply(lambda row: signature(row.tolist()), axis=1)
    block = hashes.eq(plan["documented_excluded_answer_block"]["sha256"])
    count = int(block.sum())
    expected = plan["documented_excluded_answer_block"]["expected_count"]
    if count not in (0, expected):
        raise DataError(f"Known excluded answer block has {count} rows, expected either 0 or {expected}.")
    decisions = []
    for idx in frame.index[block]:
        decisions.append({"csv_record": int(idx) + 2, "stage": "documented_duplicate_block",
                          "reason": "member_of_previously_identified_25_record_block"})
    unique = frame.loc[~block].copy()
    actual_signature = signature(unique.values.tolist())
    same_snapshot = actual_signature == plan["archived_semantic_sha256"]
    if not same_snapshot and not allow_change:
        raise DataError("The questionnaire responses do not match the frozen 205-row archive. "
                        "Use the documented version, or --allow-data-change to analyse a different snapshot explicitly.")
    eligible = unique["Q39"].eq(plan["eligible_provenance"])
    for idx in unique.index[~eligible]:
        decisions.append({"csv_record": int(idx) + 2, "stage": "provenance", "reason": unique.at[idx, "Q39"]})
    cleaned = unique.loc[eligible].copy()
    if not len(cleaned):
        raise DataError("No eligible human responses remain.")
    if len(cleaned) != plan["expected_included_n"] and not allow_change:
        raise DataError(f"Expected {plan['expected_included_n']} eligible responses, found {len(cleaned)}.")
    audit = {"raw_records": raw_n, "documented_block_removed": count,
             "after_documented_block": len(unique), "provenance_excluded": int((~eligible).sum()),
             "included": len(cleaned), "archived_snapshot_match": same_snapshot,
             "remaining_answer_duplicate_rows": int(unique.duplicated(keep=False).sum()),
             "semantic_sha256": actual_signature,
             "provenance_exclusions": unique.loc[~eligible, "Q39"].value_counts().to_dict()}
    return cleaned, audit, pd.DataFrame(decisions, columns=["csv_record", "stage", "reason"])


def json_safe(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [json_safe(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return json_safe(obj.tolist())
    if isinstance(obj, (float, np.floating)):
        return float(obj) if np.isfinite(obj) else None
    if isinstance(obj, (bool, np.bool_)):
        return bool(obj)
    if isinstance(obj, (int, np.integer)):
        return int(obj)
    return obj


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(json_safe(value), indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")


def save_table(folder: Path, name: str, rows: pd.DataFrame | list[dict]) -> pd.DataFrame:
    table = rows if isinstance(rows, pd.DataFrame) else pd.DataFrame(rows)
    table.to_csv(folder / f"{name}.csv", index=False, encoding="utf-8", float_format="%.15g", lineterminator="\n")
    return table
