from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def horizontal_rates(frame: pd.DataFrame, labels: list[str], output: Path, title: str,
                     xlabel: str = "Share of valid responses (%)") -> None:
    if len(frame) == 0:
        return
    fig, ax = plt.subplots(figsize=(10, max(4, 0.43 * len(frame) + 1.5)))
    values = frame.proportion.to_numpy() * 100
    positions = np.arange(len(frame))
    ax.barh(positions, values)
    ax.set_yticks(positions, labels=labels)
    ax.invert_yaxis()
    ax.set_xlim(0, 112)
    for y, value, n in zip(positions, values, frame.n):
        ax.text(value + 1, y, f"{value:.1f}% (n={int(n)})", va="center", fontsize=8)
    ax.set_xlabel(xlabel)
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(output, dpi=180, bbox_inches="tight")
    plt.close(fig)


def make_survey_figures(folder: Path, output: Path, plan: dict) -> None:
    output.mkdir(parents=True, exist_ok=True)
    frame = pd.read_csv(folder / "item_descriptives.csv").set_index("item")
    label = {
        "Q21": "Code/change volume increased", "Q22": "Senior review/repair per accepted change increased",
        "Q23": "Cross-module correction increased", "Q17": "Specialized agents used",
        "Q18": "Orchestrator agent used", "Q19": "Scope and checks defined in advance",
        "Q26": "AI use/cost tracked", "Q27": "Cheaper agents for low-risk tasks",
        "Q28": "Frontier tools reserved for high-risk tasks", "Q29": "Capability-and-cost routing",
        "Q25": "Independent evidence required", "Q33": "Final responsibility remains human",
        "Q34": "Routine junior work reduced", "Q35": "Junior learning tasks preserved",
        "Q37": "Less confident without AI"}
    items = plan["survey"]["core_items"][:4] + ["Q18"] + plan["survey"]["core_items"][4:]
    horizontal_rates(frame.loc[items], [label[x] for x in items], output / "survey_core.png",
                     "Professional survey: agreement with core items")
    items = plan["survey"]["artifact_items"] + ["Q32_same", "Q32_human"]
    labels = ["Unit tests", "Backend tests", "Frontend tests", "Integration tests", "Pre/postconditions",
              "Runtime assertions", "Formal specifications", "Same AI generates code and tests", "Human reviews AI checks"]
    horizontal_rates(frame.loc[items], labels, output / "verification.png",
                     "AI-generated verification and review", "Often or almost always (% of valid responses)")
    items = plan["survey"]["hiring_items"]
    hiring = frame.loc[items].sort_values("proportion", ascending=False)
    labels = [text.split("[")[-1].rstrip("]") for text in hiring.label]
    horizontal_rates(hiring, labels, output / "hiring_priorities.png", "Junior-hiring priorities",
                     "Very important or essential (% of valid responses)")
    providers = pd.read_csv(folder / "provider_interruption_counts.csv")
    providers["proportion"] = providers["count"] / providers.n
    horizontal_rates(providers, providers.label.tolist(), output / "provider_interruptions.png",
                     "Delays due to AI service or quota limits")
    workforce = pd.read_csv(folder / "workforce_factors.csv")
    workforce = workforce[workforce.factor.isin([
        "Lower demand, revenue pressure, or market conditions", "Organizational restructuring or merger",
        "General cost reduction unrelated to AI", "AI-enabled productivity expectations",
        "Direct automation or replacement of tasks by AI systems"])]
    horizontal_rates(workforce, workforce.factor.tolist(), output / "workforce_factors.png",
                     "Factors reported by respondents with workforce reductions")
