"""Independent reconstruction of the manuscript's statistical analyses."""

__version__ = "1.0.0"
