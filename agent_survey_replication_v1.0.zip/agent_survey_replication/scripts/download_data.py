#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import tempfile
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
USER_AGENT = "agent-survey-replication/1.0 (research data download)"
MAX_BYTES = 20 * 1024 * 1024


def request(url: str):
    if not url.startswith("https://"):
        raise ValueError("Only HTTPS downloads are allowed.")
    last = None
    for attempt in range(3):
        try:
            return urlopen(Request(url, headers={"User-Agent": USER_AGENT}), timeout=45)
        except HTTPError as exc:
            last = exc
            if exc.code not in [429, 500, 502, 503, 504]:
                raise
        except URLError as exc:
            last = exc
        if attempt < 2:
            time.sleep(2 ** attempt)
    raise OSError(f"Download failed after three attempts: {last}")


def checksum(path: Path, algorithm: str) -> str:
    h = hashlib.new(algorithm)
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def fetch(url: str, destination: Path, expected_md5: str) -> None:
    if destination.exists():
        if checksum(destination, "md5") != expected_md5:
            raise ValueError(f"Existing file has a different checksum: {destination}. It was not overwritten.")
        print(f"Already verified: {destination}")
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=destination.parent, delete=False) as out:
            temporary = Path(out.name)
            total = 0
            with request(url) as response:
                while block := response.read(65536):
                    total += len(block)
                    if total > MAX_BYTES:
                        raise ValueError("Download exceeds the 20 MB safety limit.")
                    out.write(block)
        if checksum(temporary, "md5") != expected_md5:
            raise ValueError("Downloaded bytes differ from the frozen source checksum. "
                             "No substitute data or HTML response has been accepted.")
        temporary.replace(destination)
        print(f"Downloaded and verified: {destination}")
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Download frozen survey data; classroom availability is not verified.")
    parser.add_argument("--dataset", choices=["survey", "classroom", "all"], default="survey")
    parser.add_argument("--dest", type=Path, default=Path("data/raw"))
    args = parser.parse_args(argv)
    sources = json.loads((ROOT / "data/sources.json").read_text(encoding="utf-8"))
    names = ["survey", "classroom"] if args.dataset == "all" else [args.dataset]
    try:
        for name in names:
            source = sources[name]
            if name == "survey":
                url = source["csv_url"]
            else:
                with request(source["metadata_url"]) as response:
                    raw = response.read(MAX_BYTES + 1)
                    if len(raw) > MAX_BYTES:
                        raise ValueError("Classroom metadata response exceeds safety limit.")
                    record = json.loads(raw)
                matches = [f for f in record.get("files", []) if f.get("key") == source["expected_csv_name"]]
                if len(matches) != 1:
                    raise ValueError("The proposed classroom record does not expose the exact v3 98-row CSV. "
                                     "Use the local analysis-input bundle or ask the authors for the frozen release; "
                                     "the 92-row v4 file is not a replacement.")
                file_info = matches[0]
                advertised = file_info.get("checksum", "")
                if advertised and advertised != "md5:" + source["local_original_csv_md5"]:
                    raise ValueError("The public classroom file is not the frozen locally validated CSV.")
                url = f"https://zenodo.org/records/{source['proposed_record']}/files/{quote(source['expected_csv_name'])}?download=1"
            md5 = source["csv_md5"] if name == "survey" else source["local_original_csv_md5"]
            fetch(url, args.dest / f"{name}.csv", md5)
        return 0
    except (OSError, ValueError, KeyError, json.JSONDecodeError) as exc:
        print(f"Data acquisition failed: {exc}", file=sys.stderr)
        print("No synthetic data were substituted. Consult dependencies.md and data/sources.json.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
