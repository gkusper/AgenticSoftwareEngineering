#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from replication.io import DataError, load_csv, sha256, write_json


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Remove columns unused by the statistical analysis; do not alter response values or rows.")
    parser.add_argument("--kind", choices=["survey", "classroom"], required=True)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    if args.output.exists():
        parser.error("Output already exists; no overwrite is performed.")
    try:
        book = json.loads((ROOT / "config/codebook.json").read_text(encoding="utf-8"))
        plan = json.loads((ROOT / "config/analysis_plan.json").read_text(encoding="utf-8"))
        frame = load_csv(args.input)
        keys = list(book["survey"]) if args.kind == "survey" else ["C002"] + plan["classroom"]["screen_numeric_items"]
        fields = book[args.kind]
        selected = [fields[key]["header"] for key in keys]
        missing = set(selected) - set(frame)
        if missing:
            raise DataError(f"Missing analysis columns: {sorted(missing)}")
        output = frame[selected]
        args.output.parent.mkdir(parents=True, exist_ok=True)
        output.to_csv(args.output, index=False, encoding="utf-8", lineterminator="\n")
        write_json(args.output.with_suffix(".provenance.json"), {
            "input_name": args.input.name, "input_sha256": sha256(args.input),
            "output_name": args.output.name, "output_sha256": sha256(args.output),
            "rows": len(output), "columns_retained": selected,
            "columns_removed": [c for c in frame if c not in selected],
            "transformation": "Keep analysis columns and rows unchanged; normalize whitespace as in the loader. No imputation or scoring.",
            "public_release_permission_verified": False})
        print(f"Prepared {args.output}: {len(output)} rows, {len(selected)} columns.")
        return 0
    except (OSError, ValueError, KeyError) as exc:
        print(f"Preparation failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
