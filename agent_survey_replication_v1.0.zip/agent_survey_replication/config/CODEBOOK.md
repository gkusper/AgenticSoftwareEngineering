# Frozen codebook

Full source headers are matched after whitespace normalization. Positional indexes below are documentation only; the loader never selects columns by these indexes.

## Professional questionnaire

### Q1

Q1. How many years of professional software-development experience do you have?

1 = 0–2 years; 2 = 3–5 years; 3 = 6–10 years; 4 = 11–15 years; 5 = 16–20 years; 6 = More than 20 years

### Q2

Q2. Which options best describe your current technical responsibility? (You can select more than one options)

### Q3

Q3. What is your highest completed academic degree?

### Q4

Q4. During the last three years, have you taught at least one university-level course?

### Q5

Q5. During the last six months, how often have you used AI-enabled or robotic software-development tools professionally?

1 = Never; 2 = Less than monthly; 3 = Monthly; 4 = Weekly; 5 = Daily or almost daily

### Q6

Q6. Approximately how many people work in your organization?

1 = 1; 2 = 2–10; 3 = 11–50; 4 = 51–250; 5 = 251–1,000; 6 = More than 1,000

### Q7

Q7. Which descriptions apply to your workplace?

### Q8

Q8. Since 2023, how has your workplace’s hiring of junior software developers changed?

1 = Greatly decreased; 2 = Somewhat decreased; 3 = No meaningful change; 4 = Somewhat increased; 5 = Greatly increased

### Q9

Q9. Since 2023, has your workplace reduced its software-development headcount?

### Q10

Q10. To the best of your knowledge, which factors contributed to this workforce reduction?

### Q11

Q11. When you hear the term “software robot,” which meaning comes closest to your own understanding?

### Q12

Q12. Which of the following technologies have you personally used in professional or substantial project work?

### Q13

Q13. A fully rule-based RPA bot can appropriately be called a software robot.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q14

Q14. A tool-using coding system such as Codex can appropriately be called a software robot.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q15

Q15. Even if both are called software robots, deterministic RPA bots and probabilistic AI agents should be distinguished.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q16

Q16. What is the largest number of AI agents you normally use concurrently on one software task or change request?

0 = 0; 1 = 1; 2 = 2; 3 = 3–5; 4 = 6–10; 5 = More than 10

### Q17

Q17. I use specialized agents or subagents with separate roles, tools, or contexts.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q18

Q18. I use an orchestrator agent that assigns work to or supervises one or more subagents.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q19

Q19. Before an AI agent starts a change that affects several files or modules, my team clearly defines what it may change and how the result will be checked.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q20

Q20. How often does your team require an AI coding agent to follow a fixed template, data schema, or predefined software interface?

1 = Never; 2 = Rarely; 3 = Sometimes; 4 = Often; 5 = Almost always

### Q21

Q21. LLM-based agents have increased the volume of code or software changes produced by my team.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q22

Q22. LLM-based agents have increased the amount of senior review, debugging, or repair work required per accepted change.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q23

Q23. AI agents need more correction when a task affects several files or modules than when it affects only one file or function.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q24

Q24. Which statement best describes your use of cross-model review, where one AI generates code and a different one reviews it? (Example: X generates the code, and Y checks it for errors or weaknesses.)

1 = I had not considered this approach before this survey.; 2 = I knew about this approach, but had not considered using it.; 3 = I have considered it, but have not used it.; 4 = I have used it occasionally.; 5 = I use it regularly.

### Q25

Q25. Even when two AI systems agree, acceptance requires independent technical evidence and, where business intent is involved, confirmation by an accountable human stakeholder.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q26

Q26. My team tracks AI usage or cost at task, project, team, or organizational level.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q27

Q27. I deliberately assign simple or low-risk tasks to cheaper agents (I use the big guns only when necessary).

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q28

Q28. I reserve frontier or more expensive AI tools for high-risk, or globally coupled tasks.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q29

Q29. A human or automated orchestrator selects models or agents according to both expected capability and cost.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q30

Q30. During the last six months, how often was your work delayed or interrupted because an AI service was unavailable or because you reached a usage, quota, or rate limit?

1 = Never; 2 = Rarely; 3 = Sometimes; 4 = Often; 5 = Very often

### Q31

Q31. During the last six months, did you have to continue an AI-assisted task with another AI service because the original service was unavailable, limited, or too expensive?

0 = No, this did not happen.; 1 = Yes, and switching required little effort.; 2 = Yes, and switching required substantial effort.; 3 = Yes, but we could not continue the task effectively.

### Q32_frontend

Q32. How often are the following statements true in your team when AI-generated code is developed or reviewed? [AI generates frontend tests.]

1 = Never; 2 = Rarely; 3 = Sometimes; 4 = Often; 5 = Almost always

### Q33

Q33. Final responsibility for accepting AI-generated software changes must remain with a human.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q34

Q34. AI-enabled software robots have reduced the amount of routine implementation work assigned to junior developers in my organization.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q35

Q35. My organization deliberately preserves learning tasks for junior developers, such as testing, debugging, review, and architecture analysis.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q36_fundamentals

Q36. Assume you are hiring a junior software developer for your current or most recent organization. How important would each of the following be in your hiring decision? [Fundamental programming and data-structure knowledge]

1 = Not important; 2 = Slightly important; 3 = Moderately important; 4 = Very important; 5 = Essential

### Q36_unaided

Q36. Assume you are hiring a junior software developer for your current or most recent organization. How important would each of the following be in your hiring decision? [Ability to read and debug existing code without AI assistance]

1 = Not important; 2 = Slightly important; 3 = Moderately important; 4 = Very important; 5 = Essential

### Q36_testing

Q36. Assume you are hiring a junior software developer for your current or most recent organization. How important would each of the following be in your hiring decision? [Software testing and verification skills]

1 = Not important; 2 = Slightly important; 3 = Moderately important; 4 = Very important; 5 = Essential

### Q36_assistants

Q36. Assume you are hiring a junior software developer for your current or most recent organization. How important would each of the following be in your hiring decision? [Knowledge of AI coding assistants]

1 = Not important; 2 = Slightly important; 3 = Moderately important; 4 = Very important; 5 = Essential

### Q36_agents

Q36. Assume you are hiring a junior software developer for your current or most recent organization. How important would each of the following be in your hiring decision? [Knowledge of AI agents and agentic workflows]

1 = Not important; 2 = Slightly important; 3 = Moderately important; 4 = Very important; 5 = Essential

### Q36_rpa

Q36. Assume you are hiring a junior software developer for your current or most recent organization. How important would each of the following be in your hiring decision? [Knowledge of software-robot or RPA solutions]

1 = Not important; 2 = Slightly important; 3 = Moderately important; 4 = Very important; 5 = Essential

### Q36_evaluate

Q36. Assume you are hiring a junior software developer for your current or most recent organization. How important would each of the following be in your hiring decision? [Ability to evaluate and verify AI-generated output]

1 = Not important; 2 = Slightly important; 3 = Moderately important; 4 = Very important; 5 = Essential

### Q36_architecture

Q36. Assume you are hiring a junior software developer for your current or most recent organization. How important would each of the following be in your hiring decision? [High-level software design and architecture knowledge]

1 = Not important; 2 = Slightly important; 3 = Moderately important; 4 = Very important; 5 = Essential

### Q36_lowlevel

Q36. Assume you are hiring a junior software developer for your current or most recent organization. How important would each of the following be in your hiring decision? [Low-level hardware, operating-system, or networking knowledge]

1 = Not important; 2 = Slightly important; 3 = Moderately important; 4 = Very important; 5 = Essential

### Q36_portfolio

Q36. Assume you are hiring a junior software developer for your current or most recent organization. How important would each of the following be in your hiring decision? [Personal hobby, portfolio, or open-source projects]

1 = Not important; 2 = Slightly important; 3 = Moderately important; 4 = Very important; 5 = Essential

### Q36_problem_solving

Q36. Assume you are hiring a junior software developer for your current or most recent organization. How important would each of the following be in your hiring decision? [General problem-solving and learning ability]

1 = Not important; 2 = Slightly important; 3 = Moderately important; 4 = Very important; 5 = Essential

### Q36_communication

Q36. Assume you are hiring a junior software developer for your current or most recent organization. How important would each of the following be in your hiring decision? [Communication and teamwork]

1 = Not important; 2 = Slightly important; 3 = Moderately important; 4 = Very important; 5 = Essential

### Q36_grades

Q36. Assume you are hiring a junior software developer for your current or most recent organization. How important would each of the following be in your hiring decision? [Excellent university results]

1 = Not important; 2 = Slightly important; 3 = Moderately important; 4 = Very important; 5 = Essential

### Q36_salary

Q36. Assume you are hiring a junior software developer for your current or most recent organization. How important would each of the following be in your hiring decision? [Low salary expectations relative to the local junior market]

1 = Not important; 2 = Slightly important; 3 = Moderately important; 4 = Very important; 5 = Essential

### Q37

Q37. Compared with one year ago, I feel less confident solving complex software-development problems without an AI assistant.

1 = Strongly disagree; 2 = Disagree; 3 = Neither agree nor disagree; 4 = Agree; 5 = Strongly agree

### Q38_static

Q38. How often are the following statements true in your team when AI-generated code is developed or reviewed? [Static code analysis (Examples: SonarQube, SpotBugs, ...)]

0 = Not used; 1 = Used, but not in the CI pipeline; 2 = Runs in CI and reports findings; 3 = Runs in CI and blocks the build

### Q39

Q39. Are you a human?

### Q40

Q40. How likely is it that, within the next three years, leading AI services will become substantially unavailable or economically inaccessible to software developers in Europe for a sustained period? For example because of geopolitical restrictions, prohibitive token pricing, infrastructure or energy constraints, climate-related disruption, or another cause.

1 = Very unlikely; 2 = Unlikely; 3 = Neither likely nor unlikely; 4 = Likely; 5 = Very likely

### Q38_dynamic

Q38. How often are the following statements true in your team when AI-generated code is developed or reviewed? [Dynamic testing (Examples: sanitizers, fuzzing ...)]

0 = Not used; 1 = Used, but not in the CI pipeline; 2 = Runs in CI and reports findings; 3 = Runs in CI and blocks the build

### Q32_backend

Q32. How often are the following statements true in your team when AI-generated code is developed or reviewed? [AI generates backend tests.]

1 = Never; 2 = Rarely; 3 = Sometimes; 4 = Often; 5 = Almost always

### Q32_unit

Q32. How often are the following statements true in your team when AI-generated code is developed or reviewed? [AI generates unit tests.]

1 = Never; 2 = Rarely; 3 = Sometimes; 4 = Often; 5 = Almost always

### Q32_integration

Q32. How often are the following statements true in your team when AI-generated code is developed or reviewed? [AI generates integration tests.]

1 = Never; 2 = Rarely; 3 = Sometimes; 4 = Often; 5 = Almost always

### Q32_assertions

Q32. How often are the following statements true in your team when AI-generated code is developed or reviewed? [AI generates runtime assertions.]

1 = Never; 2 = Rarely; 3 = Sometimes; 4 = Often; 5 = Almost always

### Q32_prepost

Q32. How often are the following statements true in your team when AI-generated code is developed or reviewed? [AI generates pre- and post-conditions.]

1 = Never; 2 = Rarely; 3 = Sometimes; 4 = Often; 5 = Almost always

### Q32_formal

Q32. How often are the following statements true in your team when AI-generated code is developed or reviewed? [AI generates formal specifications (invariants, proof obligations ...)]

1 = Never; 2 = Rarely; 3 = Sometimes; 4 = Often; 5 = Almost always

### Q32_same

Q32. How often are the following statements true in your team when AI-generated code is developed or reviewed? [The same AI system generates both the production code and the tests.]

1 = Never; 2 = Rarely; 3 = Sometimes; 4 = Often; 5 = Almost always

### Q32_human

Q32. How often are the following statements true in your team when AI-generated code is developed or reviewed? [A human reviews AI-generated checks before they are trusted.]

1 = Never; 2 = Rarely; 3 = Sometimes; 4 = Often; 5 = Almost always

## Classroom analysis items

Only workflow C002 and numeric items C005–C143 are required by the analysis. Identifiers, timestamps and free text are not analysis inputs.

- **C002**: Workflow condition
- **C005**: My most recent programming course grade was.
- **C006**: I consider myself a good programmer.
- **C007**: I regularly use AI tools for programming tasks.
- **C008**: I have experience using AI tools to generate source code.
- **C009**: I have experience using AI tools to explain source code.
- **C010**: I have experience using AI tools to generate tests.
- **C011**: I have experience using notebooks, such as Jupyter, Colab, or Mathematica.
- **C012**: I have experience using Kanban boards, Trello, Jira, or GitHub Issues.
- **C013**: I am comfortable working with unit tests.
- **C014**: Number of prompts I issued to the AI during the CR task.
- **C015**: Number of CRs I attempted.
- **C016**: Number of CRs I completed.
- **C017**: Number of tests passed at the end of the task.
- **C018**: Number of tests failed at the end of the task.
- **C019**: I completed the final change request successfully.
- **C020**: The final solution worked correctly.
- **C021**: The final solution was easy to modify.
- **C022**: I had to refactor my earlier solution during the change request.
- **C023**: I could identify which part of the solution had to be changed.
- **C024**: I could continue developing this solution later.
- **C025**: I enjoyed working with AI during the programming task.
- **C026**: I experienced a creative flow state while working with AI.
- **C027**: AI helped me maintain momentum during the task.
- **C028**: AI helped me try out more ideas than I would have tried alone.
- **C029**: AI helped me recover from errors quickly.
- **C030**: AI made the task feel more playful or exploratory.
- **C031**: AI sometimes made the solution more complex than necessary.
- **C032**: I sometimes accepted AI-generated code too quickly.
- **C033**: I sometimes lost control over the direction of the solution.
- **C034**: Overall, the task felt like vibe coding.
- **C035**: After using AI, I felt more confident that my solution was correct.
- **C036**: After using AI, I felt more confident that my solution was complete.
- **C037**: I completed more work with AI than I could have completed without AI.
- **C038**: AI reduced the effort needed for routine coding.
- **C039**: My perceived productivity matched the actual result.
- **C040**: I was surprised by how much I could implement with AI.
- **C041**: My confidence came mainly from the AI answer.
- **C042**: My confidence came mainly from passing tests.
- **C043**: My confidence came mainly from understanding the code.
- **C044**: I may have trusted the AI-generated solution too much.
- **C045**: During the task, I experienced AI mainly as a tool.
- **C046**: During the task, I experienced AI as a teammate.
- **C047**: During the task, I experienced AI as a mentor.
- **C048**: During the task, I experienced AI as a critic.
- **C049**: During the task, I experienced AI as an oracle.
- **C050**: During the task, I experienced AI as a product owner.
- **C051**: I remained the main decision-maker.
- **C052**: The AI influenced important design decisions.
- **C053**: I would like to use AI as a collaborator in future programming tasks.
- **C054**: I would prefer the AI to give more critical feedback instead of only generating code.
- **C055**: I remained responsible for the final solution, even when AI generated parts of the code.
- **C056**: I checked AI-generated code before accepting it.
- **C057**: I could explain the final solution in my own words.
- **C058**: If the AI produced an error, I considered it my task to detect and correct it.
- **C059**: I was aware of the limitations of the AI tool I used.
- **C060**: I knew what context the AI tool could or could not see.
- **C061**: I adapted my prompts to the capabilities of the AI tool.
- **C062**: I did not assume that the AI understood the full project context automatically.
- **C063**: Before asking AI to generate code, I tried to clarify the requirement.
- **C064**: I based my prompts on the task description or change request.
- **C065**: I updated my understanding of the requirement before modifying the code.
- **C066**: A clear specification helped me avoid vague prompts.
- **C067**: I planned what I wanted before asking AI to generate code.
- **C068**: I guided the AI with specific constraints or examples.
- **C069**: I verified the generated result before accepting it.
- **C070**: I used tests, checks, or examples as evidence that the solution worked.
- **C071**: I asked the AI to keep the code modular.
- **C072**: I asked the AI to keep the solution easy to extend.
- **C073**: I asked the AI to follow good programming practices.
- **C074**: I asked the AI to generate or respect tests.
- **C075**: I had a clear idea of when the task was finished.
- **C076**: Passing the tests was part of my definition of done.
- **C077**: I checked whether the solution satisfied all stated requirements.
- **C078**: I avoided adding unnecessary extra features before completing the required ones.
- **C079**: The requirement cell helped me understand the task.
- **C080**: The prompt cell helped me formulate better AI requests.
- **C081**: The generated-code cell helped me preserve what the AI produced.
- **C082**: The test/check cell helped me evaluate the generated solution.
- **C083**: The evidence cell helped me decide whether the solution was acceptable.
- **C084**: The reflection cell helped me understand my own work.
- **C085**: The notebook made the relationship between requirement, prompt, code, and test clearer.
- **C086**: The notebook helped me handle the change request.
- **C087**: The notebook helped me avoid losing track of the solution.
- **C088**: The AI could easily understand my references to my previous cells, like C1, C2.
- **C089**: The notebook slowed me down.
- **C090**: The notebook interrupted my creative flow.
- **C091**: The notebook introduced useful discipline into the workflow.
- **C092**: I would use this notebook structure again in a larger AI-assisted programming task.
- **C093**: The change request was easy to understand.
- **C094**: The previous solution was easy to adapt.
- **C095**: I knew which part of the solution had to be changed.
- **C096**: The AI helped me identify the affected parts.
- **C097**: The notebook helped me identify the affected parts.
- **C098**: Tests helped me decide whether the change was successful.
- **C099**: The change request revealed weaknesses in my earlier solution.
- **C100**: The structured workflow made the change request easier to handle.
- **C101**: I would have handled the change request less effectively without AI.
- **C102**: I would have handled the change request less effectively without a structured process.
- **C103**: AI tools are useful during requirements clarification.
- **C104**: AI tools are useful during design and architecture planning.
- **C105**: AI tools are useful during implementation.
- **C106**: AI tools are useful during test generation.
- **C107**: AI tools are useful during debugging.
- **C108**: AI tools are useful during code review.
- **C109**: AI tools are useful during documentation.
- **C110**: AI tools are useful during change request analysis.
- **C111**: AI tools are useful during process improvement and reflection.
- **C112**: AI tools should be integrated into the software process, not used only as separate chat tools.
- **C113**: I could identify why AI support was useful in this programming task.
- **C114**: I could identify weaknesses in my usual AI-assisted coding workflow.
- **C115**: I could define a more disciplined workflow for using AI in programming.
- **C116**: I could apply this improved workflow during the task or change request.
- **C117**: I learned what I should improve in my AI-assisted programming process next time.
- **C118**: The task helped me move from ad hoc AI use toward a more structured software process.
- **C119**: The notebook scaffold made my process more observable.
- **C120**: The notebook scaffold made my process more measurable.
- **C121**: The notebook scaffold made my process easier to improve.
- **C122**: I see structured vibe coding as a possible software process improvement.
- **C123**: I treated passing tests as a quality gate before accepting the solution.
- **C124**: I checked whether I was building the product right.
- **C125**: I checked whether I was building the right product.
- **C126**: The AI helped me verify the technical correctness of the solution.
- **C127**: The AI helped me validate whether the solution matched the requirement.
- **C128**: I would trust AI-generated code more if it passed explicit quality gates.
- **C129**: I would trust AI-generated code more if the requirement, code, tests, and evidence were linked.
- **C130**: It would be useful if AI-generated clarifications were attached to specific task cards.
- **C131**: It would be useful if an AI assistant could decompose requirements into smaller tasks.
- **C132**: It would be useful if an AI assistant could act as a product owner during student projects.
- **C133**: It would be useful if an AI assistant introduced realistic change requests during a project.
- **C134**: A Kanban board with AI comments would help me remember project decisions.
- **C135**: A Kanban board with AI comments would be more useful than a separate AI chat history.
- **C136**: I would trust an AI product owner only if the teacher could review its decisions.
- **C137**: An AI product owner could reduce waiting time for instructor feedback.
- **C138**: Structured vibe coding helped me work more effectively with AI.
- **C139**: Structured vibe coding helped me understand my own development process.
- **C140**: Structured vibe coding should be taught in programming education.
- **C141**: I would use structured vibe coding in a larger project.
- **C142**: I prefer unstructured AI chat over structured AI-assisted workflows.
- **C143**: The benefits of the structured workflow outweighed its overhead.
