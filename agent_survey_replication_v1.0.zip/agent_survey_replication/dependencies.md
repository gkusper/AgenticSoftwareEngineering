# Dependencies and input data

## Python and packages

Validated interpreter: **CPython 3.13.5**, Linux x86-64. Python 3.13 is the recommended environment for this release. Windows and macOS commands are provided, but those platforms were not executed during preparation.

| Package | Tested version | Purpose |
|---|---:|---|
| NumPy | 2.3.5 | Numeric arrays and linear algebra |
| pandas | 2.2.3 | CSV tables, matching and aggregation |
| SciPy | 1.17.0 | Rank tests, correlations, distributions and exact sign/Fisher tests |
| statsmodels | 0.14.6 | Multiplicity adjustment, ordinal logit and HC3 regressions |
| Matplotlib | 3.10.8 | Headless PNG chart generation |
| pytest | 9.0.2 | Optional automated tests |

Install `requirements-lock.txt` for the tested runtime package set, including its transitive dependencies. `requirements.txt` contains the direct runtime pins. `requirements-dev.txt` adds test requirements. No package is claimed to be the latest available version.

```bash
python -m pip install -r requirements-lock.txt
python -m pip install -r requirements-dev.txt
```

The downloader uses Python's standard `urllib`, `hashlib`, and `json` modules. There is no `requests`, Excel reader, proprietary workbook toolkit, R, LaTeX, LLM, cloud database, or GPU dependency. The analysis accepts **UTF-8 CSV** only; this avoids dependence on spreadsheet recalculation and localized Excel imports. Full archived CSVs and the minimized local input bundle are both accepted when their required headers/values match.

The code ran against the installed versions listed above. A fresh internet-based pip installation was not executed in the build environment. The GitHub workflow is supplied but was not run on GitHub during preparation.

## 1. Professional survey — required for survey analyses

**Title:** AI Coding Agents and Software Robots in Professional Software Engineering.

**Frozen v1 DOI:** <https://doi.org/10.5281/zenodo.21802516>  
**Record:** <https://zenodo.org/records/21802516>  
**Concept DOI cited in the manuscript:** <https://doi.org/10.5281/zenodo.21802515>

Use the version DOI, not a moving latest-version selection. The version record contains 205 submissions. The program excludes the five provenance-ineligible responses, yielding 200 observations; not-applicable responses are handled separately for each item.

**Download:**

<https://zenodo.org/records/21802516/files/AI%20Coding%20Agents%20and%20Software%20Robots%20in%20Professional%20Software%20Engineering_205.csv?download=1>

Archived CSV filename:

```text
AI Coding Agents and Software Robots in Professional Software Engineering_205.csv
```

Advertised CSV MD5: `62f61257df53b41cfe85a25f2c6e637f`.

Save as `data/raw/survey.csv`, or supply its original filename as the `--survey` argument. The matching XLSX is available from the same record; its MD5 is `bcff45baedc78e272597358d59e1c956`. The local XLSX used to validate this package matched that checksum exactly. Its required questionnaire values were converted to CSV without changing responses; timestamps are not analysed. End-to-end downloading through the supplied urllib helper was not tested under the build environment's network restrictions.

A 230-row source file was also available locally. Removing **all 25 members of the previously identified answer-identical block**, whose timestamps differ, reproduces the archived 205-row answers exactly. This is not a general instruction to remove all duplicate answer patterns from arbitrary survey datasets. The exact block signature is frozen in the analysis plan. The manuscript's starting value of 229 does not match the available original source.

## 2. Classroom study — required only for classroom analyses

**Exact tested release:** `structured-vibe-coding-v3-cleaned-primary-98.csv`.

Equivalent workbook sheet: `Cleaned_Primary_98` in the v3 cleaned workbook.

**N = 98:** Notebook-oriented 60; Unstructured 38. The v3 raw release has 103 rows, including five unknown workflow labels. The program can analyse either release and rechecks the counts and derived CR fields. It never relies on precomputed efficiency columns.

**Locally validated original CSV MD5:** `c392e1698e3627e991e626f3f762880c`.

A related project dataset is referenced at <https://doi.org/10.5281/zenodo.21134392> (record <https://zenodo.org/records/21134392>). **Public availability of the exact v3 classroom file at that DOI could not be verified.** The reviewed manuscript does not identify a separate classroom data DOI in its data-availability paragraph. Do not claim that this URL is a confirmed download of the 98-row analysis input until the authors check it.

The local input bundle contains only the required workflow and numeric columns, with timestamps, private call signs and open-ended responses removed. This permits immediate offline reproduction. The source trace and SHA-256 checksums are in the bundle's `LOCAL_INPUTS_PROVENANCE.json`. Its byte hash differs from the complete original CSV because unused columns were removed.

Before public release, the authors must either confirm that the exact v3 release is accessible at the proposed DOI or deposit the frozen analysis-only data and record the actual version DOI. The `--dataset classroom` downloader checks metadata, the exact filename and the validated original CSV checksum, and fails clearly when that precise release is unavailable. It does not invent a successful download.

**Do not use the v4 92-row dataset** as a substitute. It uses additional participant exclusions and would answer a different comparison.

## 3. External evidence — not program inputs

The manuscript cites practitioner interviews at DOI `10.5281/zenodo.21804053`. They are qualitative evidence and not needed to execute the statistics.

AIDev reference statistics are from Li, Zhang and Hassan, *The Rise of AI Teammates in Software Engineering (SE) 3.0*, <https://arxiv.org/abs/2507.15003>. The paper uses published statistics, not a new mining analysis. Downloading AIDev, accessing GitHub tokens, or running a mining script is not required for this reproduction package.

## Compute and storage

These inputs contain only hundreds of rows; a normal CPU computer is sufficient. After dependencies are installed, allow several tens of megabytes for inputs, tables, manifests and charts. Runtime depends on the machine and plotting setup; no runtime guarantee is made. Internet access is needed only for package/data acquisition, not for the statistical analysis itself.

## Method documentation

- SciPy Wilcoxon: <https://docs.scipy.org/doc/scipy-1.17.0/reference/generated/scipy.stats.wilcoxon.html>
- statsmodels multiple-testing API: <https://www.statsmodels.org/stable/generated/statsmodels.stats.multitest.multipletests.html>
- statsmodels OrderedModel: <https://www.statsmodels.org/stable/generated/statsmodels.miscmodels.ordinal_model.OrderedModel.html>
- GitHub setup-python: <https://github.com/actions/setup-python>

Exact calls are fixed in the source and the validated versions are recorded in each `run_manifest.json`.
