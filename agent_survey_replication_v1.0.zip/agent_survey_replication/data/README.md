# Data directory

`raw/` is intentionally empty in the GitHub code archive and is excluded by `.gitignore`.

The statistical program expects `survey.csv` (public 205-row v1 professional archive) and optionally `classroom.csv` (v3 98-row classroom analysis). The separate local input bundle also contains `survey_raw230.csv` and `classroom_raw103.csv` for replaying the documented row-selection steps. These inputs have unused timestamp, call-sign and open-ended columns removed as applicable. No analysed values are generated or imputed.

Download locations and verification limits are documented in [../dependencies.md](../dependencies.md). Machine-readable source metadata are in [sources.json](sources.json).

`reference/manuscript_targets.json` contains comparison targets transcribed from the reviewed PDF, not respondent observations. Estimation does not use these values.
