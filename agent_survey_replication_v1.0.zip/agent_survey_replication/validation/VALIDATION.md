# Executed validation — 2026-09-17

## What was executed

The full professional and classroom analyses were run on actual project data, not generated respondent data. The tested local input files retain only columns needed for analysis. Their provenance traces are distributed in the separate local-input bundle.

- **31 automated tests passed**, including a real-data integration test. See `test_results.txt`.
- The complete 205-row professional input produced **200 eligible observations**.
- The 98-row classroom input produced **60 notebook and 38 unstructured observations**.
- A second end-to-end run started from the **230-row professional** and **103-row classroom** sources. It reproduced the same final samples.
- **All 24 compared aggregate CSV tables were byte-identical** between the archived/cleaned-input run and the original-row cleaning replay. Row-number-based exclusion/invalid-count logs were not compared because source row numbers differ. See `raw_replay_check.json`.
- Python source files compiled successfully. Five generated charts were created, with the core and hiring-priority charts visually inspected for clipping/legibility.

The environment was CPython 3.13.5, NumPy 2.3.5, pandas 2.2.3, SciPy 1.17.0, statsmodels 0.14.6 and Matplotlib 3.10.8, on Linux. Exact input, code, configuration and output hashes are in `run_manifest.json`.

The validation directory contains the actual generated aggregate outputs. Individual record-number exclusion and count-cleaning logs are omitted from this public-facing snapshot; a fresh analysis generates them locally. Their original hashes remain in the unmodified run manifest as a record of the executed full run.

## Comparison with the reviewed manuscript

There are **150 reference checks**: **148 computed**, of which **92 match the displayed precision** and **56 differ**. Two H19 composite correlations are uncomputed because their scale definitions are absent. The checks are not independent scientific claims: the same result can be checked as a count, a proportion, a complete-case n and a derived effect size. Thus “56 differences” is not “56 proven statistical errors.”

All three classroom primary comparisons match Table 5 at its printed precision, including the reported Holm-adjusted p-values. For example:

| Outcome | Notebook n | Unstructured n | Welch p | Holm p | Cohen's d |
|---|---:|---:|---:|---:|---:|
| Completed CRs per prompt | 58 | 38 | 0.006408728739 | 0.019226186216 | 0.516045797949 |
| Failed tests | 60 | 38 | 0.011828702444 | 0.020088232346 | -0.646680571998 |
| Quality Gate/V&V | 60 | 38 | 0.010044116173 | 0.020088232346 | 0.558699852823 |

The principal professional-data discrepancies are visible already in unambiguous single-item counts, so they cannot all be attributed to modelling assumptions: Q25 is 175/188 = 93.1%, Q33 is 178/200 = 89.0%, and at least six years' experience totals 132 in the archived data. The reviewed PDF reports 92.6%, 88.5%, and conflicting 132/133 experience totals. Composite and sensitivity-model differences additionally depend on incompletely specified historical choices.

## What was not executed or verified

A fresh pip installation over the internet, the downloader's live network path, a GitHub-hosted workflow run, Windows/macOS execution, exact public classroom-file acquisition, the unavailable original author script, and unspecified composite definitions were not verified. Downloader checksum/overwrite/failure logic was unit-tested with mocked byte streams; no successful live download is claimed.

External AIDev statistics and qualitative interview interpretations were not reproduced from row-level data. Statistical significance is not interpreted as causation; absence of significance is not interpreted as independence or equivalence.
