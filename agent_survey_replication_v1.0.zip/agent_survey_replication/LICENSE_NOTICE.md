# License status

No software license has been selected on behalf of the authors. Before public reuse is advertised, the maintainers should add their chosen code license in `LICENSE`.

The original datasets, manuscript, cited papers and interview corpus retain their own rights and release conditions. This repository does not change those conditions. Respondent-level data are excluded from the GitHub code archive. A private/local copy supplied for analysis is not itself a new public data license.
