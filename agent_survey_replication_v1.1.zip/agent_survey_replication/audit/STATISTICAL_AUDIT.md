# Statistical reproducibility audit

Current manuscript: **EMSE_Article_hybrid_v2.6.3.tex**, supplied by the user. Audit date: 2026-09-27. Repository: gkusper/AgenticSoftwareEngineering, branch **main**, commit **9ce6112d3838dd57a242aa80dafe565e32a1c6e6**, clean at clone. The original v1.0 ZIP and supplied TeX are unchanged. Reports are in English to match the manuscript and the requested audit specification.

## A. Executive summary

The paper is **not exactly reproducible as printed**. Cleaning is reproducible, the original implementation mostly handles missing values correctly, and all three primary classroom comparisons reproduce at displayed precision. Numerous professional numbers are stale or inconsistent with the archived observations. H19 missing executable definitions alter FDR decisions; H14 original adjusted-model provenance remains unrecovered.

Current-TeX reconciliation contains **435 checks**: **124 exact equality checks**, **25 satisfied threshold assertions**, **155 rounding-only differences**, **117 numerical/logical mismatches**, **5 method/provenance mismatch rows**, and **9 unresolved rows**. This is **not** a count of independent scientific errors: repeated claims, CI endpoints, denominators and individual robustness cells are separate checks. “ROUNDING ONLY” means the printed value is correct at its stated precision. “PASS” includes exact equality or satisfaction of an explicitly printed bound. The separate code review has eight issue records, some overlapping these rows and some limitations rather than implementation defects.

Blocked scopes: exact **historical H14 model**, **original figure-binary comparison**, **unspecified AI-as-collaborator scale**, and **public acquisition of exact classroom v3**. Local exact classroom numerical recomputation is **not blocked**: the local release’s CSV MD5 exactly matches the frozen source registry. Intended H21 family and original missing-item scoring choices are unresolved, with separately labelled sensitivities rather than guessed replacements.

### Freeze, execution and independence

- Runtime: Python **3.12.14**, Windows; frozen package versions from v1.0 requirements-dev were installed. Python differs from the original Linux 3.13.5 validation environment; this audit does not claim an identical OS/interpreter. Package versions and all input SHA-256 values are in `independent/manifest.json` and each pipeline run manifest.
- **31/31 original tests passed before code changes**, including the actual professional/classroom integration test (`baseline_tests.txt`). Public survey download MD5 verified. Exact classroom v3 local MD5: **c392e1698e3627e991e626f3f762880c**. The proposed public record does not expose that file.
- Fresh baseline folders: `baseline_run` and `baseline_raw_replay`. Independent script imports no replication estimators and no manuscript targets. **955 scalar outputs** agree with v1.0 across **41 column checks** (`independent_crosscheck.csv`). The old baseline’s 56/150 differences are historical-target checks and are not this audit’s count.
- Raw230 → remove all 25 members of the exact answer-identical block → public205, **every questionnaire value and row order identical** → exclude public data rows **14,25,72,73,159** → N=200. Q39 labels also match PROVENANCE_EXCLUSIONS.csv exactly. Detailed row decisions are retained. Timestamps differ within the duplicate block; “fully identical” should mean answer-identical, excluding timestamps.
- Raw103 → documented screening / unknown workflow exclusions → classroom98. **23 aggregate survey/classroom CSV tables are byte-identical** between public/cleaned and raw runs; source-row exclusion and count-issue logs are intentionally not compared as row positions differ.
- Actual raw source is the locally available 230-response “Responses - Form Responses 1.csv”, matching the archive after deterministic cleaning. `Responses (3).xlsx` and `AI_Coding_Agents_205 (2).xlsx` each also contain 230 responses by sheet inspection. **AI_Coding_Agents_229.xlsx contains 229, not 230**; it is not an alias for this source. Its cleaned eligible n=199 and values differ. The manuscript’s lines 4–5 are stale and should name the verified source or its hash, not infer n from filename.

## B. Critical errors requiring manuscript correction

1. **H16 .403 is consistent with forbidden missing-as-Never coding**; correct frozen full-item result is .398384 (n=124), while .319022 replaces .317 for Q24. This diagnostic does not prove the historical implementation. v1.0 already excludes N/A correctly.
2. **H19 results were absent from executable v1.0**. Exact recovered item sets produce rho=.413736 and .482083, not .424/.485. Full 16-test BH now makes organization-size/interruption q=.048529: “does not survive FDR” is false under this frozen family. Including dynamic Q38 as test 17 leaves that decision significant too.
3. **H14 model provenance is unresolved**. Do not replace printed historical betas as though a new Q5/Q1/Q6 model reproduced them. Explicit reconstructed estimates are beta=−.312483,p=.0249875,n=126 and beta=−.219456,p=.105752,n=132.
4. Basic counts are also wrong, independently of composite choices: independent evidence **175/188=93.1%** (not 92.6), human responsibility **178/200=89.0%** (not 88.5), junior routine displacement **118/174=67.8%** (not 68.4), protected learning tasks **62/156=39.7%** (not 39.1). Apply corrections wherever repeated, including Discussion and external-evidence comparisons.
5. **Classroom correctness association .371 is not reproduced**: Spearman=.435769,p=7.29766136e-06 (see exact CSV),n=98. Pearson is .455750, so switching to Pearson does not explain .371.
6. Correct experience subgroup totals **110/90**, not 109/91. Teaching categories correctly sum to 199 because **one response is blank**; disclose Missing=1 (0.5%). Do not add one to an observed category.

Every exact replacement—including all changed robustness cells and demographics—is listed in `MANUSCRIPT_CORRECTIONS.md` and the required `manuscript_statistical_reconciliation.csv`. No manuscript was automatically edited.

## C. Critical code/configuration errors

See `CODE_MANUSCRIPT_MISMATCHES.md` for requirement, exact baseline file/line, behavior, consequence and minimal fix. The major unambiguous executable defect is null H19 item sets despite recovered definitions. Local classroom validation checks counts but not the frozen data values; this audit independently verified the correct file, and a semantic fingerprint should be added. Figure generation does not create the four named PDF assets expected by TeX. Stale target metadata must be labelled historical.

The following alleged problems were **not present in v1.0**: Q32 N/A-to-zero/never, reversed ordinal coding, positional header selection, global-only subgroup correction, rounding p before correction, undisclosed global listwise correlation deletion, or estimation from manuscript targets. Keeping these distinctions prevents “fixes” that would corrupt a correct implementation.

## D. H1–H13 audit

All ordinal category-to-code mappings, directions, response counts, observed missing labels and item-valid n—including Q1/Q5/Q6/Q16/Q24/Q32/Q36/Q38/Q39/Q40—are in `independent/ordinal_coding_and_missing.csv`. Q39 is a nominal eligibility item, not an ordinal score. Experience/organization category ranks increase with size; Q16=0..5 denotes category ranks, not estimated agent counts. Q38=0..3 denotes no use/manual/CI/nonblocking or blocking as specified in the exact codebook. Higher agreement on adverse outcomes means more reported difficulty; it is not a universally favourable scale.

H1 and H2 percentages/n/Wilson CI/median and their Holm significance reproduce. H2 Q21–Q22 rho=.0723997,p=.351013,n=168 also reproduces; do not describe its non-significance as absence of an effect. H3’s descriptive values and significance reproduce; its supplemental Q19/Q20 correlations are non-significant. The estimates below use two-sided signed-rank against 3 and the full 17-item Holm family (no sign-test substitution).

| item | n | statistic | p | p_holm |
| --- | --- | --- | --- | --- |
| Q21 | 177 | 788 | 1.12640131e-24 | 1.57696184e-23 |
| Q22 | 171 | 2190.5 | 1.41142661e-07 | 7.05713303e-07 |
| Q23 | 182 | 1964.5 | 5.9644343e-13 | 7.15732116e-12 |
| Q17 | 171 | 3004.5 | 5.32049335e-09 | 3.72434534e-08 |
| Q19 | 163 | 2251.5 | 5.49409451e-08 | 3.2964567e-07 |
| Q26 | 176 | 3224.5 | 5.06447288e-10 | 4.05157831e-09 |
| Q27 | 182 | 2092.5 | 2.03586736e-13 | 2.64662757e-12 |
| Q28 | 173 | 1990.5 | 2.33854848e-12 | 2.57240333e-11 |
| Q29 | 165 | 1625 | 1.13334417e-11 | 1.02000975e-10 |
| Q25 | 188 | 163.5 | 1.32342403e-31 | 2.24982085e-30 |
| Q33 | 200 | 1130 | 1.96379851e-27 | 3.14207762e-26 |
| Q34 | 174 | 1996.5 | 5.4737262e-12 | 5.4737262e-11 |
| Q35 | 156 | 2626 | 0.299598602 | 0.898795805 |
| Q37 | 193 | 4535.5 | 0.0252417701 | 0.10096708 |
| Q15 | 200 | 532.5 | 5.66227681e-25 | 8.49341522e-24 |
| Q18 | 155 | 4141.5 | 0.56078558 | 1 |
| Q40 | 200 | 5866 | 0.84347337 | 1 |

H4 accountability percentages and rho change (rho=.438897, not .447), while cross-model use 93/165=56.4% reproduces. H5 cost tracking is 129/176=73.3%; the Q27–Q29 range is 67.6–68.1%, alpha=.790407. H6 multi-agent 112/188=59.6%, specialized-agent 120/171=70.2%, and orchestrator agreement/disagreement/median reproduce. H7 unit/backend/frontend/integration percentages reproduce; pre/postconditions=42.9%, assertions=41.1%, formal=37.8%, human review=84.5%. Same-generator use=50.6% reproduces, but association with human review is rho=−.011350,p=.884956,n=165, not −.030/.699.

H8 junior hiring 87/150=58.0% reproduces; Q34/Q35 percentages and correlation change (rho=−.061572,p=.458786). Q35 Holm p=.898796 (display .899), not 1.0, still non-significant. H9 Friedman chi-square=994.265187,df=13,n=155,W=.493432; all seven named pairwise superiority comparisons retain Holm significance. Fundamentals/problem solving/communication/AI-output verification percentages change to 85.5/89.8/82.7/65.3%; unaided reading=79.8 and agent knowledge=28.8 reproduce. Grades and low salary each remain below 6%.

H10 Q37 agreement=34.7%, disagreement=43.0%, median=3, Holm p=.100967 (not .075); no above-midpoint population conclusion follows. H11 interruption=55.7% and switching difficulty=16.1% reproduce, switching=45.7% replaces46.2%; interruption/switching rho=.461333 replaces .468. Access risk 42.0/35.0%,median3 reproduces. H12 robot meanings: AI27.5%, either21.5%, RPA19.0%, unclear18.5%, script13.5%; distinction agreement=75.5%. H13 denominator99 reproduces: restructuring47.5%, market47.5%, non-AI cost42.4%, AI productivity27.3%, direct automation15.2%. These are multi-select attributions, not causal estimates or a test that AI was/is not a primary cause.

| hypothesis | x | y | n | rho | p |
| --- | --- | --- | --- | --- | --- |
| H2 | Q21 | Q22 | 168 | 0.0723997066 | 0.351013188 |
| H3 | Q23 | Q19 | 159 | 0.0180963758 | 0.820886662 |
| H3 | Q23 | Q20 | 167 | 0.0620110636 | 0.425969761 |
| H4 | Q25 | Q33 | 188 | 0.43889679 | 2.97010062e-10 |
| H7 | Q32_same | Q32_human | 165 | -0.0113500066 | 0.884955818 |
| H8 | Q34 | Q35 | 147 | -0.0615717158 | 0.458785745 |
| H11 | Q30 | Q31 | 185 | 0.461332637 | 3.8743443e-11 |

## E. H14–H21 audit

Arithmetic mean scores require all frozen items; alpha is raw/unstandardized and listwise. Keep the original/reconstructed distinction: original v1.0 exported no H19 composite results; the corrected definition-based computation supplies both without changing source responses. Acceptable-alpha cutoff is not stated in current TeX; no post-hoc item deletion or scale-selection threshold was invented.

| scale | items | n | alpha |
| --- | --- | --- | --- |
| routing | Q27;Q28;Q29 | 159 | 0.790407088 |
| orchestration | Q16;Q17;Q18 | 146 | 0.778221058 |
| verification | Q32_unit;Q32_backend;Q32_frontend;Q32_integration;Q32_prepost;Q32_assertions;Q32_formal | 124 | 0.913388326 |
| contract | Q32_assertions;Q32_prepost;Q32_formal | 141 | 0.873487253 |
| traditional_engineering | Q36_fundamentals;Q36_unaided;Q36_testing;Q36_architecture;Q36_problem_solving | 186 | 0.703311021 |
| ai_literacy | Q36_assistants;Q36_agents | 190 | 0.925997016 |

| hypothesis | x | y | n | rho | p | q_bh_16 | survives |
| --- | --- | --- | --- | --- | --- | --- | --- |
| H14 | contract | Q22 | 129 | -0.225173116 | 0.0102991844 | 0.0128876874 | True |
| H14 | contract | Q23 | 135 | -0.21975597 | 0.0104378531 | 0.0128876874 | True |
| H15 | orchestration | verification | 105 | 0.537831148 | 3.29013898e-09 | 2.32824402e-08 | True |
| H16 | Q5 | Q21 | 177 | 0.288951144 | 9.59781355e-05 | 0.000255941695 | True |
| H16 | Q5 | verification | 124 | 0.39838421 | 4.59544968e-06 | 1.83817987e-05 | True |
| H16 | Q5 | Q24 | 165 | 0.319022497 | 2.9612834e-05 | 9.47610687e-05 | True |
| H16 | Q5 | Q22 | 171 | -0.189035139 | 0.0132792303 | 0.0151762632 | True |
| H17 | Q21 | Q34 | 158 | 0.29269042 | 0.00019003153 | 0.00038006306 | True |
| H18 | Q1 | Q37 | 193 | -0.234380406 | 0.00103518468 | 0.00184032831 | True |
| H19 | Q36_evaluate | traditional_engineering | 186 | 0.413735836 | 4.36545754e-09 | 2.32824402e-08 | True |
| H19 | Q36_evaluate | ai_literacy | 190 | 0.482082992 | 1.88966766e-12 | 3.02346826e-11 | True |
| H20 | Q26 | routing | 149 | 0.157349681 | 0.0553042981 | 0.0553042981 | False |
| H21 | Q6 | Q32_formal | 159 | 0.294229928 | 0.000166881461 | 0.00038006306 | True |
| H21 | Q6 | Q38_static | 163 | 0.216758158 | 0.00544919483 | 0.00871871172 | True |
| H21 | Q6 | Q24 | 158 | 0.2031371 | 0.010471246 | 0.0128876874 | True |
| H21 | Q6 | Q30 | 186 | -0.146844161 | 0.0454957354 | 0.0485287844 | True |

The executable family is H14(2),H15(1),H16(4),H17(1),H18(1),H19(2),H20(1),H21(4). H21=Q6 with formal Q32, static Q38, Q24, Q30. HYPOTHESES additionally lists dynamic Q38, inconsistent with its own total. Hence reconstructed-family q values are conditional, not proof of the original exploratory search or prospective FDR control. Dynamic individually: n=153,rho=.182158,p=.0242227; BH across the explicit 17-member sensitivity yields q=.0274524. Static rho=.216758 concerns the single four-level static-analysis item, **not a combined static/dynamic scale** and not a binary CI indicator. The origin/construct of manuscript .195 is unresolved.

H18 agreement is47/106=44.3% versus20/87=23.0%, OR=2.668644,95%CI1.422031–5.008092; report2.67[1.42,5.01]. H20 correct full-case rho=.157350,p=.0553043,q=.0553043; it is still non-significant, not evidence of independence.

Partial sensitivities and reconstructed H14 models:

| hypothesis | n | rho | p | controls | status |
| --- | --- | --- | --- | --- | --- |
| H15 | 103 | 0.486420988 | 2.88313239e-07 | Q5;Q1;Q6 | Reconstructed sensitivity |
| H17 | 155 | 0.303862877 | 0.000141382764 | Q5;Q1;Q6 | Reconstructed sensitivity |

| outcome | n | beta | p | status |
| --- | --- | --- | --- | --- |
| Q22 | 126 | -0.312483301 | 0.0249874603 | Reconstructed; historical adjustment set unknown |
| Q23 | 132 | -0.21945599 | 0.10575221 | Reconstructed; historical adjustment set unknown |

## F. H16 deep audit

See `H16_AUDIT.md` for encodings, item sets, missing rules, actual n/rho/p/q, complete-item and available-item means, invalid missing-as-1/0 diagnostic, and the 229-source history check. The .403 mechanism is directly demonstrated; .317’s exact source is unresolved. “Adaptation/maturity” is an interpretation, not an independently measured construct tested by these four correlations.

## G. Subgroup robustness audit

All **112 percentage cells** were parsed directly from the current TeX and checked, not borrowed from old manuscript_comparison.csv. Valid group/cell denominators are exported in `independent/subgroup_descriptives.csv`. Group totals are experience110/90; AI use137/63; organization55/41/97. Seven “Not sure” organization answers are excluded only from organization analyses, not from N=200.

The stated within-split BH correction has exactly two significant tests:

| split | item | p | q_bh_within_split | q_bh_global |
| --- | --- | --- | --- | --- |
| experience | Q37 | 0.000229205875 | 0.00320888225 | 0.00481332338 |
| ai_use | Q21 | 0.000130146094 | 0.00182204531 | 0.00481332338 |

The global 42-test correction is separately reported and does not replace those families. Both survive it too. Several percentages/ranges nevertheless change; use the correction ledger. Integer cells were checked with half-unit rounding, while full precision is retained. No non-significant subgroup test establishes equivalence. The current manuscript already correctly acknowledges this; do not flag an already-correct caveat as an error.

## H. Demographic arithmetic audit

Experience19+49+42+38+20+32=200; at least6 years=132. AI use137+33+13+9+8=200; weekly or more170. Organization6+14+35+41+26+71+7=200. Junior hiring categories sum200. The current experience table is internally consistent; the old target file’s133 total is stale and must not be reinstated.

Degree: MSc60(30.0%) replaces59(29.5%); PhD18(9.0%) replaces19(9.5%). Q9 reduction with unknown affected levels28(14.0%) replaces27(13.5%), mainly junior17(8.5%) replaces18(9.0%). Aggregate reduced-headcount99 is unchanged. University teaching counts146+19+15+11+8=199 correctly describe199 observed answers; one blank adds the missing0.5%. All demographic rows were checked individually, not just totals.

## I. Classroom audit

The exact local v3 CSV checksum is verified and no v4/92 substitute used. Primary results independently reproduced:

| outcome | n_notebook | n_unstructured | mean_notebook | mean_unstructured | sd_notebook | sd_unstructured | p | cohen_d | mann_whitney_p | p_holm |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| completed_per_prompt | 58 | 38 | 0.595000206 | 0.354828132 | 0.551161958 | 0.286895804 | 0.00640872874 | 0.516045798 | 0.0244992325 | 0.0192261862 |
| failed_tests | 60 | 38 | 1.1 | 4.13157895 | 2.5822077 | 6.81084609 | 0.0118287024 | -0.646680572 | 0.00639514596 | 0.0200882323 |
| quality_gate | 60 | 38 | 4.1452381 | 3.83834586 | 0.530294076 | 0.578309014 | 0.0100441162 | 0.558699853 | 0.00969287644 | 0.0200882323 |
| completed_crs | 58 | 38 | 3.79310345 | 3.73684211 | 2.44058248 | 2.21401202 | 0.907229477 | 0.0239002707 | 0.795896007 |  |
| human_ownership | 60 | 38 | 3.73333333 | 3.30263158 | 0.797063821 | 0.988374817 | 0.0270462907 | 0.491802292 | 0.0464828684 |  |

| target | n | rho | p |
| --- | --- | --- | --- |
| C020 | 98 | 0.435769234 | 7.29766136e-06 |
| C021 | 98 | 0.350541295 | 0.000402199875 |
| test_success_ratio | 98 | 0.33607706 | 0.000716261855 |
| failed_tests | 98 | -0.271066075 | 0.00693958221 |

| outcome | n | beta | p |
| --- | --- | --- | --- |
| completed_per_prompt | 74 | 0.250423703 | 0.0383100654 |
| failed_tests | 75 | -3.27560575 | 0.0220308378 |
| quality_gate | 75 | 0.252614728 | 0.0329511812 |
| human_ownership | 75 | 0.224656611 | 0.321929435 |

All reported primary means/SDs/Welch/Holm/d and MW p-values match displayed precision. Quality Gate alpha=.696431754,n=98; the stated completed-CR means3.79/3.74 and p=.9072 reproduce. All three HC3 group coefficients remain nominally significant with the six stated covariates; full model n=74/75/75, not98. Course-grade nonresponse and baseline missingness explain this reduced sample. These are associational sensitivities, not randomized effects.

Secondary requirement decomposition4.22(n88), task-card clarification3.98(n90), linked-evidence trust4.12(n98), ownership3.73vs3.30,d=.492, and AI role means4.08/3.17/2.41/2.22 reproduce. “Notebook slowed me down”3.04 is the **notebook subgroup mean**, n57; all valid answers have mean3.00,n74. The subgroup must be stated. The AI-as-collaborator composite item set is absent; no exact test is claimed.

Failed-test counts lack a common denominator: total passed+failed ranges1–125(median15) in notebook and1–104(median16) in unstructured, with28 and24 distinct totals. Thus counts cannot be interpreted as a comparable failure rate or superior objective quality without shared test-suite evidence. Test-success ratio provides a distinct descriptive sensitivity; it does not retroactively standardize original task difficulty or test scope.

Public reproducibility remains blocked for this file despite exact local reproducibility. The manuscript's public DOI claim and repository's pending-deposit statement disagree. No classroom respondent data are republished in the audit deliverables.

## J. Figure audit

Five baseline survey PNGs were regenerated from the exact same fresh N=200 tables; no reuse of archived PNGs. The four original PDFs referenced by TeX were not supplied or present beside the located inputs, so **no original figure is declared stale without seeing it**. The package nevertheless does not generate the named assets or core diverging layout. The corrected package adds four manuscript-named PDFs and inspection PNGs. Fresh figures necessarily display corrected percentages; discrepancies against printed tables are recorded in the ledger. Archived validation percentages reproduce the fresh baseline aggregates; no evidence that its PNG-generation inputs came from another N was found.

## K. Semantic/interpretation issues

Minimal replacements, without rewriting the manuscript:

- H2 line505: “55.6% agreed that senior review/debugging/repair effort per accepted change had increased.” This preserves self-report/attitude and temporal increase, instead of implying directly observed effort.
- H14 line580: “Higher contract-like generation scores were associated with weaker agreement that per-accepted-change senior review/debugging/repair effort had increased (rho=−.225) and weaker agreement that multi-module tasks needed more correction (rho=−.220).” The original item measures comparative correction need, not absolute correction workload.
- H16 line582 and Discussion816–818: use the full replacement sentence in H16_AUDIT. Lower Q22 means weaker agreement about an **increase**, not lower workload even when qualified “per accepted change.” Adaptation is compatible with, not demonstrated by, the correlation.
- H21 line588: “Organization size correlated with the ordered static-analysis integration item (rho=.217); report dynamic testing separately (rho=.182).” State which family was frozen and give raw p/q. Replace the incorrect non-survival claim about interruption.
- H20: current RQ3/Discussion correctly says the coupling is unresolved; **no independence wording error remains there**. Update rho/p only. Non-significance is not proof of independence or distinct capabilities.
- Assurance paragraph: “Same-generator use showed no statistically detectable association with reported human-review frequency (rho=−.011,p=.885).” Review can be frequent overall; this association cannot show absence of compensatory assurance or measure actual review quality.
- Conclusion: “Respondents reported reduced routine junior work and junior hiring; the survey did not establish a compensating redesign of learning tasks.” Q35 measures deliberate task preservation, not the broader construct of curriculum/pipeline redesign.
- Classroom: “Among notebook respondents who answered this item (n=57), the mean for ‘the notebook slowed me down’ was3.04.” Do not describe it as a full-sample mean. “Fewer failed tests” is a count result, not a denominator-standardized quality comparison.
- H13 assessment: “Respondents selected non-AI restructuring/market factors more frequently than direct AI replacement.” This is a descriptive comparison of self-reported multi-select factors, not causal rejection of AI as the primary reason.
- Reproducibility statement: “The package reproduces the frozen-data analyses under the explicitly documented reconstruction; remaining manuscript discrepancies and unresolved historical specifications are reported in the audit.” Do not claim every printed number exactly reproduces.

The current manuscript already labels H14–H21 exploratory, notes mixed significance in the FDR table, rejects subgroup equivalence, and states non-causality/selection limits. Retain those passages. “Strongly supported” categories in the abstract are editorial synthesis, not machine-assigned significance classifications. External AIDev and informal interview percentages were not re-mined or converted into respondent-survey evidence; their quantitative source verification is outside these archived respondent computations. The claimed starter AIDev mining script is absent from the inspected v1.0 file inventory and should be removed or supplied.

## L. Recommended minimal fixes and release status

Freeze exact H19 definitions; recompute all16 q-values; enforce classroom semantic identity for ordinary runs; generate manuscript-named figure assets; retain and explicitly label historical target comparisons; update H19 metadata. Preserve the correct N/A mappings, raw data, midpoint/correction families and signed-rank methods. Leave historical H14 and H21 family decisions explicitly unresolved.

The supplied TeX is unchanged. The report and correction ledger were completed before the restricted code fixes. Final executed tests, fresh corrected public/raw runs, independent comparison and archive checksums are recorded in `FINAL_VALIDATION.md`. The v1.1 ZIP is an **audited reconstruction**, not certification of every manuscript value or recovery of missing historical choices. Public classroom deposition and original figure comparison remain outstanding.
