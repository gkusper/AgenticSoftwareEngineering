# Final executed validation

- Original unmodified v1.0 tests: **31 passed**.
- Final corrected v1.1 tests: **33 passed** (`v11_final_tests.txt`), including exact same-count classroom mutation rejection and independently audited H19/H16/FDR regression checks. None skipped in this local run.
- Full final pipeline, professional public205 plus exact classroom98: success, `v11_final/`.
- Full final pipeline, professional raw230 plus classroom raw103: success, `v11_final_raw/`.
- **24 aggregate CSV tables byte-identical** across the final public/cleaned and raw replays. Exclusion/count-issue logs use different source row numbers and are deliberately excluded from equality testing. Both cleaning fingerprints match.
- All16 n/rho/p/q values agree with the independent implementation (tolerance1e-11 relative/1e-13 absolute); all17-family sensitivity q-values agree. Non-H19 survey tables and all classroom CSV tables remain byte-identical to fresh v1.0 baseline results. The only intended changes to existing survey estimates are H19 reliability/correlations and full-family BH q-values.
- Four manuscript-named PDFs and matching PNGs regenerated, plus five compatibility PNGs. The four layouts were visually inspected for clipping/legibility and their labels/proportions checked against source tables. Q23 label now states cross-module tasks need more correction, avoiding an implied temporal increase. Original manuscript PDF figure binaries were unavailable, so their staleness is unresolved.
- Final executed source/config SHA-256 values were checked against packaged source bytes. Original v1.0 ZIP SHA-256 **1e5a7b53febbf5389110a2ad349dedeeb54fe15ea4590be0a9aaa467b92a3fc9** unchanged. Supplied manuscript SHA-256 **f8fd76ac93d14462aa30c7430696df08f8a7d163e61317995fe028b3a02c8443** unchanged.
- Current-TeX435-check reconciliation is separate from the pipeline's explicitly historical150-target comparator. Final legacy comparator has58 differences, including two newly computable H19 values; this does not replace the current audit count117.
- No input dataset edits, manuscript edits, repository push, external publication, or classroom respondent-data redistribution occurred. The GitHub clone is still clean.

The bundle is an audited reconstruction, not an exact reproduction of every printed number. Unresolved historical H14 controls, H21 family inconsistency, original scoring provenance, original figure binaries, unspecified classroom collaborator scale and missing exact public classroom download remain explicitly documented.
