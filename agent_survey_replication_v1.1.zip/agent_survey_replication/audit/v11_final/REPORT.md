# Reproduction report

This is an independent reconstruction, not the original analysis script.
The comparison below uses retained HISTORICAL manuscript targets, not a fresh parsing of v2.6.3. Use the accompanying current-manuscript statistical audit for current claims. H19 is defined in v1.1.
Published values are used only for comparison, never as inputs to estimation.

## Professional survey

Input: 205 records; documented duplicate-block removal: 0; provenance exclusions: 5; analysed: 200.
Matches the frozen archived questionnaire responses: True.

The verified 230-row source becomes the public 205-row archive after removing all 25 records in the previously identified answer-identical block. Their timestamps are different. The current manuscript body says 230; its stale 229-row source comment is not the frozen source.

Midpoint tests: 17-test Holm family. The exact sign tests form a separate 17-test sensitivity family. Subgroup BH correction is within each 14-item split; a global 42-test sensitivity is also exported.

Exploratory BH correction retains all 16 explicitly listed comparison slots. The recovered H19 scales are now analysed; all 16 raw p-values enter the correction. A separately labelled 17-test sensitivity includes dynamic Q38 because the prose family is inconsistent. This newly frozen family does not establish what the original exploratory search included.

## Classroom comparison

Input: 98; included: 98; groups: {'Notebook': 60, 'Unstructured': 38}.
Invalid CR counts are set to missing only in derived CR variables; participants are not removed for this reason.
Welch tests and pooled Cohen's d are recomputed from observations. Primary Holm correction contains three outcomes.
HC3 models use complete cases for the outcome and six baseline covariates; no imputation is used. The failed-test count is self-reported and is not a standardized test-failure rate.

## Manuscript comparison

Computed checks: 150. Matching at displayed precision: 92. Different: 58. Not computed: 0.

The following are differences, not automatic conclusions that either source is wrong. Dataset versions and incomplete method definitions must be reconciled by the authors.

| Metric | Manuscript | Computed | Location |
|---|---:|---:|---|
| `experience_at_least_6_n` | 133 | 132 | Table 11 (sum of experience categories) |
| `Q25.proportion` | 0.926 | 0.93085106 | Sections 5.1-5.4 |
| `Q26.proportion` | 0.739 | 0.73295455 | Sections 5.1-5.4 |
| `Q28.proportion` | 0.671 | 0.67630058 | Sections 5.1-5.4 |
| `Q33.proportion` | 0.885 | 0.89 | Sections 5.1-5.4 |
| `Q34.proportion` | 0.684 | 0.67816092 | Sections 5.1-5.4 |
| `Q35.proportion` | 0.391 | 0.3974359 | Sections 5.1-5.4 |
| `Q37.proportion` | 0.342 | 0.34715026 | Sections 5.1-5.4 |
| `Q32_prepost.n` | 155 | 156 | Figure 2 |
| `Q32_prepost.proportion` | 0.432 | 0.42948718 | Section 5.2 / Table 1 |
| `Q32_assertions.n` | 150 | 151 | Figure 2 |
| `Q32_assertions.proportion` | 0.407 | 0.41059603 | Section 5.2 / Table 1 |
| `Q32_formal.n` | 163 | 164 | Figure 2 |
| `Q32_formal.proportion` | 0.38 | 0.37804878 | Section 5.2 / Table 1 |
| `Q32_human.proportion` | 0.839 | 0.84482759 | Section 5.2 / Table 1 |
| `Q15.proportion` | 0.75 | 0.755 | Sections 5.1-5.5 |
| `Q36_problem_solving.proportion` | 0.893 | 0.89839572 | Sections 5.1-5.5 |
| `Q36_fundamentals.proportion` | 0.85 | 0.85492228 | Sections 5.1-5.5 |
| `Q36_communication.proportion` | 0.822 | 0.82722513 | Sections 5.1-5.5 |
| `Q36_evaluate.proportion` | 0.648 | 0.65284974 | Sections 5.1-5.5 |
| `cross_model_regular` | 0.273 | 0.27878788 | Section 5 / Tables 1-2 |
| `provider_switched` | 0.462 | 0.45698925 | Section 5 / Tables 1-2 |
| `static_blocks` | 0.425 | 0.41916168 | Section 5 / Tables 1-2 |
| `routing.alpha` | 0.799 | 0.79040709 | Section 5 / Table 4 |
| `orchestration.alpha` | 0.783 | 0.77822106 | Section 5 / Table 4 |
| `verification.alpha` | 0.914 | 0.91338833 | Section 5 / Table 4 |
| `contract.alpha` | 0.875 | 0.87348725 | Section 5 / Table 4 |
| `verification_artifacts.n` | 123 | 124 | Section 5.5 |
| `verification_artifacts.statistic` | 73.7 | 73.784941 | Section 5.5 |
| `verification_artifacts.kendall_w` | 0.1 | 0.099173308 | Section 5.5 |
| `hiring_priorities.n` | 154 | 155 | Section 5.5 |
| `hiring_priorities.statistic` | 990.4 | 994.26519 | Section 5.5 |
| `hiring_priorities.kendall_w` | 0.495 | 0.49343185 | Section 5.5 |
| `Q25:Q33.rho` | 0.447 | 0.43889679 | Sections 5.2-5.5 |
| `Q32_same:Q32_human.rho` | -0.03 | -0.011350007 | Sections 5.2-5.5 |
| `Q34:Q35.rho` | -0.066 | -0.061571716 | Sections 5.2-5.5 |
| `Q30:Q31.rho` | 0.468 | 0.46133264 | Sections 5.2-5.5 |
| `H14.contract:Q22.rho` | -0.231 | -0.22517312 | Table 4 |
| `H14.contract:Q23.rho` | -0.231 | -0.21975597 | Table 4 |
| `H15.orchestration:verification.rho` | 0.551 | 0.53783115 | Table 4 |
| `H16.Q5:verification.rho` | 0.403 | 0.39838421 | Table 4 |
| `H16.Q5:Q24.rho` | 0.317 | 0.3190225 | Table 4 |
| `H17.Q21:Q34.rho` | 0.309 | 0.29269042 | Table 4 |
| `H19.Q36_evaluate:traditional_engineering.rho` | 0.424 | 0.41373584 | Table 4 |
| `H19.Q36_evaluate:ai_literacy.rho` | 0.485 | 0.48208299 | Table 4 |
| `H20.Q26:routing.rho` | 0.128 | 0.15734968 | Table 4 |
| `H21.Q6:Q32_formal.rho` | 0.27 | 0.29422993 | Table 4 |
| `H21.Q6:Q38_static.rho` | 0.195 | 0.21675816 | Table 4 |
| `H21.Q6:Q24.rho` | 0.216 | 0.2031371 | Table 4 |
| `H21.Q6:Q30.rho` | -0.129 | -0.14684416 | Table 4 |
| `H15.partial_rho` | 0.503 | 0.48642099 | Table 4 |
| `H17.partial_rho` | 0.32 | 0.30386288 | Table 4 |
| `H18.odds_ratio` | 2.65 | 2.6686441 | Table 4 |
| `H18.odds_ci_low` | 1.41 | 1.4220308 | Table 4 |
| `H18.odds_ci_high` | 4.98 | 5.0080922 | Table 4 |
| `Q35.p_holm` | 1 | 0.8987958 | Table 2 |
| `Q37.p_holm` | 0.075 | 0.10096708 | Table 2 |
| `classroom.quality_gate:C020.rho` | 0.371 | 0.43576923 | Section 6.2 |

## Unresolved scope

The original professional analysis code was not available. Complete-case composite scoring, ordinal coding, the exact test families, and H14 sensitivity covariates are explicitly frozen in config/analysis_plan.json. The recovered H19 item sets are implemented with explicitly declared complete-item means. The classroom Quality Gate and human-ownership blocks reproduce the quoted summaries but still require author confirmation. The AI-as-collaborator composite cannot be reconstructed from an unspecified item set.

AIDev is external published reference evidence, not newly mined data. Interviews and causal mechanisms are not computationally reproduced.

Non-significant associations do not establish independence, subgroup equivalence, or absence of review. None of the scripts assigns subjective 'strongly supported' hypothesis labels.
