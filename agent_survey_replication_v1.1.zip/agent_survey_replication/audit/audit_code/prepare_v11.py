from pathlib import Path
import shutil,json,sys
R=Path(__file__).resolve().parent.parent; B=R/'work/baseline/agent_survey_replication'; V=R/'work/v11/agent_survey_replication'
assert not V.exists()
shutil.copytree(B,V,ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','raw'))
sys.path.insert(0,str(B))
from replication.io import load_csv,remap_columns,signature
book=json.loads((B/'config/codebook.json').read_text(encoding='utf-8'))
p=json.loads((B/'config/analysis_plan.json').read_text(encoding='utf-8'))
required=['C002']+p['classroom']['screen_numeric_items']
cl=remap_columns(load_csv(R/'work/classroom_source/structured-vibe-coding-v3-cleaned-primary-98.csv'),book['classroom'],required)
raw=remap_columns(load_csv(R/'work/classroom_source/structured-vibe-coding-v3-raw-103.csv'),book['classroom'],required)
raw=raw.loc[raw.C002.isin(p['classroom']['workflow_labels'])].reset_index(drop=True)
assert cl.equals(raw)
p['classroom']['primary_semantic_sha256']=signature(cl.values.tolist())
p['classroom']['primary_semantic_hash_scope']='Normalized C002 and C005..C143, retained rows in source order, before numeric conversion; verified raw103 replay equals exact MD5 c392e1698e3627e991e626f3f762880c primary98.'
groups={'traditional_engineering':['Q36_fundamentals','Q36_unaided','Q36_testing','Q36_architecture','Q36_problem_solving'], 'ai_literacy':['Q36_assistants','Q36_agents']}
for k,items in groups.items():p['survey']['scales'][k]={'items':items,'minimum_items':len(items),'status':'Item set recovered in frozen HYPOTHESES.md at commit 9ce6112. Full-item arithmetic mean follows the explicitly frozen reconstruction convention; not proof of historical scoring.'}
p['survey']['scales']['verification']['status']='Seven generation items confirmed by current HYPOTHESES.md. Complete-item mean retained from frozen reconstruction; excludes same-generator and human-review items.'
p['version']='1.1.0'
p['survey']['exploratory_family_note']='Executable 16 preserved. HYPOTHESES prose additionally lists dynamic Q38 despite total16/H21=4. Dynamic association and 17-test sensitivity exported separately; intended historical family unresolved.'
(V/'config/analysis_plan.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(V/'replication/__init__.py').write_text('"""Audited independent reconstruction, not original author code."""\n__version__ = "1.1.0"\n',encoding='utf-8')
for filename in ['HYPOTHESES.md','REPRODUCIBILITY.md','PROVENANCE_EXCLUSIONS.csv','PROVENANCE_EXCLUSIONS.md']:
    shutil.copy2(R/'work/repository'/filename,V/filename)
with (V/'METHODS.md').open('a',encoding='utf-8') as f:f.write('''

## v1.1 audit addendum (supersedes stale H19 statements above)

H19 is now computed: traditional competence = Q36 fundamentals, unaided reading/debugging, testing, architecture, problem solving; AI literacy = assistants and agents. Means require 5/5 and 2/2 valid items. These definitions come from frozen HYPOTHESES.md, not from numerical targets. All 16 actual primary p-values enter BH. Dynamic Q38 is separately exported with a 17-test sensitivity because the prose family is internally inconsistent. Do not claim that this recovers the historical search.

The classroom loader now validates a frozen normalized retained-response fingerprint, not only 98/60/38 counts. --allow-data-change is still an explicit override. No source response is edited. Manuscript figure PDFs and review PNGs are produced from the same output tables. The legacy manuscript comparison is a historical diagnostic; current v2.6.3 claims are audited separately in manuscript_statistical_reconciliation.csv. H14 historical controls and the collaborator composite remain unresolved.
''')
(V/'AUDIT_CHANGELOG.md').write_text('''# v1.1.0 audit changes

Source: v1.0 ZIP at repository commit 9ce6112d3838dd57a242aa80dafe565e32a1c6e6.

H19 item sets activated with declared full-item scoring. Classroom semantic fingerprint added. Primary 16-test family preserved; dynamic and 17-test sensitivity labelled separately. Four manuscript-named PDF figures added. Legacy comparison explicitly labelled historical. Data/TeX untouched; v1.0 ZIP untouched. See adjacent audit reports, full correction ledger and FINAL_VALIDATION.md. Original validation folder retains historical v1.0 outputs, not v1.1 evidence.
''',encoding='utf-8')
text=(V/'README.md').read_text(encoding='utf-8')
text='# v1.1 audited reconstruction\n\nSee AUDIT_CHANGELOG.md and the adjacent audit reports. The original README below is retained for historical context; statements that H19 cannot be computed are superseded by v1.1 config and METHODS addendum. Current-TeX agreement is not implied by a successful run.\n\n'+text
(V/'README.md').write_text(text,encoding='utf-8')
print(V); print('Classroom semantic SHA256',p['classroom']['primary_semantic_sha256'])
