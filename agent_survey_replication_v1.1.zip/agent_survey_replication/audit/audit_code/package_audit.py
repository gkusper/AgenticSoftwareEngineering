from pathlib import Path
import json,hashlib,zipfile,shutil,difflib
import pandas as pd
import numpy as np
R=Path(__file__).resolve().parent.parent; O=R/'outputs'; B=R/'work/baseline/agent_survey_replication'; V=R/'work/v11/agent_survey_replication'
F=O/'v11_final'; RAW=O/'v11_final_raw'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert '33 passed' in (O/'v11_final_tests.txt').read_text(encoding='utf-8-sig')
checks=[]
for p in F.glob('*/*.csv'):
    if p.stem in ['exclusions','count_cleaning']:continue
    q=RAW/p.relative_to(F)
    ok=p.read_bytes()==q.read_bytes(); assert ok,p
    checks.append({'table':str(p.relative_to(F)),'raw_replay_byte_identical':ok})
pd.DataFrame(checks).to_csv(O/'v11_raw_replay_verification.csv',index=False)
ind=pd.read_csv(O/'independent/exploratory_correlations.csv').set_index(['hypothesis','x','y'])
v=pd.read_csv(F/'survey/exploratory_correlations.csv').set_index(['hypothesis','x','y'])
for a,b in [('n','n'),('rho','rho'),('p','p'),('q_bh_16','q_bh_planned_family')]:
    assert np.allclose(ind[a],v.loc[ind.index,b],rtol=1e-11,atol=1e-13),(a,b)
ind17=pd.read_csv(O/'independent/exploratory_17_test_sensitivity.csv').set_index(['hypothesis','x','y'])
v17=pd.read_csv(F/'survey/exploratory_17_test_sensitivity.csv').set_index(['hypothesis','x','y'])
assert np.allclose(ind17.q_bh_17,v17.loc[ind17.index,'q_bh_17_test_sensitivity'],rtol=1e-11,atol=1e-13)
for p in (F/'survey').glob('*.csv'):
    if p.stem in ['exploratory_correlations','exploratory_17_test_sensitivity','scale_reliability']:continue
    old=O/'baseline_run/survey'/p.name
    assert p.read_bytes()==old.read_bytes(),p.name
for p in (F/'classroom').glob('*.csv'):
    assert p.read_bytes()==(O/'baseline_run/classroom'/p.name).read_bytes(),p.name
initial=json.loads((O/'independent/manifest.json').read_text(encoding='utf-8'))
zip0=R/'work/repository/agent_survey_replication_v1.0.zip'
assert sha(zip0)==initial['inputs'][str(zip0)]
assert sha(R/'work/current_manuscript.tex')==sha(Path(r'C:\Users\EKKE\Downloads\EMSE_Article_hybrid_v2.6.3.tex'))
figs=[p for p in (F/'figures').iterdir() if p.is_file()]
(O/'figure_sha256.json').write_text(json.dumps({p.name:sha(p) for p in figs},indent=2),encoding='utf-8')
assert len(list((F/'figures').glob('fig_*.pdf')))==4
# Validate each packaged source byte matches the final executed manifest.
run=json.loads((F/'run_manifest.json').read_text(encoding='utf-8'))
for rel,h in run['code_sha256'].items():assert sha(V/rel)==h,rel
assert sha(V/'config/analysis_plan.json')==run['analysis_plan_sha256']
assert sha(V/'config/codebook.json')==run['codebook_sha256']
changes=[]
for p in sorted(V.rglob('*')):
    if not p.is_file() or any(k in p.parts for k in ['__pycache__','.pytest_cache','validation']):continue
    q=B/p.relative_to(V)
    if q.is_file() and p.suffix in ['.py','.json','.md','.cff'] and p.read_bytes()!=q.read_bytes():
        changes.extend(difflib.unified_diff(q.read_text(encoding='utf-8').splitlines(True),p.read_text(encoding='utf-8').splitlines(True),fromfile='v1.0/'+p.relative_to(V).as_posix(),tofile='v1.1/'+p.relative_to(V).as_posix()))
(O/'v1.0_to_v1.1.patch').write_text(''.join(changes),encoding='utf-8')
validation=f'''# Final executed validation

- Original unmodified v1.0 tests: **31 passed**.
- Final corrected v1.1 tests: **33 passed** (`v11_final_tests.txt`), including exact same-count classroom mutation rejection and independently audited H19/H16/FDR regression checks. None skipped in this local run.
- Full final pipeline, professional public205 plus exact classroom98: success, `v11_final/`.
- Full final pipeline, professional raw230 plus classroom raw103: success, `v11_final_raw/`.
- **{len(checks)} aggregate CSV tables byte-identical** across the final public/cleaned and raw replays. Exclusion/count-issue logs use different source row numbers and are deliberately excluded from equality testing. Both cleaning fingerprints match.
- All16 n/rho/p/q values agree with the independent implementation (tolerance1e-11 relative/1e-13 absolute); all17-family sensitivity q-values agree. Non-H19 survey tables and all classroom CSV tables remain byte-identical to fresh v1.0 baseline results. The only intended changes to existing survey estimates are H19 reliability/correlations and full-family BH q-values.
- Four manuscript-named PDFs and matching PNGs regenerated, plus five compatibility PNGs. The four layouts were visually inspected for clipping/legibility and their labels/proportions checked against source tables. Q23 label now states cross-module tasks need more correction, avoiding an implied temporal increase. Original manuscript PDF figure binaries were unavailable, so their staleness is unresolved.
- Final executed source/config SHA-256 values were checked against packaged source bytes. Original v1.0 ZIP SHA-256 **{sha(zip0)}** unchanged. Supplied manuscript SHA-256 **{sha(R/'work/current_manuscript.tex')}** unchanged.
- Current-TeX435-check reconciliation is separate from the pipeline's explicitly historical150-target comparator. Final legacy comparator has58 differences, including two newly computable H19 values; this does not replace the current audit count117.
- No input dataset edits, manuscript edits, repository push, external publication, or classroom respondent-data redistribution occurred. The GitHub clone is still clean.

The bundle is an audited reconstruction, not an exact reproduction of every printed number. Unresolved historical H14 controls, H21 family inconsistency, original scoring provenance, original figure binaries, unspecified classroom collaborator scale and missing exact public classroom download remain explicitly documented.
'''
(O/'FINAL_VALIDATION.md').write_text(validation,encoding='utf-8')
(O/'audit_code').mkdir(exist_ok=True)
for name in ['independent_audit.py','history_checks.py','reconcile.py','verify_independent.py','write_reports.py','prepare_v11.py','finalize_docs.py','package_audit.py']:
    shutil.copy2(R/'work'/name,O/'audit_code'/name)
(O/'audit_code/README.md').write_text('''# Audit source record

These are exact copies of scripts executed in the audit workspace; they are preserved as evidence, not a second installable package. `independent_audit.py` contains no imports from the replication estimators and no manuscript target values. `reconcile.py` separately transcribes/parses current TeX claims for comparison. SHA-256 of executed independent source is in ../independent/manifest.json.

To recreate the audit workspace, place these scripts in work/ under a chosen workspace root. Unpack the unchanged v1.0 ZIP as work/baseline/agent_survey_replication and clone the frozen repository as work/repository. Supply work/current_manuscript.tex, work/survey_raw230.csv and the checksum-verified cleaned98/raw103 files in work/classroom_source. Historical diagnostics additionally use work/survey_raw229.csv exported unchanged from its original workbook. Install the pinned requirements into your environment. Run the baseline pipeline to outputs/baseline_run and raw replay to outputs/baseline_raw_replay, then run independent_audit.py, history_checks.py, verify_independent.py, reconcile.py, write_reports.py in that order from the workspace root. prepare_v11.py is the one-time documented copy/config migration. Local original-path hash checks in finalize_docs.py/package_audit.py are session-specific and should be replaced by the archived hashes if reproducing elsewhere.

The installable v1.1 pipeline is at the archive's root; use its README for ordinary reruns. No respondent input files are included here. Python dependencies can be installed normally; the audit used a workspace-local target directory because system Python was not on PATH.
''',encoding='utf-8')
reports=['STATISTICAL_AUDIT.md','H16_AUDIT.md','CODE_MANUSCRIPT_MISMATCHES.md','MANUSCRIPT_CORRECTIONS.md','FINAL_VALIDATION.md','manuscript_statistical_reconciliation.csv','current_manuscript_numeric_line_inventory.csv','independent_crosscheck.csv','source_provenance_sha256.json','figure_sha256.json','v11_raw_replay_verification.csv','baseline_tests.txt','v11_final_tests.txt','v1.0_to_v1.1.patch']
# Freeze new code-tree checksums, excluding caches and checksum file itself.
files=[p for p in sorted(V.rglob('*')) if p.is_file() and not any(c in p.parts for c in ['__pycache__','.pytest_cache']) and p.name!='SHA256SUMS.txt']
(V/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.relative_to(V).as_posix()}\n' for p in files),encoding='utf-8')
archive=O/'agent_survey_replication_v1.1.zip'; assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[V/'SHA256SUMS.txt']:z.write(p,'agent_survey_replication/'+p.relative_to(V).as_posix())
    for name in reports:z.write(O/name,'agent_survey_replication/audit/'+name)
    for directory in ['independent','audit_code','v11_final','v11_final_raw','baseline_run','baseline_raw_replay']:
        for p in sorted((O/directory).rglob('*')):
            if p.is_file():z.write(p,'agent_survey_replication/audit/'+p.relative_to(O).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
(O/'agent_survey_replication_v1.1.zip.sha256').write_text(sha(archive)+'  '+archive.name+'\n',encoding='utf-8')
print('Final replay identical tables:',len(checks)); print('Archive:',archive.name,'bytes:',archive.stat().st_size,'SHA256:',sha(archive))
