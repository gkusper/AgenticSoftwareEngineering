from pathlib import Path
import pandas as pd
import numpy as np
import json
R=Path(__file__).resolve().parent.parent; O=R/'outputs'; rows=[]
specs=[('item_descriptives','survey/item_descriptives','item',['n','count','proportion','ci_low','ci_high','median','disagree_proportion']),
 ('midpoint_tests','survey/midpoint_tests','item',['n','statistic','p','p_holm']),
 ('scale_reliability','survey/scale_reliability','scale',['n','alpha']),
 ('supplemental_correlations','survey/supplemental_correlations_unadjusted',['x','y'],['n','rho','p']),
 ('friedman_tests','survey/friedman_tests','matrix',['n','statistic','p','kendall_w']),
 ('hiring_pairwise','survey/hiring_pairwise','item',['n','p','p_holm']),
 ('subgroup_descriptives','survey/subgroup_descriptives',['split','level','item'],['n','count','proportion','group_total_n']),
 ('subgroup_tests','survey/subgroup_tests',['split','item'],['p','q_bh_within_split']),
 ('classroom_comparisons','classroom/primary_outcomes','outcome',['n_notebook','n_unstructured','mean_notebook','mean_unstructured','sd_notebook','sd_unstructured','p','cohen_d','p_holm','mann_whitney_p']),
 ('classroom_reliability','classroom/scale_reliability','scale',['n','alpha'])]
for independent,baseline,keys,cols in specs:
    a=pd.read_csv(O/'independent'/f'{independent}.csv').set_index(keys); b=pd.read_csv(O/'baseline_run'/f'{baseline}.csv').set_index(keys)
    idx=a.index.intersection(b.index); idx=[v for v in idx if not b.loc[v,cols].isna().all()]
    for col in cols:
        av=a.loc[idx,col].astype(float); bv=b.loc[idx,col].astype(float)
        passed=np.allclose(av,bv,rtol=1e-10,atol=1e-12,equal_nan=True)
        rows.append(dict(table=independent,column=col,rows=len(idx),passed=passed,max_abs_difference=float(abs(av-bv).max())))
        assert passed,(independent,col)
pd.DataFrame(rows).to_csv(O/'independent_crosscheck.csv',index=False)
print('Independent vs v1.0 column checks',len(rows),'PASS; scalar values',sum(r['rows'] for r in rows))
