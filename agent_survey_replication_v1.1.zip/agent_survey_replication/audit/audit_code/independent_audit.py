"""Independent calculations; no imports from replication and no manuscript targets in estimation."""
from pathlib import Path
import json, hashlib, re, csv, platform, importlib.metadata
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.proportion import proportion_confint
from statsmodels.miscmodels.ordinal_model import OrderedModel
import statsmodels.api as sm

ROOT=Path(__file__).resolve().parent.parent
BASE=ROOT/'work/baseline/agent_survey_replication'
OUT=ROOT/'outputs/independent'; OUT.mkdir(exist_ok=True,parents=True)
book=json.loads((BASE/'config/codebook.json').read_text(encoding='utf-8'))
plan=json.loads((BASE/'config/analysis_plan.json').read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def norm(v): return re.sub(r'\s+',' ',str(v)).strip()
def load(p):
    with Path(p).open(encoding='utf-8-sig',newline='') as f:
        delimiter=csv.Sniffer().sniff(f.read(20000),delimiters=',;\t').delimiter
    d=pd.read_csv(p,sep=delimiter,dtype=str,keep_default_na=False).map(norm)
    d.columns=[norm(c) for c in d.columns]
    return d
def mapped(p,kind):
    d=load(p); return pd.DataFrame({k:d[v['header']] for k,v in book[kind].items() if v['header'] in d})
survey=BASE/'data/raw/survey.csv'
public=mapped(survey,'survey'); raw=mapped(ROOT/'work/survey_raw230.csv','survey')
rowhash=lambda r:hashlib.sha256(json.dumps(r.tolist(),ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
h=raw.apply(rowhash,axis=1); block=h==plan['survey']['documented_excluded_answer_block']['sha256']
remaining=raw.loc[~block].reset_index(drop=True)
assert len(raw)==230 and block.sum()==25 and remaining.equals(public), 'RAW/PUBLIC DISAGREEMENT: STOP'
eligible=public.Q39==plan['survey']['eligible_provenance']; d=public.loc[eligible].copy()
assert len(d)==200
provenance=pd.read_csv(ROOT/'work/repository/PROVENANCE_EXCLUSIONS.csv')
assert list(public.index[~eligible]+1)==provenance.public_workbook_data_row_1_based.tolist()
assert public.loc[~eligible,'Q39'].tolist()==provenance.Q39_response.tolist()
pd.DataFrame({'raw_data_row':raw.index+1,'answer_sha256':h,'duplicate_block_removed':block,
 'provenance_eligible':raw.Q39==plan['survey']['eligible_provenance'],
 'included':~block & (raw.Q39==plan['survey']['eligible_provenance'])}).to_csv(OUT/'raw_row_decisions.csv',index=False)
pd.DataFrame({'public_data_row':public.index+1,'Q39':public.Q39,'included':eligible}).to_csv(OUT/'public_row_decisions.csv',index=False)
x=pd.DataFrame(index=d.index); coding=[]
for k,v in book['survey'].items():
    if 'mapping' in v:
        unknown=set(d[k])-set(v['mapping'])-set(book['missing_labels'])
        assert not unknown,(k,unknown)
        x[k]=d[k].map(v['mapping']).astype(float)
        for label in sorted(set(d[k])|set(v['mapping'])):
            coding.append(dict(item=k,header=v['header'],category=label,code=v['mapping'].get(label),
                missing=label not in v['mapping'],count=int(d[k].eq(label).sum()),valid_n=int(x[k].notna().sum()),
                direction='Higher = more agreement/frequency/importance/ordered category, not necessarily desirable'))
    else:
        for label,n in d[k].value_counts(dropna=False).items():
            coding.append(dict(item=k,header=v['header'],category=label,code='',missing=label=='',count=n,
                valid_n=int(d[k].ne('').sum()),direction='Nominal; no ordinal score'))
pd.DataFrame(coding).to_csv(OUT/'ordinal_coding_and_missing.csv',index=False)
def save(name,rows): pd.DataFrame(rows).to_csv(OUT/(name+'.csv'),index=False,float_format='%.15g')
def corr(a,b):
    z=pd.concat([a,b],axis=1).dropna(); r,p=stats.spearmanr(z.iloc[:,0],z.iloc[:,1]); return dict(n=len(z),rho=r,p=p)
def alpha(z):
    z=z.dropna(); k=z.shape[1]; return dict(n=len(z),alpha=k/(k-1)*(1-z.var().sum()/z.sum(axis=1).var()))
def desc(a):
    a=a.dropna(); n=len(a); count=int(a.ge(4).sum()); lo,hi=proportion_confint(count,n,method='wilson')
    return dict(n=n,count=count,proportion=count/n,ci_low=lo,ci_high=hi,median=a.median(),disagree_proportion=a.le(2).mean())
save('item_descriptives',[dict(item=k,**desc(x[k])) for k in x if book['survey'][k]['scale'] in ['agreement','frequency','importance','access']])
mid=[]
for k in plan['survey']['primary_midpoint_family']:
    a=x[k].dropna(); t=stats.wilcoxon(a-3,zero_method='wilcox',method='approx',correction=False)
    mid.append(dict(item=k,n=len(a),statistic=t.statistic,p=t.pvalue))
mid=pd.DataFrame(mid); mid['p_holm']=multipletests(mid.p,method='holm')[1]; save('midpoint_tests',mid)
scales={k:v['items'] for k,v in plan['survey']['scales'].items() if v['items']}
scales['traditional_engineering']=['Q36_fundamentals','Q36_unaided','Q36_testing','Q36_architecture','Q36_problem_solving']
scales['ai_literacy']=['Q36_assistants','Q36_agents']
reli=[]
for k,items in scales.items():
    x[k]=x[items].mean(axis=1,skipna=False)
    reli.append(dict(scale=k,items=';'.join(items),**alpha(x[items])))
save('scale_reliability',reli)
pairs=plan['survey']['exploratory_pairs']
ex=pd.DataFrame([dict(hypothesis=h,x=a,y=b,**corr(x[a],x[b])) for h,a,b in pairs])
ex['q_bh_16']=multipletests(ex.p,method='fdr_bh')[1]; ex['survives']=ex.q_bh_16<.05
save('exploratory_correlations',ex)
dynamic=dict(hypothesis='H21',x='Q6',y='Q38_dynamic',**corr(x.Q6,x.Q38_dynamic))
ex17=pd.concat([ex[['hypothesis','x','y','n','rho','p']],pd.DataFrame([dynamic])],ignore_index=True)
ex17['q_bh_17']=multipletests(ex17.p,method='fdr_bh')[1]; save('exploratory_17_test_sensitivity',ex17)
supp=[('H2','Q21','Q22'),('H3','Q23','Q19'),('H3','Q23','Q20'),('H4','Q25','Q33'),('H7','Q32_same','Q32_human'),('H8','Q34','Q35'),('H11','Q30','Q31')]
save('supplemental_correlations',[dict(hypothesis=h,x=a,y=b,**corr(x[a],x[b])) for h,a,b in supp])
partial=[]
for h,a,b in [('H15','orchestration','verification'),('H17','Q21','Q34')]:
    z=x[[a,b,'Q5','Q1','Q6']].dropna().rank(); design=sm.add_constant(z[['Q5','Q1','Q6']]);
    r=stats.pearsonr(sm.OLS(z[a],design).fit().resid,sm.OLS(z[b],design).fit().resid).statistic
    df=len(z)-5; p=2*stats.t.sf(abs(r*np.sqrt(df/(1-r*r))),df)
    partial.append(dict(hypothesis=h,n=len(z),rho=r,p=p,controls='Q5;Q1;Q6',status='Reconstructed sensitivity'))
save('partial_correlations',partial)
models=[]
for target in ['Q22','Q23']:
    z=x[[target,'contract','Q5','Q1','Q6']].dropna()
    fit=OrderedModel(z[target],z[['contract','Q5','Q1','Q6']],distr='logit').fit(method='bfgs',disp=False,maxiter=1000)
    models.append(dict(outcome=target,n=len(z),beta=fit.params['contract'],p=fit.pvalues['contract'],status='Reconstructed; historical adjustment set unknown'))
save('ordinal_logit',models)
fried=[]
for name,items in [('verification_artifacts',plan['survey']['artifact_items']),('hiring_priorities',plan['survey']['hiring_items'])]:
    z=x[items].dropna(); t=stats.friedmanchisquare(*[z[k] for k in items]); fried.append(dict(matrix=name,n=len(z),statistic=t.statistic,p=t.pvalue,kendall_w=t.statistic/(len(z)*(len(items)-1))))
save('friedman_tests',fried)
hp=[]
for k in plan['survey']['hiring_items']:
    if k=='Q36_agents': continue
    z=x[[k,'Q36_agents']].dropna(); t=stats.wilcoxon(z[k]-z.Q36_agents,method='approx')
    hp.append(dict(item=k,n=len(z),p=t.pvalue,mean_difference=(z[k]-z.Q36_agents).mean()))
hp=pd.DataFrame(hp); hp['p_holm']=multipletests(hp.p,method='holm')[1]; save('hiring_pairwise',hp)
groups={'experience':pd.Series(np.where(x.Q1<=3,'le10','gt10'),index=x.index),
 'ai_use':pd.Series(np.where(x.Q5==5,'daily','less_than_daily'),index=x.index),
 'org_size':x.Q6.map(lambda v:'le50' if v<=3 else '51to250' if v==4 else 'gt250' if pd.notna(v) else np.nan)}
sg=[]; st=[]
for split,g in groups.items():
    for k in plan['survey']['core_items']:
        samples=[]
        for level in g.dropna().unique():
            a=x.loc[g==level,k]; samples.append(a.dropna()); sg.append(dict(split=split,level=level,item=k,group_total_n=len(a),**desc(a)))
        t=stats.mannwhitneyu(*samples,method='asymptotic',alternative='two-sided',use_continuity=True) if len(samples)==2 else stats.kruskal(*samples)
        st.append(dict(split=split,item=k,p=t.pvalue))
st=pd.DataFrame(st); st['q_bh_within_split']=st.groupby('split').p.transform(lambda p:multipletests(p,method='fdr_bh')[1]); st['q_bh_global']=multipletests(st.p,method='fdr_bh')[1]
save('subgroup_tests',st); save('subgroup_descriptives',sg)
z=x[['Q1','Q37']].dropna(); a=((z.Q1<=3)&(z.Q37>=4)).sum(); b=((z.Q1<=3)&(z.Q37<4)).sum(); c=((z.Q1>3)&(z.Q37>=4)).sum(); e=((z.Q1>3)&(z.Q37<4)).sum()
od=a*e/(b*c); lo,hi=np.exp(np.log(od)+np.array([-1,1])*stats.norm.ppf(.975)*np.sqrt(1/a+1/b+1/c+1/e))
save('H18_odds',[dict(a=a,b=b,c=c,d=e,odds_ratio=od,ci_low=lo,ci_high=hi,p=stats.fisher_exact([[a,b],[c,e]]).pvalue)])
sens=[]
for minimum in [1,4,7]:
    v=x[scales['verification']].mean(axis=1).where(x[scales['verification']].notna().sum(axis=1)>=minimum)
    sens.append(dict(variant=f'Q32 missing; mean >= {minimum}/7 items',target='verification',**corr(x.Q5,v)))
for fill in [1,0]:
    v=x[scales['verification']].fillna(fill).mean(axis=1)
    sens.append(dict(variant=f'INVALID Q32 missing filled with {fill}',target='verification',**corr(x.Q5,v)))
for fill in [None,1,0]:
    y=x.Q24 if fill is None else x.Q24.fillna(fill)
    sens.append(dict(variant='Q24 missing excluded' if fill is None else f'INVALID Q24 missing filled with {fill}',target='Q24',**corr(x.Q5,y)))
for target in ['Q21','Q22']:
    sens.append(dict(variant='Ordinal pairwise complete',target=target,**corr(x.Q5,x[target])))
save('H16_sensitivity',sens)
save('demographics',[dict(item=k,category=label,count=count,proportion=count/200) for k in ['Q1','Q3','Q4','Q5','Q6','Q8','Q9','Q11'] for label,count in d[k].value_counts().items()])
# Validate additional descriptive outputs independently using exact response boundaries.
baseline_cat=pd.read_csv(ROOT/'outputs/baseline_run/survey/categorical_summaries.csv').set_index('measure')
for measure,k,threshold in [('multiple_agents','Q16',2),('cross_model_used','Q24',4),('provider_interruption_ever','Q30',2),('provider_switched','Q31',1),('provider_switch_difficult','Q31',2)]:
    a=x[k].dropna(); assert int(a.ge(threshold).sum())==baseline_cat.loc[measure,'count']; assert len(a)==baseline_cat.loc[measure,'n']
wf=pd.read_csv(ROOT/'outputs/baseline_run/survey/workforce_factors.csv')
for rr in wf.to_dict('records'):
    a=d.loc[d.Q9.str.startswith('Yes,'),'Q10']
    count=a.map(lambda s: bool(re.search(r'(?:^|, )'+re.escape(rr['factor'])+r'(?:$|, )',s))).sum()
    assert count==rr['count'] and len(a)==rr['n']
senior_labels=[v for v in book['multiple_choice']['Q2'] if v!='Other technical role']
assert int(d.Q2.map(lambda s:any(re.search(r'(?:^|, )'+re.escape(v)+r'(?:$|, )',s) for v in senior_labels)).sum())==164
# Independently reconstruct classroom values from the exact checksum-verified source.
cp=ROOT/'work/classroom_source/structured-vibe-coding-v3-cleaned-primary-98.csv'
assert hashlib.md5(cp.read_bytes()).hexdigest()=='c392e1698e3627e991e626f3f762880c'
cr=mapped(cp,'classroom'); cl=pd.DataFrame({k:pd.to_numeric(cr[k].replace(book['missing_labels'],np.nan),errors='raise') for k in plan['classroom']['screen_numeric_items']})
g=cr.C002.map(plan['classroom']['workflow_labels']); assert g.value_counts().to_dict()=={'Notebook':60,'Unstructured':38}
for name,k in [('completed_crs','C016'),('prompts','C014'),('passed_tests','C017'),('failed_tests','C018')]:
    v=cl[k]; cl[name]=v.where(v>=0).where(v==np.floor(v))
    if name=='completed_crs': cl[name]=cl[name].where(cl[name]<=8)
cl['completed_per_prompt']=cl.completed_crs/cl.prompts.where(cl.prompts>0)
cl['test_success_ratio']=cl.passed_tests/(cl.passed_tests+cl.failed_tests).where(cl.passed_tests+cl.failed_tests>0)
for name in ['quality_gate','human_ownership']:
    cl[name]=cl[plan['classroom'][name]['items']].mean(axis=1,skipna=False)
save('classroom_reliability',[dict(scale=k,**alpha(cl[plan['classroom'][k]['items']])) for k in ['quality_gate','human_ownership']])
rows=[]
for name in plan['classroom']['primary_outcomes']+['completed_crs','human_ownership']:
    a=cl.loc[g=='Notebook',name].dropna(); b=cl.loc[g=='Unstructured',name].dropna(); pool=np.sqrt(((len(a)-1)*a.var()+(len(b)-1)*b.var())/(len(a)+len(b)-2))
    rows.append(dict(outcome=name,n_notebook=len(a),n_unstructured=len(b),mean_notebook=a.mean(),mean_unstructured=b.mean(),sd_notebook=a.std(),sd_unstructured=b.std(),p=stats.ttest_ind(a,b,equal_var=False).pvalue,cohen_d=(a.mean()-b.mean())/pool,mann_whitney_p=stats.mannwhitneyu(a,b,alternative='two-sided',method='asymptotic').pvalue))
ct=pd.DataFrame(rows); ct['p_holm']=np.nan; ct.loc[:2,'p_holm']=multipletests(ct.loc[:2,'p'],method='holm')[1]; save('classroom_comparisons',ct)
save('classroom_associations',[dict(target=k,**corr(cl.quality_gate,cl[k])) for k in ['C020','C021','test_success_ratio','failed_tests']])
save('classroom_correlation_method_sensitivity',[dict(target='C020',method='Pearson (not specified Spearman)',n=98,r=stats.pearsonr(cl.quality_gate,cl.C020).statistic,p=stats.pearsonr(cl.quality_gate,cl.C020).pvalue)])
cl['notebook']=(g=='Notebook').astype(float); models=[]
for target in plan['classroom']['primary_outcomes']+['human_ownership']:
    z=cl[[target,'notebook']+plan['classroom']['controls']].dropna(); f=sm.OLS(z[target],sm.add_constant(z[['notebook']+plan['classroom']['controls']])).fit(cov_type='HC3')
    models.append(dict(outcome=target,n=len(z),beta=f.params.notebook,p=f.pvalues.notebook))
save('classroom_HC3',models)
save('classroom_secondary_all_items',[dict(item=k,header=book['classroom'][k]['header'],n=cl[k].count(),mean=cl[k].mean()) for k in plan['classroom']['screen_numeric_items']])
save('classroom_test_denominators',[dict(group=level,n=int((g==level).sum()),minimum=(cl.passed_tests+cl.failed_tests)[g==level].min(),median=(cl.passed_tests+cl.failed_tests)[g==level].median(),maximum=(cl.passed_tests+cl.failed_tests)[g==level].max(),distinct=(cl.passed_tests+cl.failed_tests)[g==level].nunique()) for level in ['Notebook','Unstructured']])
manifest={'python':platform.python_version(),'packages':{p:importlib.metadata.version(p) for p in ['numpy','pandas','scipy','statsmodels','matplotlib','pytest']},'repository_branch':'main','repository_commit':'9ce6112d3838dd57a242aa80dafe565e32a1c6e6','repository_status_at_clone':'clean','inputs':{str(p):sha(p) for p in [survey,ROOT/'work/survey_raw230.csv',cp,ROOT/'work/classroom_source/structured-vibe-coding-v3-raw-103.csv',ROOT/'work/current_manuscript.tex',ROOT/'work/repository/agent_survey_replication_v1.0.zip']},'raw_to_public_exact_questionnaire_match':True,'independent_code_sha256':sha(__file__)}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(ex.to_string(index=False)); print(pd.DataFrame(sens).to_string(index=False)); print(st[st.q_bh_within_split<.05].to_string(index=False))
