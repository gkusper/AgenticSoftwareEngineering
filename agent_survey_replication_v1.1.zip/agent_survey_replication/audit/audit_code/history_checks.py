from pathlib import Path
import json, csv, hashlib, re
import pandas as pd
import numpy as np
from scipy.stats import spearmanr
R=Path(__file__).resolve().parent.parent
B=R/'work/baseline/agent_survey_replication'
book=json.loads((B/'config/codebook.json').read_text(encoding='utf-8'))
plan=json.loads((B/'config/analysis_plan.json').read_text(encoding='utf-8'))['survey']
def read(p):
    with p.open(encoding='utf-8-sig') as f: sep=csv.Sniffer().sniff(f.read(20000),delimiters=',;\t').delimiter
    z=pd.read_csv(p,sep=sep,keep_default_na=False,dtype=str).map(lambda v:re.sub(r'\s+',' ',v).strip())
    z.columns=[re.sub(r'\s+',' ',c).strip() for c in z]
    return pd.DataFrame({k:z[v['header']] for k,v in book['survey'].items()})
old=read(R/'work/survey_raw229.csv'); new=read(B/'data/raw/survey.csv')
hashrow=lambda v:hashlib.sha256(json.dumps(v.tolist(),ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
counts=old.apply(hashrow,axis=1).value_counts()
old=old.loc[old.apply(hashrow,axis=1)!=counts.index[0]]
print('229 source removed largest answer-identical block',counts.iloc[0],'; remaining',len(old))
print('old/new identical rows',len(set(old.apply(hashrow,axis=1))&set(new.apply(hashrow,axis=1))))
rows=[]
for version,z in [('local_229',old),('public_205',new)]:
    z=z[z.Q39==plan['eligible_provenance']]
    x=pd.DataFrame({k:z[k].map(v['mapping']) for k,v in book['survey'].items() if 'mapping' in v})
    items=plan['scales']['verification']['items']
    for name,y in [('Q24',x.Q24),('verification_complete',x[items].mean(axis=1,skipna=False)),('verification_fill1_INVALID',x[items].fillna(1).mean(axis=1))]:
        pair=pd.concat([x.Q5,y],axis=1).dropna(); t=spearmanr(pair.iloc[:,0],pair.iloc[:,1]); rows.append(dict(version=version,analysis_n=len(z),target=name,n=len(pair),rho=t.statistic,p=t.pvalue))
pd.DataFrame(rows).to_csv(R/'outputs/independent/historical_diagnostics.csv',index=False)
print(pd.DataFrame(rows).to_string(index=False))
# Compare raw replay tables (exclude logs containing source record numbers).
diff=[]
for p in (R/'outputs/baseline_run').glob('*/*.csv'):
    if p.stem in ['exclusions','count_cleaning']: continue
    q=R/'outputs/baseline_raw_replay'/p.relative_to(R/'outputs/baseline_run')
    diff.append(dict(table=str(p.relative_to(R/'outputs/baseline_run')),byte_identical=p.read_bytes()==q.read_bytes()))
pd.DataFrame(diff).to_csv(R/'outputs/independent/raw_replay_comparison.csv',index=False)
assert all(v['byte_identical'] for v in diff)
print('Raw replay identical tables:',len(diff))
