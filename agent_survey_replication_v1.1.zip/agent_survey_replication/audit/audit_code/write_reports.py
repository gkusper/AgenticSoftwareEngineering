from pathlib import Path
import json
import pandas as pd
R=Path(__file__).resolve().parent.parent; O=R/'outputs'; I=O/'independent'
def t(name):return pd.read_csv(I/(name+'.csv'))
def md(d):
    d=d.copy().fillna('')
    def f(v):return (f'{v:.9g}' if isinstance(v,float) else str(v)).replace('|','/').replace('\n',' ')
    return '| '+' | '.join(d.columns)+' |\n| '+' | '.join(['---']*len(d.columns))+' |\n'+'\n'.join('| '+' | '.join(f(v) for v in row)+' |' for row in d.itertuples(index=False,name=None))+'\n'
rec=pd.read_csv(O/'manuscript_statistical_reconciliation.csv'); counts=rec.status.value_counts(); ex=t('exploratory_correlations')
manifest=json.loads((I/'manifest.json').read_text(encoding='utf-8'))
H16='''# H16 independent audit

Authority: supplied EMSE_Article_hybrid_v2.6.3.tex, not the old target JSON. Dataset: public 205-row release, exact Q39 eligibility, N=200. All four estimates below are from respondent records; manuscript values never enter estimation.

## Coding and estimands

Q5: Never=1; Less than monthly=2; Monthly=3; Weekly=4; Daily or almost daily=5. Valid n=200. Higher means more frequent professional AI use.

Q21 and Q22: Strongly disagree=1; Disagree=2; Neither agree nor disagree=3; Agree=4; Strongly agree=5. N/A/insufficient experience is missing. Valid n=177 and 171 respectively. Q22 is agreement that senior review/debugging/repair work **per accepted change increased**. It is neither the level of workload nor total workload.

Q24: had not considered before survey=1; knew but had not considered using=2; considered but not used=3; occasionally used=4; regularly used=5. Missing/insufficient experience excluded; valid n=165. This ordered variable mixes awareness, consideration and use; call it the ordered cross-model-review item, not a continuous usage count.

Each of seven Q32 generation items: Never=1; Rarely=2; Sometimes=3; Often=4; Almost always=5. N/A/insufficient direct experience is missing, never 1 or 0. Higher means more frequent generation of the stated artifact. These seven exclude same-generator practice and human review.

Verification items: unit tests, frontend tests, backend tests, integration tests, runtime assertions, pre/postconditions and formal specifications. The frozen executable convention is an unweighted mean **requiring all seven valid responses**; n=124. This is a mean generation-frequency score, not a count of distinct practices. The manuscript specifies itemwise missing handling and points to source for composites; the v1.0 METHODS acknowledges that listwise scoring is a reconstruction, not recovered historical proof. Do not silently substitute an available-item mean. If the authors intended another minimum-item rule, these composite comparisons become UNRESOLVED until that rule is frozen.

For each target, intersect valid Q5 and target rows, assign average ranks to ties, compute Pearson correlation of those ranks (Spearman rho). Two-sided p uses the standard asymptotic t transform, df=n−2. BH uses **all 16 primary raw p-values**, including the now-defined H19 tests: sort p, calculate 16*p/rank, take reverse cumulative minima and cap at 1. No pre-rounding or significance filtering. Partial/logit sensitivities are outside this primary family.

## Results

'''+md(ex[ex.hypothesis=='H16'][['x','y','n','rho','p','q_bh_16','survives']])+'''
The manuscript’s .289 and −.189 match printed precision. Under the frozen complete-item rule, .403 must become **.398** and .317 must become **.319**. All four survive the reconstructed BH family. See the explicit 17-test family sensitivity in `independent/exploratory_17_test_sensitivity.csv`; all four also survive there.

## Missing-data sensitivities (not target-fitting)

'''+md(t('H16_sensitivity'))+'''
The suspect .403 is reproduced to displayed precision by the **invalid** choice of replacing missing Q32 responses with Never=1: rho=.402885209718143. This changes the sample from 124 complete seven-item respondents to all 200 and treats lack of applicability/experience as observed non-use. It contradicts the manuscript and is **not what the v1.0 encoder does**. Numerical agreement identifies a plausible mechanism, not proof of the historical author's actual code.

The .398 value is .398384209772328 using valid complete items. Filling with zero, another invalid choice, also rounds to .398 (.397765...), illustrating why matching a rounded target alone is not evidence of the right method. Available-item means are defensible only if declared in advance with a minimum answered-item rule; here they yield .240847 (at least one) or .277254 (at least four), and are sensitivities, not replacements.

## Historical cross-check

'''+md(t('historical_diagnostics'))+'''
The local AI_Coding_Agents_229.xlsx genuinely has 229 responses, removes a 25-answer-identical block and leaves 199 Q39-eligible records. It is not the frozen N=200 source and differs in more than a final row (only 76 complete questionnaire rows overlap the public205 file). Its Q24 rho is .315991, which rounds to .316, not .317. Neither public205 pairwise coding nor this preserved older file explains .317. Its exact historical origin is **UNRESOLVED**. No respondent deletion, category regrouping, or item-subset search was undertaken to force .317.

## Faithful replacement wording

“More frequent professional AI use was associated with higher reported code-volume growth (rho=.289), a higher mean verification-generation score (rho=.398), higher scores on the ordered cross-model-review item (rho=.319), and weaker agreement that senior review/debugging/repair effort per accepted change had increased (rho=−.189). All four associations survived BH correction in the reconstructed 16-test family. An adaptation account is a hypothesis; these cross-sectional data do not distinguish it from selection or confounding.”

## Reproduction

Exact category counts, missing labels and valid n: `independent/ordinal_coding_and_missing.csv`. Every primary test including n/p/q: `independent/exploratory_correlations.csv`. Independent estimation source is supplied under `audit_code/independent_audit.py`; its input and code hashes are in `independent/manifest.json`. The corrected pipeline yields the same H16 rho/p as v1.0; H19 completion changes family q-values. No response values were edited.
'''
(O/'H16_AUDIT.md').write_text(H16,encoding='utf-8')
issues=[
('C01 — H19 executable definitions missing','Current HYPOTHESES.md defines a five-item traditional scale and two-item AI-literacy scale.','config/analysis_plan.json:125–132 has items=null; replication/survey.py:117–126 produces undefined scores.','Both primary tests missing; p=1 placeholders in correction affect all 16 q-values.','Populate exact item sets; retain explicitly documented full-item mean rule (5/5 and 2/2); rerun full BH family. Do not fit .424/.485.'),
('C02 — historical H14 provenance','Manuscript line 580 presents adjusted coefficients without naming reconstructed controls.','config/analysis_plan.json:144; replication/survey.py:177–179 and METHODS explicitly use Q5/Q1/Q6 as a new sensitivity.','The .498/.352 coefficients cannot be certified against an unrecovered historical model; new betas are −.312483 and −.219456.','Do not invent controls or replace historical numbers as an exact reproduction; label new sensitivity, with covariates and n, or remove historical coefficients pending recovery.'),
('C03 — ambiguous H21 family and construct','HYPOTHESES lists formal/static/dynamic/cross-model/interruption (5) but counts H21=4 and total=16.','config/analysis_plan.json:145–227 fixes 16 pairs and Q38_static only at line 214; no combined CI scale is calculated.','Dynamic result omitted from primary family; manuscript CI label .195 is under-specified.','Keep frozen executable 16, report dynamic separately and 17-family sensitivity; author must resolve intended family and item. Do not silently change primary family.'),
('C04 — stale comparison targets','Current TeX is numerical comparison authority.','analysis_pipeline.py:53 reads data/reference/manuscript_targets.json via replication/reporting.py:14–23.','150 old reference checks include a 133-person experience target absent from current table and omit many current cells. Matching that file is not a current manuscript audit.','Preserve old targets as explicitly historical; provide current-TeX reconciliation and input hash. Do not use targets in estimation.'),
('C05 — figures are not the manuscript figure files','TeX lines 394/423/442/462 require fig_likert.pdf, fig_artifacts.pdf, fig_resilience.pdf, fig_hiring.pdf and a diverging core distribution.','replication/figures.py:31–77 produces five horizontal-rate PNG files, not the named four PDFs or the diverging layout.','One-command claim cannot create the figure assets expected by TeX; original figure binaries were not supplied.','Generate named PDF counterparts from the same freshly computed N=200 tables, including diverging distributions and combined resilience panel; preserve original TeX.'),
('C06 — exact classroom provenance not enforced by local loader','Use only the verified exact v3 98-row analysis data.','replication/classroom.py:56–63 validates N and group counts only, unlike survey fingerprint; scripts/download_data.py verifies exact public MD5 on downloads.','A modified local classroom file with same schema/98/60/38 could pass. This audit used the exact MD5 match and is not affected.','Add a frozen semantic fingerprint after classroom cleaning, preserve --allow-data-change as explicit override, and regression-test rejection of modified same-count data.'),
('C07 — method metadata versus historical certainty','Composites and ordinal coding must be specified, not inferred from a target.','config/analysis_plan.json:91–123; METHODS says complete cases/Q16 rank coding reconstructed; quality_gate/human_ownership reconstructed blocks at 392–403.','Current point estimates are conditional on these declared rules; historical identity and alpha acceptability threshold are not fully specified.','Keep reconstruction labels, document full-item rules and Q16 category scores, flag unspecified collaborator composite. Do not tune minimum items.'),
('C08 — public classroom availability claim','Current TeX lines 900–905 says the exact 98-row release is public.','REPRODUCIBILITY.md says DOI pending; current downloader cannot find exact v3 CSV at proposed record.','Local reproducibility succeeds but public end-to-end acquisition is blocked.','Correct availability wording or deposit the exact verified file through the authors’ release process; this audit does not publish respondent data.')]
code='# Code/manuscript mismatches\n\nAudit of untouched v1.0 against supplied current TeX and frozen repository commit. Line references in this report refer to v1.0 unless stated otherwise.\n\n'
for title,requirement,behavior,consequence,fix in issues:
    code+=f'## {title}\n\n- Requirement: {requirement}\n- Current behavior and location: {behavior}\n- Consequence: {consequence}\n- Minimal fix: {fix}\n\n'
code+='''## Checks that passed

`replication/io.py:94–106` maps only named ordinal responses; missing labels are not in the numerical mapping. Q32 N/A is NaN, not Never or zero. Scale directions and full normalized headers agree with the questionnaire. Unknown labels fail. `statistics.py:81–93` uses pairwise complete Spearman; composite scoring and alpha are listwise under the explicitly frozen convention. `survey.py:201–224` separates 14-item BH families by split and also labels the global 42-test sensitivity. Holm uses 17 raw midpoint p-values; BH/ Holm occur before export rounding. Q39 excludes exactly the documented five. No inference is run on N=205 as if it were the eligible sample. Raw replay gives identical final tables.

`statistics.py:67–78` preserves undefined planned tests as p=1 slots only for correction bookkeeping, while exporting missing actual results. That is transparent but was incomplete once H19 definitions became available. No manuscript target file is imported by estimation modules; target constants live in reporting/regression fixtures. The original tests check data/estimator outputs, not tune observations. Q22 full header and chart label retain “per accepted change”; no code comment claiming that a negative coefficient proves less total review work was found. H20 non-significance is not converted into independence by the current code or current manuscript discussion.

## Changes authorized after this audit

Implement C01 and C06, add manuscript figure counterparts for C05, and label C04’s retained historical target comparison clearly. Update stale H19 metadata/documentation and version to 1.1.0. Do not decide the C02 historical model, C03 intended primary family, C07 original missing-item rules or C08 public release by guessing. No manuscript/data edits; no overwrite of v1.0 ZIP. Fresh tests and runs recorded separately.
'''
(O/'CODE_MANUSCRIPT_MISMATCHES.md').write_text(code,encoding='utf-8')
corrections=rec[rec.status=='MISMATCH'][['location','claim_id','manuscript_value','recomputed_value','n','raw_p','adjusted_p_or_q']]
(O/'MANUSCRIPT_CORRECTIONS.md').write_text('# Exact current-manuscript correction ledger\n\nThese are discrepancy checks, not independent scientific errors; repeated claims and separate count/percent checks are retained. Values are unrounded to prevent ambiguity. Round to the manuscript’s chosen display precision after estimation. Composite replacements are conditional on the documented complete-item scoring convention; see audit. H14 historical-model substitutions and unresolved items are deliberately excluded. No TeX was modified.\n\n'+md(corrections)+'\n## Unresolved and method/provenance items\n\n'+md(rec[rec.status.isin(['METHOD MISMATCH','UNRESOLVED'])][['location','claim_id','manuscript_value','recomputed_value','status','notes']]),encoding='utf-8')
exact=int(((rec.status=='PASS')&~rec.manuscript_value.astype(str).str.startswith(('<','>'))).sum())
stat=f'''# Statistical reproducibility audit

Current manuscript: **EMSE_Article_hybrid_v2.6.3.tex**, supplied by the user. Audit date: 2026-09-27. Repository: gkusper/AgenticSoftwareEngineering, branch **main**, commit **9ce6112d3838dd57a242aa80dafe565e32a1c6e6**, clean at clone. The original v1.0 ZIP and supplied TeX are unchanged. Reports are in English to match the manuscript and the requested audit specification.

## A. Executive summary

The paper is **not exactly reproducible as printed**. Cleaning is reproducible, the original implementation mostly handles missing values correctly, and all three primary classroom comparisons reproduce at displayed precision. Numerous professional numbers are stale or inconsistent with the archived observations. H19 missing executable definitions alter FDR decisions; H14 original adjusted-model provenance remains unrecovered.

Current-TeX reconciliation contains **{len(rec)} checks**: **{exact} exact equality checks**, **{counts['PASS']-exact} satisfied threshold assertions**, **{counts['ROUNDING ONLY']} rounding-only differences**, **{counts['MISMATCH']} numerical/logical mismatches**, **{counts['METHOD MISMATCH']} method/provenance mismatch rows**, and **{counts['UNRESOLVED']} unresolved rows**. This is **not** a count of independent scientific errors: repeated claims, CI endpoints, denominators and individual robustness cells are separate checks. “ROUNDING ONLY” means the printed value is correct at its stated precision. “PASS” includes exact equality or satisfaction of an explicitly printed bound. The separate code review has eight issue records, some overlapping these rows and some limitations rather than implementation defects.

Blocked scopes: exact **historical H14 model**, **original figure-binary comparison**, **unspecified AI-as-collaborator scale**, and **public acquisition of exact classroom v3**. Local exact classroom numerical recomputation is **not blocked**: the local release’s CSV MD5 exactly matches the frozen source registry. Intended H21 family and original missing-item scoring choices are unresolved, with separately labelled sensitivities rather than guessed replacements.

### Freeze, execution and independence

- Runtime: Python **{manifest['python']}**, Windows; frozen package versions from v1.0 requirements-dev were installed. Python differs from the original Linux 3.13.5 validation environment; this audit does not claim an identical OS/interpreter. Package versions and all input SHA-256 values are in `independent/manifest.json` and each pipeline run manifest.
- **31/31 original tests passed before code changes**, including the actual professional/classroom integration test (`baseline_tests.txt`). Public survey download MD5 verified. Exact classroom v3 local MD5: **c392e1698e3627e991e626f3f762880c**. The proposed public record does not expose that file.
- Fresh baseline folders: `baseline_run` and `baseline_raw_replay`. Independent script imports no replication estimators and no manuscript targets. **955 scalar outputs** agree with v1.0 across **41 column checks** (`independent_crosscheck.csv`). The old baseline’s 56/150 differences are historical-target checks and are not this audit’s count.
- Raw230 → remove all 25 members of the exact answer-identical block → public205, **every questionnaire value and row order identical** → exclude public data rows **14,25,72,73,159** → N=200. Q39 labels also match PROVENANCE_EXCLUSIONS.csv exactly. Detailed row decisions are retained. Timestamps differ within the duplicate block; “fully identical” should mean answer-identical, excluding timestamps.
- Raw103 → documented screening / unknown workflow exclusions → classroom98. **23 aggregate survey/classroom CSV tables are byte-identical** between public/cleaned and raw runs; source-row exclusion and count-issue logs are intentionally not compared as row positions differ.
- Actual raw source is the locally available 230-response “Responses - Form Responses 1.csv”, matching the archive after deterministic cleaning. `Responses (3).xlsx` and `AI_Coding_Agents_205 (2).xlsx` each also contain 230 responses by sheet inspection. **AI_Coding_Agents_229.xlsx contains 229, not 230**; it is not an alias for this source. Its cleaned eligible n=199 and values differ. The manuscript’s lines 4–5 are stale and should name the verified source or its hash, not infer n from filename.

## B. Critical errors requiring manuscript correction

1. **H16 .403 is consistent with forbidden missing-as-Never coding**; correct frozen full-item result is .398384 (n=124), while .319022 replaces .317 for Q24. This diagnostic does not prove the historical implementation. v1.0 already excludes N/A correctly.
2. **H19 results were absent from executable v1.0**. Exact recovered item sets produce rho=.413736 and .482083, not .424/.485. Full 16-test BH now makes organization-size/interruption q=.048529: “does not survive FDR” is false under this frozen family. Including dynamic Q38 as test 17 leaves that decision significant too.
3. **H14 model provenance is unresolved**. Do not replace printed historical betas as though a new Q5/Q1/Q6 model reproduced them. Explicit reconstructed estimates are beta=−.312483,p=.0249875,n=126 and beta=−.219456,p=.105752,n=132.
4. Basic counts are also wrong, independently of composite choices: independent evidence **175/188=93.1%** (not 92.6), human responsibility **178/200=89.0%** (not 88.5), junior routine displacement **118/174=67.8%** (not 68.4), protected learning tasks **62/156=39.7%** (not 39.1). Apply corrections wherever repeated, including Discussion and external-evidence comparisons.
5. **Classroom correctness association .371 is not reproduced**: Spearman=.435769,p=7.30e−06 (see exact CSV),n=98. Pearson is .455750, so switching to Pearson does not explain .371.
6. Correct experience subgroup totals **110/90**, not 109/91. Teaching categories correctly sum to 199 because **one response is blank**; disclose Missing=1 (0.5%). Do not add one to an observed category.

Every exact replacement—including all changed robustness cells and demographics—is listed in `MANUSCRIPT_CORRECTIONS.md` and the required `manuscript_statistical_reconciliation.csv`. No manuscript was automatically edited.

## C. Critical code/configuration errors

See `CODE_MANUSCRIPT_MISMATCHES.md` for requirement, exact baseline file/line, behavior, consequence and minimal fix. The major unambiguous executable defect is null H19 item sets despite recovered definitions. Local classroom validation checks counts but not the frozen data values; this audit independently verified the correct file, and a semantic fingerprint should be added. Figure generation does not create the four named PDF assets expected by TeX. Stale target metadata must be labelled historical.

The following alleged problems were **not present in v1.0**: Q32 N/A-to-zero/never, reversed ordinal coding, positional header selection, global-only subgroup correction, rounding p before correction, undisclosed global listwise correlation deletion, or estimation from manuscript targets. Keeping these distinctions prevents “fixes” that would corrupt a correct implementation.

## D. H1–H13 audit

All ordinal category-to-code mappings, directions, response counts, observed missing labels and item-valid n—including Q1/Q5/Q6/Q16/Q24/Q32/Q36/Q38/Q39/Q40—are in `independent/ordinal_coding_and_missing.csv`. Q39 is a nominal eligibility item, not an ordinal score. Experience/organization category ranks increase with size; Q16=0..5 denotes category ranks, not estimated agent counts. Q38=0..3 denotes no use/manual/CI/nonblocking or blocking as specified in the exact codebook. Higher agreement on adverse outcomes means more reported difficulty; it is not a universally favourable scale.

H1 and H2 percentages/n/Wilson CI/median and their Holm significance reproduce. H2 Q21–Q22 rho=.0723997,p=.351013,n=168 also reproduces; do not describe its non-significance as absence of an effect. H3’s descriptive values and significance reproduce; its supplemental Q19/Q20 correlations are non-significant. The estimates below use two-sided signed-rank against 3 and the full 17-item Holm family (no sign-test substitution).

'''+md(t('midpoint_tests'))+'''
H4 accountability percentages and rho change (rho=.438897, not .447), while cross-model use 93/165=56.4% reproduces. H5 cost tracking is 129/176=73.3%; the Q27–Q29 range is 67.6–68.1%, alpha=.790407. H6 multi-agent 112/188=59.6%, specialized-agent 120/171=70.2%, and orchestrator agreement/disagreement/median reproduce. H7 unit/backend/frontend/integration percentages reproduce; pre/postconditions=42.9%, assertions=41.1%, formal=37.8%, human review=84.5%. Same-generator use=50.6% reproduces, but association with human review is rho=−.011350,p=.884956,n=165, not −.030/.699.

H8 junior hiring 87/150=58.0% reproduces; Q34/Q35 percentages and correlation change (rho=−.061572,p=.458786). Q35 Holm p=.898796 (display .899), not 1.0, still non-significant. H9 Friedman chi-square=994.265187,df=13,n=155,W=.493432; all seven named pairwise superiority comparisons retain Holm significance. Fundamentals/problem solving/communication/AI-output verification percentages change to 85.5/89.8/82.7/65.3%; unaided reading=79.8 and agent knowledge=28.8 reproduce. Grades and low salary each remain below 6%.

H10 Q37 agreement=34.7%, disagreement=43.0%, median=3, Holm p=.100967 (not .075); no above-midpoint population conclusion follows. H11 interruption=55.7% and switching difficulty=16.1% reproduce, switching=45.7% replaces46.2%; interruption/switching rho=.461333 replaces .468. Access risk 42.0/35.0%,median3 reproduces. H12 robot meanings: AI27.5%, either21.5%, RPA19.0%, unclear18.5%, script13.5%; distinction agreement=75.5%. H13 denominator99 reproduces: restructuring47.5%, market47.5%, non-AI cost42.4%, AI productivity27.3%, direct automation15.2%. These are multi-select attributions, not causal estimates or a test that AI was/is not a primary cause.

'''+md(t('supplemental_correlations'))+'''
## E. H14–H21 audit

Arithmetic mean scores require all frozen items; alpha is raw/unstandardized and listwise. Keep the original/reconstructed distinction: original v1.0 exported no H19 composite results; the corrected definition-based computation supplies both without changing source responses. Acceptable-alpha cutoff is not stated in current TeX; no post-hoc item deletion or scale-selection threshold was invented.

'''+md(t('scale_reliability'))+'\n'+md(ex)+'''
The executable family is H14(2),H15(1),H16(4),H17(1),H18(1),H19(2),H20(1),H21(4). H21=Q6 with formal Q32, static Q38, Q24, Q30. HYPOTHESES additionally lists dynamic Q38, inconsistent with its own total. Hence reconstructed-family q values are conditional, not proof of the original exploratory search or prospective FDR control. Dynamic individually: n=153,rho=.182158,p=.0242227; BH across the explicit 17-member sensitivity yields q=.0274524. Static rho=.216758 concerns the single four-level static-analysis item, **not a combined static/dynamic scale** and not a binary CI indicator. The origin/construct of manuscript .195 is unresolved.

H18 agreement is47/106=44.3% versus20/87=23.0%, OR=2.668644,95%CI1.422031–5.008092; report2.67[1.42,5.01]. H20 correct full-case rho=.157350,p=.0553043,q=.0553043; it is still non-significant, not evidence of independence.

Partial sensitivities and reconstructed H14 models:

'''+md(t('partial_correlations'))+'\n'+md(t('ordinal_logit'))+'''
## F. H16 deep audit

See `H16_AUDIT.md` for encodings, item sets, missing rules, actual n/rho/p/q, complete-item and available-item means, invalid missing-as-1/0 diagnostic, and the 229-source history check. The .403 mechanism is directly demonstrated; .317’s exact source is unresolved. “Adaptation/maturity” is an interpretation, not an independently measured construct tested by these four correlations.

## G. Subgroup robustness audit

All **112 percentage cells** were parsed directly from the current TeX and checked, not borrowed from old manuscript_comparison.csv. Valid group/cell denominators are exported in `independent/subgroup_descriptives.csv`. Group totals are experience110/90; AI use137/63; organization55/41/97. Seven “Not sure” organization answers are excluded only from organization analyses, not from N=200.

The stated within-split BH correction has exactly two significant tests:

'''+md(t('subgroup_tests').query('q_bh_within_split < .05'))+'''
The global 42-test correction is separately reported and does not replace those families. Both survive it too. Several percentages/ranges nevertheless change; use the correction ledger. Integer cells were checked with half-unit rounding, while full precision is retained. No non-significant subgroup test establishes equivalence. The current manuscript already correctly acknowledges this; do not flag an already-correct caveat as an error.

## H. Demographic arithmetic audit

Experience19+49+42+38+20+32=200; at least6 years=132. AI use137+33+13+9+8=200; weekly or more170. Organization6+14+35+41+26+71+7=200. Junior hiring categories sum200. The current experience table is internally consistent; the old target file’s133 total is stale and must not be reinstated.

Degree: MSc60(30.0%) replaces59(29.5%); PhD18(9.0%) replaces19(9.5%). Q9 reduction with unknown affected levels28(14.0%) replaces27(13.5%), mainly junior17(8.5%) replaces18(9.0%). Aggregate reduced-headcount99 is unchanged. University teaching counts146+19+15+11+8=199 correctly describe199 observed answers; one blank adds the missing0.5%. All demographic rows were checked individually, not just totals.

## I. Classroom audit

The exact local v3 CSV checksum is verified and no v4/92 substitute used. Primary results independently reproduced:

'''+md(t('classroom_comparisons'))+'\n'+md(t('classroom_associations'))+'\n'+md(t('classroom_HC3'))+'''
All reported primary means/SDs/Welch/Holm/d and MW p-values match displayed precision. Quality Gate alpha=.696431754,n=98; the stated completed-CR means3.79/3.74 and p=.9072 reproduce. All three HC3 group coefficients remain nominally significant with the six stated covariates; full model n=74/75/75, not98. Course-grade nonresponse and baseline missingness explain this reduced sample. These are associational sensitivities, not randomized effects.

Secondary requirement decomposition4.22(n88), task-card clarification3.98(n90), linked-evidence trust4.12(n98), ownership3.73vs3.30,d=.492, and AI role means4.08/3.17/2.41/2.22 reproduce. “Notebook slowed me down”3.04 is the **notebook subgroup mean**, n57; all valid answers have mean3.00,n74. The subgroup must be stated. The AI-as-collaborator composite item set is absent; no exact test is claimed.

Failed-test counts lack a common denominator: total passed+failed ranges1–125(median15) in notebook and1–104(median16) in unstructured, with28 and24 distinct totals. Thus counts cannot be interpreted as a comparable failure rate or superior objective quality without shared test-suite evidence. Test-success ratio provides a distinct descriptive sensitivity; it does not retroactively standardize original task difficulty or test scope.

Public reproducibility remains blocked for this file despite exact local reproducibility. The manuscript's public DOI claim and repository's pending-deposit statement disagree. No classroom respondent data are republished in the audit deliverables.

## J. Figure audit

Five baseline survey PNGs were regenerated from the exact same fresh N=200 tables; no reuse of archived PNGs. The four original PDFs referenced by TeX were not supplied or present beside the located inputs, so **no original figure is declared stale without seeing it**. The package nevertheless does not generate the named assets or core diverging layout. The corrected package adds four manuscript-named PDFs and inspection PNGs. Fresh figures necessarily display corrected percentages; discrepancies against printed tables are recorded in the ledger. Archived validation percentages reproduce the fresh baseline aggregates; no evidence that its PNG-generation inputs came from another N was found.

## K. Semantic/interpretation issues

Minimal replacements, without rewriting the manuscript:

- H2 line505: “55.6% agreed that senior review/debugging/repair effort per accepted change had increased.” This preserves self-report/attitude and temporal increase, instead of implying directly observed effort.
- H14 line580: “Higher contract-like generation scores were associated with weaker agreement that per-accepted-change senior review/debugging/repair effort had increased (rho=−.225) and weaker agreement that multi-module tasks needed more correction (rho=−.220).” The original item measures comparative correction need, not absolute correction workload.
- H16 line582 and Discussion816–818: use the full replacement sentence in H16_AUDIT. Lower Q22 means weaker agreement about an **increase**, not lower workload even when qualified “per accepted change.” Adaptation is compatible with, not demonstrated by, the correlation.
- H21 line588: “Organization size correlated with the ordered static-analysis integration item (rho=.217); report dynamic testing separately (rho=.182).” State which family was frozen and give raw p/q. Replace the incorrect non-survival claim about interruption.
- H20: current RQ3/Discussion correctly says the coupling is unresolved; **no independence wording error remains there**. Update rho/p only. Non-significance is not proof of independence or distinct capabilities.
- Assurance paragraph: “Same-generator use showed no statistically detectable association with reported human-review frequency (rho=−.011,p=.885).” Review can be frequent overall; this association cannot show absence of compensatory assurance or measure actual review quality.
- Conclusion: “Respondents reported reduced routine junior work and junior hiring; the survey did not establish a compensating redesign of learning tasks.” Q35 measures deliberate task preservation, not the broader construct of curriculum/pipeline redesign.
- Classroom: “Among notebook respondents who answered this item (n=57), the mean for ‘the notebook slowed me down’ was3.04.” Do not describe it as a full-sample mean. “Fewer failed tests” is a count result, not a denominator-standardized quality comparison.
- H13 assessment: “Respondents selected non-AI restructuring/market factors more frequently than direct AI replacement.” This is a descriptive comparison of self-reported multi-select factors, not causal rejection of AI as the primary reason.
- Reproducibility statement: “The package reproduces the frozen-data analyses under the explicitly documented reconstruction; remaining manuscript discrepancies and unresolved historical specifications are reported in the audit.” Do not claim every printed number exactly reproduces.

The current manuscript already labels H14–H21 exploratory, notes mixed significance in the FDR table, rejects subgroup equivalence, and states non-causality/selection limits. Retain those passages. “Strongly supported” categories in the abstract are editorial synthesis, not machine-assigned significance classifications. External AIDev and informal interview percentages were not re-mined or converted into respondent-survey evidence; their quantitative source verification is outside these archived respondent computations. The claimed starter AIDev mining script is absent from the inspected v1.0 file inventory and should be removed or supplied.

## L. Recommended minimal fixes and release status

Freeze exact H19 definitions; recompute all16 q-values; enforce classroom semantic identity for ordinary runs; generate manuscript-named figure assets; retain and explicitly label historical target comparisons; update H19 metadata. Preserve the correct N/A mappings, raw data, midpoint/correction families and signed-rank methods. Leave historical H14 and H21 family decisions explicitly unresolved.

The supplied TeX is unchanged. The report and correction ledger were completed before the restricted code fixes. Final executed tests, fresh corrected public/raw runs, independent comparison and archive checksums are recorded in `FINAL_VALIDATION.md`. The v1.1 ZIP is an **audited reconstruction**, not certification of every manuscript value or recovery of missing historical choices. Public classroom deposition and original figure comparison remain outstanding.
'''
# Use exact freshly computed p rather than a rounded hand transcription.
p=t('classroom_associations').query("target == 'C020'").iloc[0].p
stat=stat.replace('p=7.30e−06',f'p={p:.9g}')
(O/'STATISTICAL_AUDIT.md').write_text(stat,encoding='utf-8')
print('Reports written; current reconciliation checks:',len(rec))
