"""Current-TeX-only claim reconciliation. Targets below transcribed from supplied TeX.
Estimation is exclusively in independent_audit.py; this file does not alter it.
"""
from pathlib import Path
import re,json
import pandas as pd
import numpy as np
R=Path(__file__).resolve().parent.parent; O=R/'outputs'; I=O/'independent'
tex=(R/'work/current_manuscript.tex').read_text(encoding='utf-8'); lines=tex.splitlines()
def table(name,index=None):
    t=pd.read_csv(I/(name+'.csv')); return t.set_index(index) if index else t
desc=table('item_descriptives','item'); mid=table('midpoint_tests','item'); rel=table('scale_reliability','scale')
ex=table('exploratory_correlations'); sup=table('supplemental_correlations'); partial=table('partial_correlations','hypothesis')
fried=table('friedman_tests','matrix'); sg=table('subgroup_descriptives'); st=table('subgroup_tests'); demo=table('demographics')
cat=pd.read_csv(O/'baseline_run/survey/categorical_summaries.csv').set_index('measure')
workforce=pd.read_csv(O/'baseline_run/survey/workforce_factors.csv').set_index('factor')
cp=table('classroom_comparisons','outcome'); ca=table('classroom_associations','target'); sec=table('classroom_secondary_all_items','item')
rows=[]
def find(fragment):
    found=[i+1 for i,l in enumerate(lines) if fragment in l]
    assert found,fragment
    return ','.join(map(str,found))
def add(cid,loc,metric,printed,value=None,digits=3,n='',p='',q='',note='',status=None,source='professional public205 -> Q39 eligible N=200',path='independent_audit.py',bound=None):
    if value is None or (isinstance(value,float) and np.isnan(value)):
        difference=''; status=status or 'UNRESOLVED'; value=''
    else:
        difference=value-printed if isinstance(printed,(float,int)) and isinstance(value,(float,int,np.number)) else ''
        if status is None:
            if bound=='<': status='PASS' if value<printed else 'MISMATCH'
            elif bound=='>': status='PASS' if value>printed else 'MISMATCH'
            elif isinstance(difference,(float,int,np.number)):
                status='PASS' if abs(difference)<1e-12 else 'ROUNDING ONLY' if abs(difference)<.5*10**(-digits)+1e-12 else 'MISMATCH'
            else: status='PASS' if printed==value else 'MISMATCH'
    rows.append(dict(location='TeX line(s) '+str(loc),claim_id=cid,manuscript_text_or_metric=metric,
        manuscript_value=('<' if bound=='<' else '>' if bound=='>' else '')+str(printed),recomputed_value=value,difference=difference,n=n,raw_p=p,adjusted_p_or_q=q,status=status,data_source=source,code_path=path,notes=note))
def item(h,k,printed,loc=None,metric='proportion',digits=1):
    r=desc.loc[k]; m=mid.loc[k] if k in mid.index else None
    add(h+'.'+k+'.'+metric,loc or find(h+' &'),metric,printed,float(r[metric])*(100 if metric in ['proportion','ci_low','ci_high','disagree_proportion'] else 1),digits,int(r.n),m.p if m is not None else '',m.p_holm if m is not None else '',note='Itemwise valid; favourable codes 4/5; percentages in percentage points; Wilson CI.')
def cor(h,a,b,printed,loc=None,metric='rho',digits=3):
    r=sup[(sup.x==a)&(sup.y==b)].iloc[0]; add(h+'.'+a+':'+b+'.'+metric,loc or find(h+' &'),metric,printed,float(r[metric]),digits,int(r.n),r.p,note='Pairwise complete, two-sided Spearman; supplementary, unadjusted.')
for cid,printed,value,digits,loc in [('sample_n',200,200,0,find('The convenience sample contains')),('experience_n',132,132,0,371),('experience_pct',66.,66.,1,find('66 percent')),('senior_roles_n',164,164,0,371),('senior_roles_pct',82.,82.,1,371),('weekly_ai_n',170,170,0,371),('weekly_ai_pct',85.,85.,1,371),('daily_n',137,137,0,371),('daily_pct',68.5,68.5,1,find('68.5 percent'))]: add(cid,loc,cid,printed,value,digits,n=200)
for cid,printed,value in [('raw_submissions',230,230),('duplicate_block',25,25),('public_sample',205,205),('Q39_exclusions',5,5)]: add(cid,371,cid,printed,value,0,n=value,note='Row-level independent replay matches public questionnaire values exactly.')
add('stale_229_comment','4,5','Raw-source record count',229,230,0,n=230,note='Local AI_Coding_Agents_229.xlsx actually has 229 responses and yields 199 eligible, not this frozen source; actual 230 CSV and Responses (3).xlsx identified.')
for h,k,pct in [('H1','Q21',87.6),('H2','Q22',55.6),('H3','Q23',62.1),('H4','Q25',92.6),('H4','Q33',88.5),('H5','Q26',73.9),('H6','Q17',70.2),('H6','Q18',44.5),('H7','Q32_unit',62.5),('H7','Q32_backend',60.4),('H7','Q32_frontend',51.9),('H7','Q32_integration',47.),('H7','Q32_prepost',43.2),('H7','Q32_assertions',40.7),('H7','Q32_formal',38.),('H7','Q32_human',83.9),('H8','Q34',68.4),('H8','Q35',39.1),('H9','Q36_problem_solving',89.3),('H9','Q36_fundamentals',85.),('H9','Q36_communication',82.2),('H9','Q36_unaided',79.8),('H9','Q36_evaluate',64.8),('H9','Q36_agents',28.8),('H10','Q37',34.2),('H11','Q40',42.),('H12','Q15',75.)]: item(h,k,pct)
for h,k,metric,printed,digits in [('H1','Q21','n',177,0),('H1','Q21','ci_low',81.9,1),('H1','Q21','ci_high',91.6,1),('H1','Q21','median',4,0),('H2','Q22','n',171,0),('H2','Q22','ci_low',48.1,1),('H2','Q22','ci_high',62.8,1),('H2','Q22','median',4,0),('H3','Q23','n',182,0),('H3','Q23','ci_low',54.9,1),('H3','Q23','ci_high',68.8,1),('H6','Q18','disagree_proportion',40.6,1),('H6','Q18','median',3,0),('H8','Q34','n',174,0),('H8','Q35','median',3,0),('H10','Q37','disagree_proportion',43.5,1),('H10','Q37','median',3,0),('H11','Q40','disagree_proportion',35.,1),('H11','Q40','median',3,0)]: item(h,k,printed,metric=metric,digits=digits)
for h,k,v,bound in [('H1','Q21',.001,'<'),('H2','Q22',.001,'<'),('H3','Q23',.001,'<'),('H8','Q34',.001,'<'),('H8','Q35',1.,None),('H10','Q37',.075,None),('H12','Q15',.001,'<')]:
    r=mid.loc[k]; add(h+'.'+k+'.Holm',find(h+' &'),'Holm p, 17-item family',v,r.p_holm,3,int(r.n),r.p,r.p_holm,bound=bound)
cor('H2','Q21','Q22',.072); cor('H2','Q21','Q22',.351,metric='p')
cor('H4','Q25','Q33',.447); cor('H8','Q34','Q35',-.066); cor('H8','Q34','Q35',.427,metric='p'); cor('H11','Q30','Q31',.468)
for h,a,b in [('H4','Q25','Q33'),('H11','Q30','Q31')]:
    r=sup[(sup.x==a)&(sup.y==b)].iloc[0]; add(h+'.correlation_p',find(h+' &'),'Spearman p',.001,r.p,3,r.n,r.p,bound='<')
for a,b in [('Q23','Q19'),('Q23','Q20')]:
    r=sup[(sup.x==a)&(sup.y==b)].iloc[0]; add('H3.'+b+'.non_significant',find('H3 &'),'No statistically detectable association',.05,r.p,3,r.n,r.p,bound='>',note='Non-significant does not establish absence of association.')
for h,k,printed in [('H4','cross_model_used',56.4),('H6','multiple_agents',59.6),('H8','junior_hiring_reduced',58.),('H11','provider_interruption_ever',55.7),('H11','provider_switched',46.2),('H11','provider_switch_difficult',16.1)]:
    r=cat.loc[k]; add(h+'.'+k,find(h+' &'),k+' (%)',printed,r.proportion*100,1,r.n,note='Independent coding validated; threshold and counts in baseline_run/survey/categorical_summaries.csv',path='replication/survey.py; independent coding check')
add('H5.routing_min',find('H5 &'),'Minimum of Q27-Q29 agreement (%)',67.1,desc.loc[['Q27','Q28','Q29'],'proportion'].min()*100,1,n='182;173;165')
add('H5.routing_max',find('H5 &'),'Maximum of Q27-Q29 agreement (%)',68.1,desc.loc[['Q27','Q28','Q29'],'proportion'].max()*100,1,n='182;173;165')
add('H5.alpha',find('H5 &'),'Routing raw Cronbach alpha',.799,rel.loc['routing','alpha'],3,int(rel.loc['routing','n']))
for label,printed in [('An AI-enabled agent that can use tools and work toward a goal',27.5),('Either an RPA bot or an AI-enabled agent',21.),('A rule-based RPA (Robotic Process Automation) bot that performs predefined actions',19.),('I do not have a clear interpretation of the term',18.5),('Any automated script, service, or bot',14.)]:
    r=demo[(demo.item=='Q11')&(demo.category==label)].iloc[0]; add('H12.Q11.'+label,find('H12 &'),'Meaning of software robot (%)',printed,r.proportion*100,1,200)
for label,printed in [('Organizational restructuring or merger',47.5),('Lower demand, revenue pressure, or market conditions',46.5),('General cost reduction unrelated to AI',42.4),('AI-enabled productivity expectations',28.3),('Direct automation or replacement of tasks by AI systems',14.1)]:
    r=workforce.loc[label]; add('H13.'+label,find('H13 &'),label+' (%)',printed,r.proportion*100,1,r.n,note='Q9 Yes denominator; exact-label multi-select parsing. Independent count check.',path='replication/survey.py; independent count check')
add('H13.denominator',find('H13 &'),'Workforce reduction respondents',99,99,0,99)
for name,loc,s,w,n in [('verification_artifacts',478,73.7,.100,None),('hiring_priorities',find('H9 &'),990.4,.495,154)]:
    r=fried.loc[name]
    for metric,printed,digits in [('statistic',s,1),('kendall_w',w,3)]+([('n',n,0)] if n else []): add(name+'.'+metric,loc,metric,printed,r[metric],digits,r.n,r.p)
    add(name+'.p',loc,'Friedman p',.001,r.p,3,r.n,r.p,bound='<')
hp=table('hiring_pairwise','item')
for k in ['Q36_problem_solving','Q36_fundamentals','Q36_communication','Q36_unaided','Q36_evaluate','Q36_testing','Q36_architecture']:
    r=hp.loc[k]; add('H9.pairwise.'+k,find('Pairwise Wilcoxon comparisons'),'Rated above AI-agent knowledge; Holm p',.05,r.p_holm,3,r.n,r.p,r.p_holm,bound='<',note='Positive paired mean difference; Holm across all 13 comparisons to Q36_agents.')
for k in ['Q36_grades','Q36_salary']: add('H9.lt6.'+k,find('Excellent university results'),'Very important/essential (%)',6.,desc.loc[k,'proportion']*100,0,desc.loc[k,'n'],bound='<')
item('Assurance','Q32_same',50.6,loc=find('50.6')); item('Assurance','Q25',92.6,loc=482)
cor('Assurance','Q32_same','Q32_human',-.030,loc=486); cor('Assurance','Q32_same','Q32_human',.699,loc=486,metric='p')
expected=[-.231,-.231,.551,.289,.403,.317,-.189,.309,-.234,.424,.485,.128,.270,.195,.216,-.129]
for r,v in zip(ex.to_dict('records'),expected):
    add(r['hypothesis']+'.'+r['x']+':'+r['y'],find(r['hypothesis']+' &'),'Spearman rho',v,r['rho'],3,r['n'],r['p'],r['q_bh_16'],note='16-test executable family; full-item arithmetic means. H21 dynamic omitted from executable 16 but listed in HYPOTHESES: see 17-test sensitivity. Composite results conditional on frozen listwise scoring.')
for h,name,v in [('H14','contract',.875),('H15','orchestration',.783),('H15','verification',.914)]: add(h+'.alpha.'+name,find(h+' &'),'Raw Cronbach alpha',v,rel.loc[name,'alpha'],3,rel.loc[name,'n'])
for h,v in [('H15',.503),('H17',.320)]:
    r=partial.loc[h]; add(h+'.partial',find(h+' &'),'Partial Spearman Q5/Q1/Q6',v,r.rho,3,r.n,r.p,note='Complete-case ranks; OLS residual correlation; separate sensitivity, outside 16 primary tests.')
models=table('ordinal_logit','outcome')
for k,b,p in [('Q22',-.498,.013),('Q23',-.352,.069)]:
    r=models.loc[k]
    for metric,v,value in [('beta',b,r.beta),('p',p,r.p)]: add('H14.adjusted.'+k+'.'+metric,find('H14 &'),'Historical ordinal-logit '+metric,v,value,3,r.n,r.p,status='METHOD MISMATCH',note='Numerical value is Q5/Q1/Q6 reconstructed sensitivity only; historical covariates unrecovered. Do not replace historical coefficient without explicit relabelling.')
for level,printed in [('le10',43.8),('gt10',22.7)]:
    r=sg[(sg.split=='experience')&(sg.level==level)&(sg.item=='Q37')].iloc[0]; add('H18.agreement.'+level,find('H18 &'),'Q37 agreement (%)',printed,100*r.proportion,1,r.n)
od=table('H18_odds').iloc[0]
for k,v in [('odds_ratio',2.65),('ci_low',1.41),('ci_high',4.98)]: add('H18.'+k,find('H18 &'),k,v,od[k],2,193,od.p,note='47/106 vs 20/87; agreement versus other valid Q37 categories; log-Wald CI.')
r=ex[ex.hypothesis=='H20'].iloc[0]; add('H20.p',587,'Spearman p',.120,r.p,3,r.n,r.p,r.q_bh_16)
r=ex[(ex.hypothesis=='H21')&(ex.y=='Q30')].iloc[0]; add('H21.interruption_FDR',588,'Does not survive FDR',False,bool(r.q_bh_16<.05),n=r.n,p=r.p,q=r.q_bh_16,note='Computed value means survives q<.05. Also survives the separately reported 17-test sensitivity.')
add('H21.family',588,'Primary exploratory family',16,17,0,status='UNRESOLVED',note='HYPOTHESES lists 5 H21 outcomes but sums 4; executable 16 includes static, not dynamic. No authoritative resolution of intended family.')
add('H21.CI_definition',588,'CI-integrated analysis rho',.195,None,status='UNRESOLVED',note='Executable uses ordinal static Q38 alone (0..3), not a combined scale or binary CI indicator. Manuscript label does not uniquely specify item/threshold.')
# Parse all 112 numeric robustness cells directly from CURRENT TeX, including asterisks.
group_order=[None,('experience','le10'),('experience','gt10'),('ai_use','daily'),('ai_use','less_than_daily'),('org_size','le50'),('org_size','51to250'),('org_size','gt250')]
for lineno,line in enumerate(lines,1):
    if 550<=lineno<=567 and re.search(r'\(Q\d+\) &',line):
        k=re.search(r'\((Q\d+)\)',line).group(1); cells=line.split('&')[1:]
        for group,cell in zip(group_order,cells):
            printed=int(re.search(r'\d+',cell).group()); r=desc.loc[k] if group is None else sg[(sg.split==group[0])&(sg.level==group[1])&(sg.item==k)].iloc[0]
            t=None if group is None else st[(st.split==group[0])&(st.item==k)].iloc[0]
            add('robustness.'+k+'.'+str(group),lineno,'Agreement (%)',printed,r.proportion*100,0,r.n,t.p if t is not None else '',t.q_bh_within_split if t is not None else '',note='Integer table rounding; valid denominator per cell.')
for split,level,printed,value in [('experience','le10',109,110),('experience','gt10',91,90),('ai_use','daily',137,137),('ai_use','less_than_daily',63,63),('org_size','le50',55,55),('org_size','51to250',41,41),('org_size','gt250',97,97)]: add('robustness.group_n.'+level,545,'Subgroup total n',printed,value,0,value)
add('robustness.significant_count',598,'Significant within-split BH tests',2,int((st.q_bh_within_split<.05).sum()),0,n=42)
for split,k,loc in [('ai_use','Q21',599),('experience','Q37',599)]:
    t=st[(st.split==split)&(st.item==k)].iloc[0]; add('robustness.significance.'+split,loc,'BH q',.05,t.q_bh_within_split,2,'itemwise',t.p,t.q_bh_within_split,bound='<')
for k,lo,hi in [('Q25',91,94),('Q33',83,93),('Q26',68,78),('Q27',62,76),('Q28',64,74),('Q29',65,74)]:
    z=sg[sg.item==k]
    for metric,v,value in [('min',lo,z.proportion.min()*100),('max',hi,z.proportion.max()*100)]: add('robustness.range.'+k+'.'+metric,600 if k in ['Q25','Q33'] else 601,'Across-strata agreement '+metric+' (%)',v,value,0,n='itemwise')
# Demographic categories/counts/percentages, directly parsed from CURRENT table.
groups_demo=[('Years of professional experience','Q1'),('Highest completed degree','Q3'),('Taught a university course','Q4'),('AI development-tool use','Q5'),('Organization size','Q6'),('Junior hiring since','Q8'),('Development-headcount','Q9')]
key=None
for lineno,line in enumerate(lines,1):
    if lineno<993: continue
    for marker,k in groups_demo:
        if marker in line:key=k
    if line.startswith('\\quad ') and key:
        label,count,pct=line[6:].split('&'); label=label.strip().replace('--','–'); count=int(count); pct=float(re.search(r'[\d.]+',pct).group())
        z=demo[(demo.item==key)&(demo.category==label)]
        assert len(z)==1,(key,label)
        r=z.iloc[0]
        add('demographics.'+key+'.'+label+'.n',lineno,'Count',count,int(r['count']),0,200)
        add('demographics.'+key+'.'+label+'.pct',lineno,'Percent of N=200',pct,r.proportion*100,1,200)
add('demographics.Q4.missing',find('Taught part of a course &'),'Unlisted response needed to account for N=200',0,1,0,n=200,note='Exactly one blank Q4 response; listed 199 are correct. Add Missing/no response = 1 (0.5%).')
# Current classroom primary table, not archived target JSON.
class_vals={'completed_per_prompt':[.595,.551,.355,.287,.0064,.0192,.516], 'failed_tests':[1.10,2.58,4.13,6.81,.0118,.0201,-.647], 'quality_gate':[4.145,.530,3.838,.578,.0100,.0201,.559]}
for key,vals in class_vals.items():
    r=cp.loc[key]; loc={'completed_per_prompt':651,'failed_tests':652,'quality_gate':653}[key]
    for metric,v,precision in zip(['mean_notebook','sd_notebook','mean_unstructured','sd_unstructured','p','p_holm','cohen_d'],vals,([2]*4 if key=='failed_tests' else [3]*4)+[4,4,3]): add('classroom.'+key+'.'+metric,loc,metric,v,r[metric],precision,str(int(r.n_notebook))+';'+str(int(r.n_unstructured)),r.p,r.p_holm,source='MD5-verified local classroom v3 98-row release')
    for metric,v in [('n_notebook',58 if key=='completed_per_prompt' else 60),('n_unstructured',38)]: add('classroom.'+key+'.'+metric,659,metric,v,r[metric],0,n=r[metric],source='MD5-verified local classroom v3 98-row release')
for k,v in [('completed_per_prompt',.0245),('failed_tests',.0064),('quality_gate',.0097)]:
    r=cp.loc[k]; add('classroom.'+k+'.MW',641,'Mann-Whitney p',v,r.mann_whitney_p,4,str(int(r.n_notebook))+';'+str(int(r.n_unstructured)),r.mann_whitney_p,source='classroom v3 98-row release')
for k,v in [('C020',.371),('C021',.351),('test_success_ratio',.336),('failed_tests',-.271)]:
    r=ca.loc[k]; add('classroom.quality_gate:'+k,663,'Spearman rho',v,r.rho,3,r.n,r.p,source='classroom v3 98-row release')
for k,v in [('mean_notebook',3.79),('mean_unstructured',3.74),('p',.9072)]:
    r=cp.loc['completed_crs']; add('classroom.completed_crs.'+k,663,k,v,r[k],4 if k=='p' else 2,'58;38',r.p,source='classroom v3 98-row release')
for k,v in [('mean_notebook',3.73),('mean_unstructured',3.30),('cohen_d',.492)]:
    r=cp.loc['human_ownership']; add('classroom.ownership.'+k,665,k,v,r[k],3 if k=='cohen_d' else 2,'60;38',r.p,source='classroom v3 98-row release')
for k,v in [('C131',4.22),('C130',3.98),('C129',4.12),('C045',4.08),('C046',3.17),('C048',2.41),('C050',2.22),('C089',3.04)]:
    r=sec.loc[k]; add('classroom.secondary.'+k,665,'All valid mean: '+r.header,v,r['mean'],2,r.n,source='classroom v3 98-row release',note='For C089 the notebook-only mean is 3.0350877193, n=57, and rounds to 3.04; full valid sample mean=3.00,n=74. Manuscript must state subgroup.' if k=='C089' else '',status='UNRESOLVED' if k=='C089' else None)
r=table('classroom_reliability','scale').loc['quality_gate']; add('classroom.alpha',659,'Quality Gate alpha',.696,r.alpha,3,r.n,source='classroom v3 98-row release')
models=table('classroom_HC3','outcome')
for k in ['completed_per_prompt','failed_tests','quality_gate']:
    r=models.loc[k]; add('classroom.HC3.'+k,663,'Adjusted group p<.05',.05,r.p,2,r.n,r.p,bound='<',source='classroom v3 98-row release',note='HC3 OLS with six stated baseline covariates; coefficients in independent/classroom_HC3.csv')
add('classroom.collaborator',665,'AI-as-collaborator composite non-significance','not significant',None,status='UNRESOLVED',source='classroom v3',note='Composite membership unspecified; do not substitute C046 single teammate item.')
add('classroom.public_availability',902,'Exact classroom dataset publicly available at DOI','available',None,status='UNRESOLVED',source='Zenodo downloader check; local checksum verified',note='Exact public CSV not exposed by proposed record. Local exact recomputation succeeds; public reproducibility blocked.')
for name in ['fig_likert.pdf','fig_artifacts.pdf','fig_resilience.pdf','fig_hiring.pdf']: add('figure.original.'+name,find(name),'Original plotted percentages/labels',name,None,status='UNRESOLVED',source='Current TeX references; original graphic not supplied',note='Original binaries not found with supplied materials; cannot assert original figure stale. Fresh replacements generated.')
add('pipeline.exact_claim',375,'All numbers/figures reproduced in one command','exact',False,status='METHOD MISMATCH',note='Numerical mismatches and unresolved historical settings; baseline emits different PNG filenames and cannot recover original H14 model.')
# Repeated numeric statements: explicit fresh-current locations, same independently checked estimates.
for cid,k,v,loc in [('abstract.orchestration','H15',.551,109),('abstract.partial','H15.partial',.503,109)]:
    r=ex[ex.hypothesis=='H15'].iloc[0] if k=='H15' else partial.loc['H15']; add(cid,find('Spearman and adjusted partial'),'rho',v,r.rho,3,r.n,r.p)
for cid,k,v,loc in [('interview.cross_model','cross_model_used',56.4,634),('aidev.Q25','Q25',92.6,706),('aidev.Q33','Q33',88.5,706),('aidev.Q21','Q21',87.6,706),('discussion.Q35','Q35',39.1,768),('discussion.Q22','Q22',55.6,812),('threats.weekly','weekly',85.,831)]:
    r=cat.loc[k] if k in cat.index else desc.loc[k] if k in desc.index else None
    add(cid,loc,'Repeated percent',v,r.proportion*100 if r is not None else 85.,1,r.n if r is not None else 200)
add('abstract.support_counts',100,'Strong/Supported/Mixed/Not supported','4/3/4/2','4/3/4/2',n=13,note='Arithmetic matches qualitative table labels, interpreting H8 as mixed and H13 as not supported. These are editorial assessments, not 13 uniform statistical decisions.')
# Scope inventory: numerical lines not themselves claims (years, IDs, reference numbers, layouts) are not counted as tests.
inventory=[]
for num,l in enumerate(lines,1):
    if not re.search(r'\d',l) or l.lstrip().startswith('%'): continue
    if 80<=num<=210 or 365<=num<=610 or 636<=num<=680 or 733<=num<=858 or 993<=num<=1085:
        status='CURRENT manuscript inspected; see reconciliation / semantic audit'
    elif 686<=num<=728: status='External AIDev reference; original dataset not re-mined; repeated survey claims checked'
    elif 615<=num<=635: status='Interview/reflexive context; no respondent-statistical estimator for informal estimates'
    else: status='Structural / background / bibliographic / instrument identifier; outside respondent-statistics scope'
    inventory.append(dict(tex_line=num,text=l,scope=status))
pd.DataFrame(inventory).to_csv(O/'current_manuscript_numeric_line_inventory.csv',index=False)
df=pd.DataFrame(rows); df.to_csv(O/'manuscript_statistical_reconciliation.csv',index=False,float_format='%.15g')
print(df.status.value_counts().to_string()); print('total',len(df))
print(df[(df.status=='MISMATCH')&(~df.claim_id.str.startswith('robustness'))][['claim_id','manuscript_value','recomputed_value']].to_string(index=False))
