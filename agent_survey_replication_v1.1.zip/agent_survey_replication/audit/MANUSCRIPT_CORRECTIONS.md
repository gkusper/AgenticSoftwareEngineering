# Exact current-manuscript correction ledger

These are discrepancy checks, not independent scientific errors; repeated claims and separate count/percent checks are retained. Values are unrounded to prevent ambiguity. Round to the manuscript’s chosen display precision after estimation. Composite replacements are conditional on the documented complete-item scoring convention; see audit. H14 historical-model substitutions and unresolved items are deliberately excluded. No TeX was modified.

| location | claim_id | manuscript_value | recomputed_value | n | raw_p | adjusted_p_or_q |
| --- | --- | --- | --- | --- | --- | --- |
| TeX line(s) 4,5 | stale_229_comment | 229 | 230 | 230 |  |  |
| TeX line(s) 511 | H4.Q25.proportion | 92.6 | 93.0851063829787 | 188 | 1.32342403e-31 | 2.24982085e-30 |
| TeX line(s) 511 | H4.Q33.proportion | 88.5 | 89.0 | 200 | 1.96379851e-27 | 3.14207762e-26 |
| TeX line(s) 512 | H5.Q26.proportion | 73.9 | 73.2954545454545 | 176 | 5.06447288e-10 | 4.05157831e-09 |
| TeX line(s) 514 | H7.Q32_prepost.proportion | 43.2 | 42.9487179487179 | 156 |  |  |
| TeX line(s) 514 | H7.Q32_assertions.proportion | 40.7 | 41.0596026490066 | 151 |  |  |
| TeX line(s) 514 | H7.Q32_formal.proportion | 38.0 | 37.8048780487805 | 164 |  |  |
| TeX line(s) 514 | H7.Q32_human.proportion | 83.9 | 84.48275862068971 | 174 |  |  |
| TeX line(s) 530 | H8.Q34.proportion | 68.4 | 67.816091954023 | 174 | 5.4737262e-12 | 5.4737262e-11 |
| TeX line(s) 530 | H8.Q35.proportion | 39.1 | 39.7435897435897 | 156 | 0.299598602 | 0.898795805 |
| TeX line(s) 531 | H9.Q36_problem_solving.proportion | 89.3 | 89.8395721925134 | 187 |  |  |
| TeX line(s) 531 | H9.Q36_fundamentals.proportion | 85.0 | 85.4922279792746 | 193 |  |  |
| TeX line(s) 531 | H9.Q36_communication.proportion | 82.2 | 82.7225130890052 | 191 |  |  |
| TeX line(s) 531 | H9.Q36_evaluate.proportion | 64.8 | 65.2849740932642 | 193 |  |  |
| TeX line(s) 532 | H10.Q37.proportion | 34.2 | 34.715025906735804 | 193 | 0.0252417701 | 0.10096708 |
| TeX line(s) 534 | H12.Q15.proportion | 75.0 | 75.5 | 200 | 5.66227681e-25 | 8.49341522e-24 |
| TeX line(s) 532 | H10.Q37.disagree_proportion | 43.5 | 43.0051813471503 | 193 | 0.0252417701 | 0.10096708 |
| TeX line(s) 530 | H8.Q35.Holm | 1.0 | 0.898795804710581 | 156 | 0.299598602 | 0.898795805 |
| TeX line(s) 532 | H10.Q37.Holm | 0.075 | 0.100967080371946 | 193 | 0.0252417701 | 0.10096708 |
| TeX line(s) 511 | H4.Q25:Q33.rho | 0.447 | 0.43889679002901 | 188 | 2.97010062e-10 |  |
| TeX line(s) 530 | H8.Q34:Q35.rho | -0.066 | -0.0615717157964004 | 147 | 0.458785745 |  |
| TeX line(s) 530 | H8.Q34:Q35.p | 0.427 | 0.458785745040425 | 147 | 0.458785745 |  |
| TeX line(s) 533 | H11.Q30:Q31.rho | 0.468 | 0.461332636979175 | 185 | 3.8743443e-11 |  |
| TeX line(s) 533 | H11.provider_switched | 46.2 | 45.6989247311828 | 186 |  |  |
| TeX line(s) 512 | H5.routing_min | 67.1 | 67.6300578034682 | 182;173;165 |  |  |
| TeX line(s) 512 | H5.alpha | 0.799 | 0.790407087514289 | 159 |  |  |
| TeX line(s) 534 | H12.Q11.Either an RPA bot or an AI-enabled agent | 21.0 | 21.5 | 200 |  |  |
| TeX line(s) 534 | H12.Q11.Any automated script, service, or bot | 14.0 | 13.5 | 200 |  |  |
| TeX line(s) 535 | H13.Lower demand, revenue pressure, or market conditions | 46.5 | 47.474747474747495 | 99.0 |  |  |
| TeX line(s) 535 | H13.AI-enabled productivity expectations | 28.3 | 27.2727272727273 | 99.0 |  |  |
| TeX line(s) 535 | H13.Direct automation or replacement of tasks by AI systems | 14.1 | 15.151515151515198 | 99.0 |  |  |
| TeX line(s) 478 | verification_artifacts.statistic | 73.7 | 73.7849409448822 | 124.0 | 6.82624479e-14 |  |
| TeX line(s) 478 | verification_artifacts.kendall_w | 0.1 | 0.0991733077216159 | 124.0 | 6.82624479e-14 |  |
| TeX line(s) 531 | hiring_priorities.statistic | 990.4 | 994.265187275942 | 155.0 | 2.9802822e-204 |  |
| TeX line(s) 531 | hiring_priorities.kendall_w | 0.495 | 0.493431854727515 | 155.0 | 2.9802822e-204 |  |
| TeX line(s) 531 | hiring_priorities.n | 154 | 155.0 | 155.0 | 2.9802822e-204 |  |
| TeX line(s) 482 | Assurance.Q25.proportion | 92.6 | 93.0851063829787 | 188 | 1.32342403e-31 | 2.24982085e-30 |
| TeX line(s) 486 | Assurance.Q32_same:Q32_human.rho | -0.03 | -0.0113500065982112 | 165 | 0.884955818 |  |
| TeX line(s) 486 | Assurance.Q32_same:Q32_human.p | 0.699 | 0.884955818376388 | 165 | 0.884955818 |  |
| TeX line(s) 580 | H14.contract:Q22 | -0.231 | -0.225173116400676 | 129 | 0.0102991844 | 0.0128876874 |
| TeX line(s) 580 | H14.contract:Q23 | -0.231 | -0.219755970045328 | 135 | 0.0104378531 | 0.0128876874 |
| TeX line(s) 581 | H15.orchestration:verification | 0.551 | 0.537831147878377 | 105 | 3.29013898e-09 | 2.32824402e-08 |
| TeX line(s) 582 | H16.Q5:verification | 0.403 | 0.398384209772328 | 124 | 4.59544968e-06 | 1.83817987e-05 |
| TeX line(s) 582 | H16.Q5:Q24 | 0.317 | 0.31902249653881 | 165 | 2.9612834e-05 | 9.47610687e-05 |
| TeX line(s) 583 | H17.Q21:Q34 | 0.309 | 0.292690419868565 | 158 | 0.00019003153 | 0.00038006306 |
| TeX line(s) 585 | H19.Q36_evaluate:traditional_engineering | 0.424 | 0.413735836335703 | 186 | 4.36545754e-09 | 2.32824402e-08 |
| TeX line(s) 585 | H19.Q36_evaluate:ai_literacy | 0.485 | 0.482082992229127 | 190 | 1.88966766e-12 | 3.02346826e-11 |
| TeX line(s) 586 | H20.Q26:routing | 0.128 | 0.157349680538319 | 149 | 0.0553042981 | 0.0553042981 |
| TeX line(s) 588 | H21.Q6:Q32_formal | 0.27 | 0.29422992840278 | 159 | 0.000166881461 | 0.00038006306 |
| TeX line(s) 588 | H21.Q6:Q38_static | 0.195 | 0.216758157688801 | 163 | 0.00544919483 | 0.00871871172 |
| TeX line(s) 588 | H21.Q6:Q24 | 0.216 | 0.203137100384185 | 158 | 0.010471246 | 0.0128876874 |
| TeX line(s) 588 | H21.Q6:Q30 | -0.129 | -0.14684416050041 | 186 | 0.0454957354 | 0.0485287844 |
| TeX line(s) 580 | H14.alpha.contract | 0.875 | 0.873487252816238 | 141 |  |  |
| TeX line(s) 581 | H15.alpha.orchestration | 0.783 | 0.77822105759039 | 146 |  |  |
| TeX line(s) 581 | H15.alpha.verification | 0.914 | 0.913388325880034 | 124 |  |  |
| TeX line(s) 581 | H15.partial | 0.503 | 0.486420988457624 | 103 | 2.88313239e-07 |  |
| TeX line(s) 583 | H17.partial | 0.32 | 0.303862877210073 | 155 | 0.000141382764 |  |
| TeX line(s) 584 | H18.agreement.le10 | 43.8 | 44.3396226415094 | 106 |  |  |
| TeX line(s) 584 | H18.agreement.gt10 | 22.7 | 22.9885057471264 | 87 |  |  |
| TeX line(s) 584 | H18.odds_ratio | 2.65 | 2.66864406779661 | 193 | 0.00232802578 |  |
| TeX line(s) 584 | H18.ci_low | 1.41 | 1.42203076236731 | 193 | 0.00232802578 |  |
| TeX line(s) 584 | H18.ci_high | 4.98 | 5.00809219396235 | 193 | 0.00232802578 |  |
| TeX line(s) 587 | H20.p | 0.12 | 0.0553042980785677 | 149 | 0.0553042981 | 0.0553042981 |
| TeX line(s) 588 | H21.interruption_FDR | False | True | 186 | 0.0454957354 | 0.0485287844 |
| TeX line(s) 554 | robustness.Q22.('experience', 'gt10') | 52 | 51.315789473684205 | 76 | 0.139845898 | 0.305841904 |
| TeX line(s) 556 | robustness.Q17.('experience', 'le10') | 65 | 65.5913978494624 | 93 | 0.12470114 | 0.305841904 |
| TeX line(s) 557 | robustness.Q19.('experience', 'le10') | 62 | 60.8695652173913 | 92 | 0.165241171 | 0.305841904 |
| TeX line(s) 557 | robustness.Q19.('experience', 'gt10') | 65 | 66.19718309859151 | 71 | 0.165241171 | 0.305841904 |
| TeX line(s) 558 | robustness.Q26.None | 74 | 73.2954545454545 | 176.0 |  |  |
| TeX line(s) 558 | robustness.Q26.('experience', 'le10') | 72 | 71.1340206185567 | 97 | 0.649870098 | 0.758181781 |
| TeX line(s) 558 | robustness.Q26.('ai_use', 'daily') | 72 | 71.2 | 125 | 0.480499331 | 0.683249058 |
| TeX line(s) 558 | robustness.Q26.('org_size', 'gt250') | 76 | 74.4186046511628 | 86 | 0.426921438 | 0.664100015 |
| TeX line(s) 559 | robustness.Q27.('experience', 'le10') | 62 | 61.0 | 100 | 0.174766802 | 0.305841904 |
| TeX line(s) 559 | robustness.Q27.('experience', 'gt10') | 76 | 76.8292682926829 | 82 | 0.174766802 | 0.305841904 |
| TeX line(s) 560 | robustness.Q28.None | 67 | 67.6300578034682 | 173.0 |  |  |
| TeX line(s) 560 | robustness.Q28.('experience', 'gt10') | 65 | 65.8227848101266 | 79 | 0.902004731 | 0.97138971 |
| TeX line(s) 560 | robustness.Q28.('ai_use', 'daily') | 67 | 67.7165354330709 | 127 | 0.121026717 | 0.338874808 |
| TeX line(s) 560 | robustness.Q28.('org_size', 'gt250') | 64 | 65.1162790697674 | 86 | 0.724940579 | 0.835954827 |
| TeX line(s) 561 | robustness.Q29.('experience', 'le10') | 69 | 67.7777777777778 | 90 | 0.987299485 | 0.987299485 |
| TeX line(s) 561 | robustness.Q29.('experience', 'gt10') | 67 | 68.0 | 75 | 0.987299485 | 0.987299485 |
| TeX line(s) 562 | robustness.Q25.('experience', 'gt10') | 92 | 92.8571428571429 | 84 | 0.0427286277 | 0.165201533 |
| TeX line(s) 562 | robustness.Q25.('ai_use', 'daily') | 92 | 93.0769230769231 | 130 | 0.650570046 | 0.827998241 |
| TeX line(s) 562 | robustness.Q25.('org_size', 'gt250') | 91 | 92.3076923076923 | 91 | 0.335243159 | 0.664100015 |
| TeX line(s) 563 | robustness.Q33.None | 88 | 89.0 | 200.0 |  |  |
| TeX line(s) 563 | robustness.Q33.('experience', 'gt10') | 85 | 85.5555555555556 | 90 | 0.0155626293 | 0.108938405 |
| TeX line(s) 563 | robustness.Q33.('org_size', 'gt250') | 88 | 88.659793814433 | 97 | 0.0125418676 | 0.175586146 |
| TeX line(s) 564 | robustness.Q34.('ai_use', 'daily') | 66 | 65.3225806451613 | 124 | 0.74347851 | 0.867391595 |
| TeX line(s) 564 | robustness.Q34.('org_size', 'gt250') | 66 | 65.06024096385539 | 83 | 0.407301317 | 0.664100015 |
| TeX line(s) 565 | robustness.Q35.None | 39 | 39.7435897435897 | 156.0 |  |  |
| TeX line(s) 565 | robustness.Q35.('experience', 'le10') | 35 | 35.955056179775305 | 89 | 0.326599074 | 0.457238703 |
| TeX line(s) 565 | robustness.Q35.('experience', 'gt10') | 44 | 44.776119402985096 | 67 | 0.326599074 | 0.457238703 |
| TeX line(s) 565 | robustness.Q35.('ai_use', 'daily') | 40 | 40.7407407407407 | 108 | 0.289098772 | 0.578197544 |
| TeX line(s) 565 | robustness.Q35.('org_size', 'gt250') | 39 | 40.2597402597403 | 77 | 0.314611009 | 0.664100015 |
| TeX line(s) 566 | robustness.Q37.None | 34 | 34.715025906735804 | 193.0 |  |  |
| TeX line(s) 566 | robustness.Q37.('ai_use', 'daily') | 36 | 36.7647058823529 | 136 | 0.334781426 | 0.585867495 |
| TeX line(s) 566 | robustness.Q37.('org_size', 'gt250') | 28 | 29.032258064516096 | 93 | 0.354515973 | 0.664100015 |
| TeX line(s) 545 | robustness.group_n.le10 | 109 | 110 | 110 |  |  |
| TeX line(s) 545 | robustness.group_n.gt10 | 91 | 90 | 90 |  |  |
| TeX line(s) 600 | robustness.range.Q25.min | 91 | 92.3076923076923 | itemwise |  |  |
| TeX line(s) 601 | robustness.range.Q27.min | 62 | 61.0 | itemwise |  |  |
| TeX line(s) 601 | robustness.range.Q27.max | 76 | 76.8292682926829 | itemwise |  |  |
| TeX line(s) 601 | robustness.range.Q28.min | 64 | 65.1162790697674 | itemwise |  |  |
| TeX line(s) 1017 | demographics.Q3.MSc or equivalent.n | 59 | 60 | 200 |  |  |
| TeX line(s) 1017 | demographics.Q3.MSc or equivalent.pct | 29.5 | 30.0 | 200 |  |  |
| TeX line(s) 1018 | demographics.Q3.PhD / doctorate.n | 19 | 18 | 200 |  |  |
| TeX line(s) 1018 | demographics.Q3.PhD / doctorate.pct | 9.5 | 9.0 | 200 |  |  |
| TeX line(s) 1057 | demographics.Q9.Yes, but I do not know which levels were most affected.n | 27 | 28 | 200 |  |  |
| TeX line(s) 1057 | demographics.Q9.Yes, but I do not know which levels were most affected.pct | 13.5 | 14.000000000000002 | 200 |  |  |
| TeX line(s) 1058 | demographics.Q9.Yes, mainly junior positions.n | 18 | 17 | 200 |  |  |
| TeX line(s) 1058 | demographics.Q9.Yes, mainly junior positions.pct | 9.0 | 8.5 | 200 |  |  |
| TeX line(s) 1027 | demographics.Q4.missing | 0 | 1 | 200 |  |  |
| TeX line(s) 663 | classroom.quality_gate:C020 | 0.371 | 0.435769234162655 | 98.0 | 7.29766136e-06 |  |
| TeX line(s) 111 | abstract.orchestration | 0.551 | 0.537831147878377 | 105 | 3.29013898e-09 |  |
| TeX line(s) 111 | abstract.partial | 0.503 | 0.486420988457624 | 103 | 2.88313239e-07 |  |
| TeX line(s) 706 | aidev.Q25 | 92.6 | 93.0851063829787 | 188.0 |  |  |
| TeX line(s) 706 | aidev.Q33 | 88.5 | 89.0 | 200.0 |  |  |
| TeX line(s) 768 | discussion.Q35 | 39.1 | 39.7435897435897 | 156.0 |  |  |

## Unresolved and method/provenance items

| location | claim_id | manuscript_value | recomputed_value | status | notes |
| --- | --- | --- | --- | --- | --- |
| TeX line(s) 580 | H14.adjusted.Q22.beta | -0.498 | -0.312483301461335 | METHOD MISMATCH | Numerical value is Q5/Q1/Q6 reconstructed sensitivity only; historical covariates unrecovered. Do not replace historical coefficient without explicit relabelling. |
| TeX line(s) 580 | H14.adjusted.Q22.p | 0.013 | 0.0249874603326116 | METHOD MISMATCH | Numerical value is Q5/Q1/Q6 reconstructed sensitivity only; historical covariates unrecovered. Do not replace historical coefficient without explicit relabelling. |
| TeX line(s) 580 | H14.adjusted.Q23.beta | -0.352 | -0.219455990321426 | METHOD MISMATCH | Numerical value is Q5/Q1/Q6 reconstructed sensitivity only; historical covariates unrecovered. Do not replace historical coefficient without explicit relabelling. |
| TeX line(s) 580 | H14.adjusted.Q23.p | 0.069 | 0.105752209630111 | METHOD MISMATCH | Numerical value is Q5/Q1/Q6 reconstructed sensitivity only; historical covariates unrecovered. Do not replace historical coefficient without explicit relabelling. |
| TeX line(s) 588 | H21.family | 16 | 17 | UNRESOLVED | HYPOTHESES lists 5 H21 outcomes but sums 4; executable 16 includes static, not dynamic. No authoritative resolution of intended family. |
| TeX line(s) 588 | H21.CI_definition | 0.195 |  | UNRESOLVED | Executable uses ordinal static Q38 alone (0..3), not a combined scale or binary CI indicator. Manuscript label does not uniquely specify item/threshold. |
| TeX line(s) 665 | classroom.secondary.C089 | 3.04 | 3.0 | UNRESOLVED | For C089 the notebook-only mean is 3.0350877193, n=57, and rounds to 3.04; full valid sample mean=3.00,n=74. Manuscript must state subgroup. |
| TeX line(s) 665 | classroom.collaborator | not significant |  | UNRESOLVED | Composite membership unspecified; do not substitute C046 single teammate item. |
| TeX line(s) 902 | classroom.public_availability | available |  | UNRESOLVED | Exact public CSV not exposed by proposed record. Local exact recomputation succeeds; public reproducibility blocked. |
| TeX line(s) 395 | figure.original.fig_likert.pdf | fig_likert.pdf |  | UNRESOLVED | Original binaries not found with supplied materials; cannot assert original figure stale. Fresh replacements generated. |
| TeX line(s) 423 | figure.original.fig_artifacts.pdf | fig_artifacts.pdf |  | UNRESOLVED | Original binaries not found with supplied materials; cannot assert original figure stale. Fresh replacements generated. |
| TeX line(s) 442 | figure.original.fig_resilience.pdf | fig_resilience.pdf |  | UNRESOLVED | Original binaries not found with supplied materials; cannot assert original figure stale. Fresh replacements generated. |
| TeX line(s) 462 | figure.original.fig_hiring.pdf | fig_hiring.pdf |  | UNRESOLVED | Original binaries not found with supplied materials; cannot assert original figure stale. Fresh replacements generated. |
| TeX line(s) 375 | pipeline.exact_claim | exact | False | METHOD MISMATCH | Numerical mismatches and unresolved historical settings; baseline emits different PNG filenames and cannot recover original H14 model. |
