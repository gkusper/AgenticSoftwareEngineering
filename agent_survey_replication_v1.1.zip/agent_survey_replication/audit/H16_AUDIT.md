# H16 independent audit

Authority: supplied EMSE_Article_hybrid_v2.6.3.tex, not the old target JSON. Dataset: public 205-row release, exact Q39 eligibility, N=200. All four estimates below are from respondent records; manuscript values never enter estimation.

## Coding and estimands

Q5: Never=1; Less than monthly=2; Monthly=3; Weekly=4; Daily or almost daily=5. Valid n=200. Higher means more frequent professional AI use.

Q21 and Q22: Strongly disagree=1; Disagree=2; Neither agree nor disagree=3; Agree=4; Strongly agree=5. N/A/insufficient experience is missing. Valid n=177 and 171 respectively. Q22 is agreement that senior review/debugging/repair work **per accepted change increased**. It is neither the level of workload nor total workload.

Q24: had not considered before survey=1; knew but had not considered using=2; considered but not used=3; occasionally used=4; regularly used=5. Missing/insufficient experience excluded; valid n=165. This ordered variable mixes awareness, consideration and use; call it the ordered cross-model-review item, not a continuous usage count.

Each of seven Q32 generation items: Never=1; Rarely=2; Sometimes=3; Often=4; Almost always=5. N/A/insufficient direct experience is missing, never 1 or 0. Higher means more frequent generation of the stated artifact. These seven exclude same-generator practice and human review.

Verification items: unit tests, frontend tests, backend tests, integration tests, runtime assertions, pre/postconditions and formal specifications. The frozen executable convention is an unweighted mean **requiring all seven valid responses**; n=124. This is a mean generation-frequency score, not a count of distinct practices. The manuscript specifies itemwise missing handling and points to source for composites; the v1.0 METHODS acknowledges that listwise scoring is a reconstruction, not recovered historical proof. Do not silently substitute an available-item mean. If the authors intended another minimum-item rule, these composite comparisons become UNRESOLVED until that rule is frozen.

For each target, intersect valid Q5 and target rows, assign average ranks to ties, compute Pearson correlation of those ranks (Spearman rho). Two-sided p uses the standard asymptotic t transform, df=n−2. BH uses **all 16 primary raw p-values**, including the now-defined H19 tests: sort p, calculate 16*p/rank, take reverse cumulative minima and cap at 1. No pre-rounding or significance filtering. Partial/logit sensitivities are outside this primary family.

## Results

| x | y | n | rho | p | q_bh_16 | survives |
| --- | --- | --- | --- | --- | --- | --- |
| Q5 | Q21 | 177 | 0.288951144 | 9.59781355e-05 | 0.000255941695 | True |
| Q5 | verification | 124 | 0.39838421 | 4.59544968e-06 | 1.83817987e-05 | True |
| Q5 | Q24 | 165 | 0.319022497 | 2.9612834e-05 | 9.47610687e-05 | True |
| Q5 | Q22 | 171 | -0.189035139 | 0.0132792303 | 0.0151762632 | True |

The manuscript’s .289 and −.189 match printed precision. Under the frozen complete-item rule, .403 must become **.398** and .317 must become **.319**. All four survive the reconstructed BH family. See the explicit 17-test family sensitivity in `independent/exploratory_17_test_sensitivity.csv`; all four also survive there.

## Missing-data sensitivities (not target-fitting)

| variant | target | n | rho | p |
| --- | --- | --- | --- | --- |
| Q32 missing; mean >= 1/7 items | verification | 185 | 0.240847334 | 0.00095852939 |
| Q32 missing; mean >= 4/7 items | verification | 167 | 0.277253995 | 0.000286316508 |
| Q32 missing; mean >= 7/7 items | verification | 124 | 0.39838421 | 4.59544968e-06 |
| INVALID Q32 missing filled with 1 | verification | 200 | 0.40288521 | 3.3283288e-09 |
| INVALID Q32 missing filled with 0 | verification | 200 | 0.397764913 | 5.46228767e-09 |
| Q24 missing excluded | Q24 | 165 | 0.319022497 | 2.9612834e-05 |
| INVALID Q24 missing filled with 1 | Q24 | 200 | 0.302349973 | 1.35301404e-05 |
| INVALID Q24 missing filled with 0 | Q24 | 200 | 0.296003434 | 2.08451248e-05 |
| Ordinal pairwise complete | Q21 | 177 | 0.288951144 | 9.59781355e-05 |
| Ordinal pairwise complete | Q22 | 171 | -0.189035139 | 0.0132792303 |

The suspect .403 is reproduced to displayed precision by the **invalid** choice of replacing missing Q32 responses with Never=1: rho=.402885209718143. This changes the sample from 124 complete seven-item respondents to all 200 and treats lack of applicability/experience as observed non-use. It contradicts the manuscript and is **not what the v1.0 encoder does**. Numerical agreement identifies a plausible mechanism, not proof of the historical author's actual code.

The .398 value is .398384209772328 using valid complete items. Filling with zero, another invalid choice, also rounds to .398 (.397765...), illustrating why matching a rounded target alone is not evidence of the right method. Available-item means are defensible only if declared in advance with a minimum answered-item rule; here they yield .240847 (at least one) or .277254 (at least four), and are sensitivities, not replacements.

## Historical cross-check

| version | analysis_n | target | n | rho | p |
| --- | --- | --- | --- | --- | --- |
| local_229 | 199 | Q24 | 164 | 0.315990544 | 3.75899694e-05 |
| local_229 | 199 | verification_complete | 123 | 0.396394819 | 5.66018212e-06 |
| local_229 | 199 | verification_fill1_INVALID | 199 | 0.401179577 | 4.29982896e-09 |
| public_205 | 200 | Q24 | 165 | 0.319022497 | 2.9612834e-05 |
| public_205 | 200 | verification_complete | 124 | 0.39838421 | 4.59544968e-06 |
| public_205 | 200 | verification_fill1_INVALID | 200 | 0.40288521 | 3.3283288e-09 |

The local AI_Coding_Agents_229.xlsx genuinely has 229 responses, removes a 25-answer-identical block and leaves 199 Q39-eligible records. It is not the frozen N=200 source and differs in more than a final row (only 76 complete questionnaire rows overlap the public205 file). Its Q24 rho is .315991, which rounds to .316, not .317. Neither public205 pairwise coding nor this preserved older file explains .317. Its exact historical origin is **UNRESOLVED**. No respondent deletion, category regrouping, or item-subset search was undertaken to force .317.

## Faithful replacement wording

“More frequent professional AI use was associated with higher reported code-volume growth (rho=.289), a higher mean verification-generation score (rho=.398), higher scores on the ordered cross-model-review item (rho=.319), and weaker agreement that senior review/debugging/repair effort per accepted change had increased (rho=−.189). All four associations survived BH correction in the reconstructed 16-test family. An adaptation account is a hypothesis; these cross-sectional data do not distinguish it from selection or confounding.”

## Reproduction

Exact category counts, missing labels and valid n: `independent/ordinal_coding_and_missing.csv`. Every primary test including n/p/q: `independent/exploratory_correlations.csv`. Independent estimation source is supplied under `audit_code/independent_audit.py`; its input and code hashes are in `independent/manifest.json`. The corrected pipeline yields the same H16 rho/p as v1.0; H19 completion changes family q-values. No response values were edited.
