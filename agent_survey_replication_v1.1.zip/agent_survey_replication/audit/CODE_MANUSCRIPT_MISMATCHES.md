# Code/manuscript mismatches

Audit of untouched v1.0 against supplied current TeX and frozen repository commit. Line references in this report refer to v1.0 unless stated otherwise.

## C01 — H19 executable definitions missing

- Requirement: Current HYPOTHESES.md defines a five-item traditional scale and two-item AI-literacy scale.
- Current behavior and location: config/analysis_plan.json:125–132 has items=null; replication/survey.py:117–126 produces undefined scores.
- Consequence: Both primary tests missing; p=1 placeholders in correction affect all 16 q-values.
- Minimal fix: Populate exact item sets; retain explicitly documented full-item mean rule (5/5 and 2/2); rerun full BH family. Do not fit .424/.485.

## C02 — historical H14 provenance

- Requirement: Manuscript line 580 presents adjusted coefficients without naming reconstructed controls.
- Current behavior and location: config/analysis_plan.json:144; replication/survey.py:177–179 and METHODS explicitly use Q5/Q1/Q6 as a new sensitivity.
- Consequence: The .498/.352 coefficients cannot be certified against an unrecovered historical model; new betas are −.312483 and −.219456.
- Minimal fix: Do not invent controls or replace historical numbers as an exact reproduction; label new sensitivity, with covariates and n, or remove historical coefficients pending recovery.

## C03 — ambiguous H21 family and construct

- Requirement: HYPOTHESES lists formal/static/dynamic/cross-model/interruption (5) but counts H21=4 and total=16.
- Current behavior and location: config/analysis_plan.json:145–227 fixes 16 pairs and Q38_static only at line 214; no combined CI scale is calculated.
- Consequence: Dynamic result omitted from primary family; manuscript CI label .195 is under-specified.
- Minimal fix: Keep frozen executable 16, report dynamic separately and 17-family sensitivity; author must resolve intended family and item. Do not silently change primary family.

## C04 — stale comparison targets

- Requirement: Current TeX is numerical comparison authority.
- Current behavior and location: analysis_pipeline.py:53 reads data/reference/manuscript_targets.json via replication/reporting.py:14–23.
- Consequence: 150 old reference checks include a 133-person experience target absent from current table and omit many current cells. Matching that file is not a current manuscript audit.
- Minimal fix: Preserve old targets as explicitly historical; provide current-TeX reconciliation and input hash. Do not use targets in estimation.

## C05 — figures are not the manuscript figure files

- Requirement: TeX lines 394/423/442/462 require fig_likert.pdf, fig_artifacts.pdf, fig_resilience.pdf, fig_hiring.pdf and a diverging core distribution.
- Current behavior and location: replication/figures.py:31–77 produces five horizontal-rate PNG files, not the named four PDFs or the diverging layout.
- Consequence: One-command claim cannot create the figure assets expected by TeX; original figure binaries were not supplied.
- Minimal fix: Generate named PDF counterparts from the same freshly computed N=200 tables, including diverging distributions and combined resilience panel; preserve original TeX.

## C06 — exact classroom provenance not enforced by local loader

- Requirement: Use only the verified exact v3 98-row analysis data.
- Current behavior and location: replication/classroom.py:56–63 validates N and group counts only, unlike survey fingerprint; scripts/download_data.py verifies exact public MD5 on downloads.
- Consequence: A modified local classroom file with same schema/98/60/38 could pass. This audit used the exact MD5 match and is not affected.
- Minimal fix: Add a frozen semantic fingerprint after classroom cleaning, preserve --allow-data-change as explicit override, and regression-test rejection of modified same-count data.

## C07 — method metadata versus historical certainty

- Requirement: Composites and ordinal coding must be specified, not inferred from a target.
- Current behavior and location: config/analysis_plan.json:91–123; METHODS says complete cases/Q16 rank coding reconstructed; quality_gate/human_ownership reconstructed blocks at 392–403.
- Consequence: Current point estimates are conditional on these declared rules; historical identity and alpha acceptability threshold are not fully specified.
- Minimal fix: Keep reconstruction labels, document full-item rules and Q16 category scores, flag unspecified collaborator composite. Do not tune minimum items.

## C08 — public classroom availability claim

- Requirement: Current TeX lines 900–905 says the exact 98-row release is public.
- Current behavior and location: REPRODUCIBILITY.md says DOI pending; current downloader cannot find exact v3 CSV at proposed record.
- Consequence: Local reproducibility succeeds but public end-to-end acquisition is blocked.
- Minimal fix: Correct availability wording or deposit the exact verified file through the authors’ release process; this audit does not publish respondent data.

## Checks that passed

`replication/io.py:94–106` maps only named ordinal responses; missing labels are not in the numerical mapping. Q32 N/A is NaN, not Never or zero. Scale directions and full normalized headers agree with the questionnaire. Unknown labels fail. `statistics.py:81–93` uses pairwise complete Spearman; composite scoring and alpha are listwise under the explicitly frozen convention. `survey.py:201–224` separates 14-item BH families by split and also labels the global 42-test sensitivity. Holm uses 17 raw midpoint p-values; BH/ Holm occur before export rounding. Q39 excludes exactly the documented five. No inference is run on N=205 as if it were the eligible sample. Raw replay gives identical final tables.

`statistics.py:67–78` preserves undefined planned tests as p=1 slots only for correction bookkeeping, while exporting missing actual results. That is transparent but was incomplete once H19 definitions became available. No manuscript target file is imported by estimation modules; target constants live in reporting/regression fixtures. The original tests check data/estimator outputs, not tune observations. Q22 full header and chart label retain “per accepted change”; no code comment claiming that a negative coefficient proves less total review work was found. H20 non-significance is not converted into independence by the current code or current manuscript discussion.

## Changes authorized after this audit

Implement C01 and C06, add manuscript figure counterparts for C05, and label C04’s retained historical target comparison clearly. Update stale H19 metadata/documentation and version to 1.1.0. Do not decide the C02 historical model, C03 intended primary family, C07 original missing-item rules or C08 public release by guessing. No manuscript/data edits; no overwrite of v1.0 ZIP. Fresh tests and runs recorded separately.
