# v1.1.0 audit changes

Source: v1.0 ZIP at repository commit 9ce6112d3838dd57a242aa80dafe565e32a1c6e6.

H19 item sets activated with declared full-item scoring. Classroom semantic fingerprint added. Primary 16-test family preserved; dynamic and 17-test sensitivity labelled separately. Four manuscript-named PDF figures added. Legacy comparison explicitly labelled historical. Data/TeX untouched; v1.0 ZIP untouched. See adjacent audit reports, full correction ledger and FINAL_VALIDATION.md. Original validation folder retains historical v1.0 outputs, not v1.1 evidence.
