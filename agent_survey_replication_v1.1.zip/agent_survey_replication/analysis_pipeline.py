#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.metadata
import json
import platform
import shutil
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from replication import __version__
from replication import classroom, survey
from replication.io import DataError, load_csv, sha256, write_json
from replication.reporting import comparison, write_report

ROOT = Path(__file__).resolve().parent


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Recompute survey/classroom statistics and audit manuscript values.")
    parser.add_argument("--survey", type=Path, help="Professional survey UTF-8 CSV (205 archived or 230 original rows).")
    parser.add_argument("--classroom", type=Path, help="Classroom v3 UTF-8 CSV (98 cleaned or 103 original rows).")
    parser.add_argument("--out", type=Path, default=Path("results"))
    parser.add_argument("--plan", type=Path, default=ROOT / "config/analysis_plan.json")
    parser.add_argument("--codebook", type=Path, default=ROOT / "config/codebook.json")
    parser.add_argument("--no-figures", action="store_true")
    parser.add_argument("--allow-data-change", action="store_true", help="Explicitly permit data other than the frozen snapshots.")
    parser.add_argument("--fail-on-mismatch", action="store_true", help="Exit 2 when computed values differ from manuscript targets.")
    args = parser.parse_args(argv)
    if args.survey is None and args.classroom is None:
        parser.error("Supply --survey and/or --classroom. See README.md for download and run commands.")
    if args.out.exists():
        parser.error("The output directory already exists. Choose a fresh --out directory; existing files are never overwritten.")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=".replication-", dir=args.out.parent))
    try:
        plan = json.loads(args.plan.read_text(encoding="utf-8"))
        codebook = json.loads(args.codebook.read_text(encoding="utf-8"))
        analyses, metrics, inputs = {}, {}, {}
        for name, path, module in [("survey", args.survey, survey), ("classroom", args.classroom, classroom)]:
            if path is None:
                continue
            if not path.is_file():
                raise DataError(f"Input file not found: {path}")
            frame = load_csv(path)
            inputs[name] = {"name": path.name, "bytes": path.stat().st_size, "sha256": sha256(path)}
            result = module.run(frame, codebook, plan, staging / name, args.allow_data_change)
            analyses[name] = result
            metrics.update(result["metrics"])
        comparisons = comparison(metrics, ROOT / "data/reference/manuscript_targets.json", staging)
        write_report(staging, analyses, comparisons)
        if "survey" in analyses and not args.no_figures:
            from replication.figures import make_survey_figures
            make_survey_figures(staging / "survey", staging / "figures", plan)
        versions = {p: importlib.metadata.version(p) for p in ["numpy", "pandas", "scipy", "statsmodels", "matplotlib"]}
        sources = [ROOT / "analysis_pipeline.py"] + sorted((ROOT / "replication").glob("*.py"))
        manifest = {"software_version": __version__, "utc_timestamp": datetime.now(timezone.utc).isoformat(),
                    "python": platform.python_version(), "platform": platform.platform(), "packages": versions,
                    "inputs": inputs, "code_sha256": {str(p.relative_to(ROOT)): sha256(p) for p in sources},
                    "analysis_plan_sha256": sha256(args.plan), "codebook_sha256": sha256(args.codebook),
                    "manuscript_targets_sha256": sha256(ROOT / "data/reference/manuscript_targets.json"),
                    "allow_data_change": args.allow_data_change,
                    "not_original_author_pipeline": True,
                    "outputs": {str(p.relative_to(staging)): sha256(p) for p in sorted(staging.rglob("*.csv"))}}
        write_json(staging / "run_manifest.json", manifest)
        write_json(staging / "analysis_plan_used.json", plan)
        write_json(staging / "codebook_used.json", codebook)
        staging.rename(args.out)
        count = int(comparisons.status.eq("differs").sum())
        print(f"Results: {args.out.resolve()}")
        print(f"Historical target differences: {count}; see REPORT.md and manuscript_comparison.csv (legacy targets).")
        print("Current v2.6.3 audit is in the accompanying manuscript_statistical_reconciliation.csv; "
              "H19 is now defined. Historical H14 controls and intended H21 family remain unresolved.")
        return 2 if args.fail_on_mismatch and count else 0
    except (DataError, OSError, ValueError, KeyError, TypeError) as exc:
        shutil.rmtree(staging, ignore_errors=True)
        print(f"Analysis failed: {exc}", file=sys.stderr)
        return 1
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise


if __name__ == "__main__":
    raise SystemExit(main())
