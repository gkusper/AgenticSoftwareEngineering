"""Regressions against independently audited respondent-level estimates and input integrity."""
import json
import os
from pathlib import Path
import pandas as pd
import pytest
from replication import classroom, survey
from replication.io import DataError, load_csv

ROOT = Path(__file__).resolve().parents[1]


def test_exact_classroom_identity_rejects_same_count_mutation(tmp_path):
    path = os.environ.get("REPLICATION_CLASSROOM_CSV")
    if not path:
        pytest.skip("Requires the exact optional local classroom release")
    book = json.loads((ROOT / "config/codebook.json").read_text(encoding="utf-8"))
    plan = json.loads((ROOT / "config/analysis_plan.json").read_text(encoding="utf-8"))
    data = load_csv(Path(path))
    column = book["classroom"]["C020"]["header"]
    data.loc[0, column] = "1" if data.loc[0, column] != "1" else "2"
    with pytest.raises(DataError, match="frozen exact v3"):
        classroom.run(data, book, plan, tmp_path / "mutated")


def test_h19_completion_and_family_decision_from_independent_audit(tmp_path):
    path = os.environ.get("REPLICATION_SURVEY_CSV")
    if not path:
        pytest.skip("Requires the optional archived professional release")
    book = json.loads((ROOT / "config/codebook.json").read_text(encoding="utf-8"))
    plan = json.loads((ROOT / "config/analysis_plan.json").read_text(encoding="utf-8"))
    survey.run(load_csv(Path(path)), book, plan, tmp_path)
    result = pd.read_csv(tmp_path / "exploratory_correlations.csv").set_index(["hypothesis", "y"])
    h19 = result.loc["H19"]
    assert h19.loc["traditional_engineering", "n"] == 186
    assert h19.loc["traditional_engineering", "rho"] == pytest.approx(.413735836335703)
    assert h19.loc["ai_literacy", "rho"] == pytest.approx(.482082992229127)
    assert result.loc[("H16", "verification"), "n"] == 124
    assert result.loc[("H16", "verification"), "rho"] == pytest.approx(.398384209772328)
    assert len(result) == 16 and result.p.notna().all()
    assert result.loc[("H21", "Q30"), "q_bh_planned_family"] == pytest.approx(.0485287843877072)
    dynamic = pd.read_csv(tmp_path / "exploratory_17_test_sensitivity.csv")
    assert len(dynamic) == 17 and "Q38_dynamic" in dynamic.y.values
