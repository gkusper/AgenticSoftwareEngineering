# Agent survey statistical replication v1.1.0

An audited independent reconstruction for the supplied current `EMSE_Article_hybrid_v2.6.3.tex`. It is not the unavailable original author pipeline and does not claim that every printed manuscript statistic is correct. Read `audit/STATISTICAL_AUDIT.md`, `audit/H16_AUDIT.md`, `audit/CODE_MANUSCRIPT_MISMATCHES.md` and the complete current-TeX reconciliation CSV.

## Reproduce

Install the pinned packages in requirements-dev.txt (audit executed on Windows, Python 3.12.14). The prior v1.0 validation used Linux/Python3.13.5. Create a virtual environment and run:

```text
python -m pip install -r requirements-dev.txt
python scripts/download_data.py --dataset survey
python analysis_pipeline.py --survey data/raw/survey.csv --classroom /path/to/structured-vibe-coding-v3-cleaned-primary-98.csv --out results/fresh_run
python -m pytest -q
```

For real-data tests set REPLICATION_SURVEY_CSV and REPLICATION_CLASSROOM_CSV to absolute input paths before pytest. Output directories must not exist. The 230-row survey and103-row classroom sources can instead be passed for a cleaning replay; both give the same aggregate results. `--allow-data-change` is an explicit override for non-frozen inputs, not used in the audited runs.

The exact classroom CSV MD5 is c392e1698e3627e991e626f3f762880c. The local v3 data-release ZIP contains this file; the proposed public Zenodo record does not currently expose it. Do not substitute v4/92, and do not treat local availability as confirmed public release. No respondent data are included in this code bundle. The loader validates normalized retained classroom values as well as sample/group counts.

## Changes and scope

H19 uses the recovered five-item traditional-competence and two-item AI-literacy scales. Means require all items. The16 primary Spearman tests now all contribute actual p-values to BH. The contradictory H21 definition is not guessed: executable16 is retained and dynamic Q38 plus the17-test family are separately labelled sensitivity outputs. H14 Q5/Q1/Q6 ordinal-logit is explicitly a reconstructed sensitivity; historical controls remain unknown. Q32 missing/insufficient-experience answers remain missing.

Five original-style PNGs plus the four manuscript-named PDFs and matching PNGs are generated from the same fresh N=200 tables. Copy fig_likert.pdf, fig_artifacts.pdf, fig_hiring.pdf and fig_resilience.pdf from the run's figures directory beside the manuscript when compiling. Original figure binaries were unavailable for direct comparison.

`manuscript_comparison.csv` in a pipeline run remains a **historical150-target comparison**, clearly identified as such. The current435-check audit is `audit/manuscript_statistical_reconciliation.csv`; it is not the old target file relabelled. Never change responses or estimators to hit targets. `validation/` contains preserved historical v1.0 evidence; definitive v1.1 evidence is in `audit/v11_final/` and FINAL_VALIDATION.md.

The original v1.0 ZIP, all input data and the supplied TeX are unchanged. License/publication choices remain with the authors; no repository push or respondent-data publication was performed.
