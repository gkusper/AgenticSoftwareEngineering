"""Audited independent reconstruction, not original author code."""
__version__ = "1.1.0"
