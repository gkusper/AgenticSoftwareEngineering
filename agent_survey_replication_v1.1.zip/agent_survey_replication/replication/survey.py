from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .io import DataError, clean_survey, encode_ordinal, remap_columns, save_table, write_json
from .statistics import (adjust, composite, cronbach_alpha, friedman, group_test, odds_ratio,
                         partial_spearman, proportion, regression, signed_rank, spearman)


def parse_multiple(text: str, choices: list[str]) -> set[str]:
    if not text:
        return set()
    remaining = text
    selected = set()
    # Option labels contain commas, so splitting at every comma would corrupt Q10.
    while remaining:
        found = [x for x in choices if remaining == x or remaining.startswith(x + ", ")]
        if not found:
            raise DataError(f"Unrecognized multi-select option: {remaining!r}")
        choice = max(found, key=len)
        if choice in selected:
            raise DataError("A multi-select option is repeated within one response.")
        selected.add(choice)
        remaining = remaining[len(choice):]
        if remaining:
            remaining = remaining[2:]
    return selected


def run(frame: pd.DataFrame, codebook: dict, config: dict, out: Path,
        allow_change: bool = False) -> dict[str, Any]:
    out.mkdir(parents=True, exist_ok=True)
    plan = config["survey"]
    raw = remap_columns(frame, codebook["survey"])
    data, cleaning, exclusions = clean_survey(raw, plan, allow_change)
    write_json(out / "cleaning.json", cleaning)
    save_table(out, "exclusions", exclusions)
    x = encode_ordinal(data, codebook["survey"], codebook["missing_labels"])
    n = len(data)
    metrics: dict[str, Any] = {"survey_n": n}
    rows = []
    for key in x:
        definition = codebook["survey"][key]
        if definition["scale"] not in {"agreement", "frequency", "importance", "access"}:
            continue
        r = {"item": key, "label": definition["header"]} | proportion(x[key])
        r["missing_n"] = n - r["n"]
        r["disagree_count"] = int(x[key].le(2).sum())
        r["disagree_proportion"] = r["disagree_count"] / r["n"] if r["n"] else np.nan
        for k in range(1, 6):
            r[f"count_{k}"] = int(x[key].eq(k).sum())
        rows.append(r)
        for field in ["n", "count", "proportion", "median", "ci_low", "ci_high"]:
            metrics[f"{key}.{field}"] = r[field]
    descriptions = save_table(out, "item_descriptives", rows)
    midpoint = []
    for key in plan["primary_midpoint_family"]:
        r = {"item": key} | signed_rank(x[key], plan["midpoint"], plan["wilcoxon"])
        midpoint.append(r)
    midpoint = pd.DataFrame(midpoint)
    midpoint["p_holm"] = adjust(midpoint.p, "holm")
    midpoint["sign_p_holm"] = adjust(midpoint.sign_p, "holm")
    save_table(out, "midpoint_tests", midpoint)
    for r in midpoint.to_dict("records"):
        metrics[f"{r['item']}.p_holm"] = r["p_holm"]

    demography = []
    for key in ["Q1", "Q3", "Q4", "Q5", "Q6", "Q8", "Q9", "Q11"]:
        counts = data[key].replace("", "[Missing]").value_counts(sort=False)
        for label, count in counts.items():
            demography.append({"item": key, "category": label, "count": int(count), "denominator": n,
                               "proportion": int(count) / n})
    save_table(out, "demographics", demography)
    role_sets = data.Q2.map(lambda s: parse_multiple(s, codebook["multiple_choice"]["Q2"]))
    senior_roles = set(codebook["multiple_choice"]["Q2"]) - {"Other technical role"}
    metrics.update({"experience_at_least_6_n": int(x.Q1.ge(3).sum()),
                    "experience_at_least_6_proportion": float(x.Q1.ge(3).sum() / n),
                    "senior_role_n": int(role_sets.map(lambda s: bool(s & senior_roles)).sum()),
                    "Q4.missing_n": int(data.Q4.eq("").sum()),
                    "daily_ai_n": int(x.Q5.eq(5).sum()), "weekly_or_daily_ai_n": int(x.Q5.ge(4).sum())})

    summaries = []
    thresholds = [("multiple_agents", "Q16", 2), ("cross_model_used", "Q24", 4),
                  ("cross_model_regular", "Q24", 5), ("provider_interruption_ever", "Q30", 2),
                  ("provider_switched", "Q31", 1), ("provider_switch_difficult", "Q31", 2),
                  ("static_in_ci", "Q38_static", 2), ("static_blocks", "Q38_static", 3),
                  ("dynamic_in_ci", "Q38_dynamic", 2), ("dynamic_blocks", "Q38_dynamic", 3)]
    for name, item, threshold in thresholds:
        r = {"measure": name, "item": item, "threshold": threshold} | proportion(x[item], threshold)
        summaries.append(r)
        metrics[name] = r["proportion"]
    hired = x.Q8.dropna()
    metrics["junior_hiring_reduced"] = float(hired.le(2).mean()) if len(hired) else np.nan
    summaries.append({"measure": "junior_hiring_reduced", "item": "Q8", "n": len(hired),
                      "count": int(hired.le(2).sum()), "proportion": metrics["junior_hiring_reduced"]})
    save_table(out, "categorical_summaries", summaries)

    reduced = data.Q9.str.startswith("Yes,")
    choices = codebook["multiple_choice"]["Q10"]
    workforce = data.loc[reduced, "Q10"].map(lambda s: parse_multiple(s, choices))
    workforce_rows = [{"factor": option, "n": len(workforce),
                       "count": int(workforce.map(lambda s: option in s).sum())} for option in choices]
    for r in workforce_rows:
        r["proportion"] = r["count"] / r["n"] if r["n"] else np.nan
    save_table(out, "workforce_factors", workforce_rows)
    metrics["workforce_reduced_n"] = int(reduced.sum())
    save_table(out, "provider_interruption_counts", [
        {"label": label, "code": code, "count": int(x.Q30.eq(code).sum()), "n": int(x.Q30.notna().sum())}
        for label, code in codebook["survey"]["Q30"]["mapping"].items()])

    reliability = []
    unresolved = []
    for name, definition in plan["scales"].items():
        items = definition["items"]
        if items is None:
            x[name] = np.nan
            unresolved.append({"analysis": name, "reason": definition["status"]})
            reliability.append({"scale": name, "status": "undefined_item_set"})
        else:
            x[name] = composite(x, items, definition["minimum_items"])
            reliability.append({"scale": name, "items": ";".join(items),
                                "n_scored": int(x[name].notna().sum()), "definition_status": definition["status"]}
                               | cronbach_alpha(x[items]))
            metrics[f"{name}.alpha"] = reliability[-1]["alpha"]
    save_table(out, "scale_reliability", reliability)
    repeated = []
    for name, items in [("verification_artifacts", plan["artifact_items"]), ("hiring_priorities", plan["hiring_items"])]:
        result = {"matrix": name} | friedman(x[items])
        repeated.append(result)
        for k in ["n", "statistic", "kendall_w"]:
            metrics[f"{name}.{k}"] = result[k]
    save_table(out, "friedman_tests", repeated)
    hiring_pairs = []
    for item in plan["hiring_items"]:
        if item == "Q36_agents":
            continue
        paired = x[[item, "Q36_agents"]].dropna()
        hiring_pairs.append({"item": item, "comparator": "Q36_agents"}
                            | signed_rank(paired[item] - paired.Q36_agents))
    hiring_pairs = pd.DataFrame(hiring_pairs)
    hiring_pairs["p_holm"] = adjust(hiring_pairs.p, "holm")
    save_table(out, "hiring_pairwise", hiring_pairs)

    pairs = [("H2", "Q21", "Q22"), ("H3", "Q23", "Q19"), ("H3", "Q23", "Q20"),
             ("H4", "Q25", "Q33"), ("H7", "Q32_same", "Q32_human"),
             ("H8", "Q34", "Q35"), ("H11", "Q30", "Q31")]
    correlations = [{"hypothesis": h, "x": a, "y": b} | spearman(x[a], x[b]) for h, a, b in pairs]
    save_table(out, "supplemental_correlations_unadjusted", correlations)
    for r in correlations:
        metrics[f"{r['x']}:{r['y']}.rho"] = r["rho"]
    explorations = []
    for h, a, b in plan["exploratory_pairs"]:
        r = {"hypothesis": h, "x": a, "y": b} | spearman(x[a], x[b])
        if a in [u["analysis"] for u in unresolved] or b in [u["analysis"] for u in unresolved]:
            r["status"] = "not_computed_missing_scale_definition"
        explorations.append(r)
    exploration = pd.DataFrame(explorations)
    exploration["q_bh_planned_family"] = adjust(exploration.p, "fdr_bh")
    exploration["family_size"] = len(exploration)
    save_table(out, "exploratory_correlations", exploration)
    # The frozen 16-test executable family is preserved. HYPOTHESES prose also
    # lists dynamic analysis, making 17 if included; report that choice separately.
    dynamic = {"hypothesis": "H21", "x": "Q6", "y": "Q38_dynamic"} | spearman(x.Q6, x.Q38_dynamic)
    sensitivity17 = pd.concat([exploration.drop(columns=["q_bh_planned_family", "family_size"]),
                               pd.DataFrame([dynamic])], ignore_index=True)
    sensitivity17["q_bh_17_test_sensitivity"] = adjust(sensitivity17.p, "fdr_bh")
    sensitivity17["family_size"] = len(sensitivity17)
    save_table(out, "exploratory_17_test_sensitivity", sensitivity17)
    for r in explorations:
        metrics[f"{r['hypothesis']}.{r['x']}:{r['y']}.rho"] = r["rho"]
    sensitivities = [
        {"hypothesis": h, "x": a, "y": b, "controls": ";".join(plan["partial_controls"])}
        | partial_spearman(x, a, b, plan["partial_controls"])
        for h, a, b in [("H15", "orchestration", "verification"), ("H17", "Q21", "Q34")]]
    save_table(out, "partial_correlations_sensitivity", sensitivities)
    for r in sensitivities:
        metrics[f"{r['hypothesis']}.partial_rho"] = r["rho"]
    models = [regression(x, outcome, "contract", plan["ordinal_logit_controls"], ordinal=True)
              for outcome in ["Q22", "Q23"]]
    save_table(out, "ordinal_logit_sensitivity", models)

    component_h19 = [{"item": item, "comparator": "Q36_evaluate"} | spearman(x[item], x.Q36_evaluate)
                     for item in plan["hiring_items"] if item != "Q36_evaluate"]
    h19 = pd.DataFrame(component_h19)
    h19["q_bh_component_family"] = adjust(h19.p, "fdr_bh")
    save_table(out, "H19_item_level_sensitivity_not_composite_test", h19)

    groups = pd.DataFrame(index=x.index)
    groups["experience"] = x.Q1.map(lambda v: "le10" if v <= 3 else "gt10" if pd.notna(v) else np.nan)
    groups["ai_use"] = x.Q5.map(lambda v: "daily" if v == 5 else "less_than_daily" if pd.notna(v) else np.nan)
    groups["org_size"] = x.Q6.map(lambda v: "le50" if v <= 3 else "51to250" if v == 4 else "gt250" if pd.notna(v) else np.nan)
    split_levels = {"experience": ["le10", "gt10"], "ai_use": ["daily", "less_than_daily"],
                    "org_size": ["le50", "51to250", "gt250"]}
    split_desc, split_tests = [], []
    for split, levels in split_levels.items():
        for item in plan["core_items"]:
            samples = [x.loc[groups[split].eq(level), item] for level in levels]
            split_tests.append({"split": split, "item": item} | group_test(samples))
            for level, sample in zip(levels, samples):
                split_desc.append({"split": split, "level": level, "item": item,
                                   "group_total_n": len(sample)} | proportion(sample))
    tests = pd.DataFrame(split_tests)
    tests["q_bh_within_split"] = tests.groupby("split", sort=False)["p"].transform(lambda s: adjust(s, "fdr_bh"))
    tests["q_bh_global_sensitivity"] = adjust(tests.p, "fdr_bh")
    save_table(out, "subgroup_tests", tests)
    save_table(out, "subgroup_descriptives", split_desc)
    left = x.loc[groups.experience.eq("le10"), "Q37"].dropna()
    right = x.loc[groups.experience.eq("gt10"), "Q37"].dropna()
    a, b = int(left.ge(4).sum()), int(left.lt(4).sum())
    c, d = int(right.ge(4).sum()), int(right.lt(4).sum())
    odds = {"le10_agree": a, "le10_not_agree": b, "gt10_agree": c, "gt10_not_agree": d} | odds_ratio(a, b, c, d)
    save_table(out, "H18_odds_ratio", [odds])
    metrics["H18.odds_ratio"] = odds["or"]
    metrics["H18.odds_ci_low"] = odds["ci_low"]
    metrics["H18.odds_ci_high"] = odds["ci_high"]
    write_json(out / "unresolved_definitions.json", unresolved)
    write_json(out / "metrics.json", metrics)
    return {"metrics": metrics, "cleaning": cleaning, "unresolved": unresolved,
            "tables": {"item_descriptives": descriptions}, "models": models}
