from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .io import save_table


def comparison(metrics: dict[str, Any], reference_file: Path, out: Path) -> pd.DataFrame:
    targets = json.loads(reference_file.read_text(encoding="utf-8"))
    rows = []
    for r in targets:
        computed = metrics.get(r["metric"], np.nan)
        if computed is None or not np.isfinite(computed):
            state = "not_computed"
            difference = np.nan
        else:
            difference = float(computed - r["reported"])
            state = "matches_at_reported_precision" if abs(difference) <= r["tolerance"] else "differs"
        rows.append(r | {"computed": computed, "difference": difference, "status": state})
    return save_table(out, "manuscript_comparison", rows)


def write_report(out: Path, analyses: dict[str, Any], comparisons: pd.DataFrame) -> None:
    lines = ["# Reproduction report", "", "This is an independent reconstruction, not the original analysis script.",
             "The comparison below uses retained HISTORICAL manuscript targets, not a fresh parsing of v2.6.3. "
             "Use the accompanying current-manuscript statistical audit for current claims. H19 is defined in v1.1.",
             "Published values are used only for comparison, never as inputs to estimation.", ""]
    if "survey" in analyses:
        a = analyses["survey"]
        c = a["cleaning"]
        lines += ["## Professional survey", "",
                  f"Input: {c['raw_records']} records; documented duplicate-block removal: {c['documented_block_removed']}; "
                  f"provenance exclusions: {c['provenance_excluded']}; analysed: {c['included']}.",
                  f"Matches the frozen archived questionnaire responses: {c['archived_snapshot_match']}.", "",
                  "The verified 230-row source becomes the public 205-row archive after removing all 25 records "
                  "in the previously identified answer-identical block. Their timestamps are different. "
                  "The current manuscript body says 230; its stale 229-row source comment is not the frozen source.", "",
                  "Midpoint tests: 17-test Holm family. The exact sign tests form a separate 17-test sensitivity family. "
                  "Subgroup BH correction is within each 14-item split; a global 42-test sensitivity is also exported.", "",
                  "Exploratory BH correction retains all 16 explicitly listed comparison slots. "
                  "The recovered H19 scales are now analysed; all 16 raw p-values enter the correction. "
                  "A separately labelled 17-test sensitivity includes dynamic Q38 because the prose family is inconsistent. "
                  "This newly frozen family does not establish what the original exploratory search included.", ""]
    if "classroom" in analyses:
        c = analyses["classroom"]["cleaning"]
        lines += ["## Classroom comparison", "",
                  f"Input: {c['input_records']}; included: {c['included']}; groups: {c['groups']}.",
                  "Invalid CR counts are set to missing only in derived CR variables; participants are not removed for this reason.",
                  "Welch tests and pooled Cohen's d are recomputed from observations. Primary Holm correction contains three outcomes.",
                  "HC3 models use complete cases for the outcome and six baseline covariates; no imputation is used. "
                  "The failed-test count is self-reported and is not a standardized test-failure rate.", ""]
    active = comparisons[comparisons.status.ne("not_computed")]
    mismatches = active[active.status.eq("differs")]
    lines += ["## Manuscript comparison", "",
              f"Computed checks: {len(active)}. Matching at displayed precision: {int(active.status.eq('matches_at_reported_precision').sum())}. "
              f"Different: {len(mismatches)}. Not computed: {int(comparisons.status.eq('not_computed').sum())}.", "",
              "The following are differences, not automatic conclusions that either source is wrong. "
              "Dataset versions and incomplete method definitions must be reconciled by the authors.", "",
              "| Metric | Manuscript | Computed | Location |", "|---|---:|---:|---|"]
    for r in mismatches.to_dict("records"):
        lines.append(f"| `{r['metric']}` | {r['reported']:.8g} | {r['computed']:.8g} | {r['location']} |")
    lines += ["", "## Unresolved scope", "",
              "The original professional analysis code was not available. Complete-case composite scoring, ordinal coding, "
              "the exact test families, and H14 sensitivity covariates are explicitly frozen in config/analysis_plan.json. "
              "The recovered H19 item sets are implemented with explicitly declared complete-item means. "
              "The classroom Quality Gate and human-ownership blocks reproduce the quoted summaries but still require author confirmation. "
              "The AI-as-collaborator composite cannot be reconstructed from an unspecified item set.", "",
              "AIDev is external published reference evidence, not newly mined data. Interviews and causal mechanisms are not computationally reproduced.", "",
              "Non-significant associations do not establish independence, subgroup equivalence, or absence of review. "
              "None of the scripts assigns subjective 'strongly supported' hypothesis labels.", ""]
    model_failures = [m for a in analyses.values() for m in a.get("models", []) if m.get("status") != "ok"]
    if model_failures:
        lines += ["## Model warnings", ""] + [str(m) for m in model_failures]
    (out / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")
