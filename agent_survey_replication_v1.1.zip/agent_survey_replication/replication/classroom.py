from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats

from .io import DataError, numeric_items, remap_columns, save_table, write_json, signature
from .statistics import (adjust, composite, cronbach_alpha, independent_groups,
                         regression, spearman)


def clean_counts(values: pd.Series, maximum: int | None = None) -> pd.Series:
    good = values.notna() & np.isfinite(values) & values.ge(0) & values.eq(np.floor(values))
    if maximum is not None:
        good &= values.le(maximum)
    return values.where(good)


def run(frame: pd.DataFrame, codebook: dict, config: dict, out: Path,
        allow_change: bool = False) -> dict[str, Any]:
    out.mkdir(parents=True, exist_ok=True)
    plan = config["classroom"]
    required = ["C002"] + plan["screen_numeric_items"]
    data = remap_columns(frame, codebook["classroom"], required)
    x = numeric_items(data, plan["screen_numeric_items"], codebook["missing_labels"])
    score_keys = [k for k in x if k not in ["C014", "C015", "C016", "C017", "C018"]]
    ratings = x[score_keys]
    if (((ratings < 1) | (ratings > 5) | ratings.ne(np.floor(ratings))) & ratings.notna()).any().any():
        raise DataError("Classroom ratings must be integers in the documented 1..5 range.")
    answered = x.notna().mean(axis=1)

    def effective_categories(row: pd.Series) -> float:
        counts = row.dropna().value_counts().to_numpy()
        return float(np.exp(stats.entropy(counts))) if len(counts) else 0.0

    entropy = x.apply(effective_categories, axis=1)
    workflow = data.C002.map(plan["workflow_labels"])
    pass_missing = answered.ge(plan["min_numeric_fraction"])
    pass_entropy = entropy.gt(plan["min_exp_entropy"])
    include = pass_missing & pass_entropy & workflow.notna()
    actual_fingerprint = signature(data.loc[include, required].values.tolist())
    expected_fingerprint = plan["primary_semantic_sha256"]
    if not allow_change and actual_fingerprint != expected_fingerprint:
        raise DataError("Classroom responses do not match the frozen exact v3 98-row analysis dataset. "
                        "Matching sample counts alone is insufficient. Use the verified input or "
                        "explicit --allow-data-change for a different snapshot.")
    exclusions = []
    for idx in x.index[~include]:
        reasons = []
        if not pass_missing.loc[idx]:
            reasons.append("numeric_answer_fraction_below_threshold")
        if not pass_entropy.loc[idx]:
            reasons.append("response_entropy_below_threshold")
        if pd.isna(workflow.loc[idx]):
            reasons.append("unknown_workflow")
        exclusions.append({"csv_record": int(idx) + 2, "reason": ";".join(reasons)})
    x, workflow = x.loc[include].copy(), workflow.loc[include]
    counts = workflow.value_counts().to_dict()
    if not allow_change and (len(x) != plan["primary_release_n"] or
                             counts.get("Notebook", 0) != plan["expected_notebook_n"] or
                             counts.get("Unstructured", 0) != plan["expected_unstructured_n"]):
        raise DataError(f"Classroom sample differs from the 98-row v3 release: {counts}. "
                        "The 92-row v4 release is not interchangeable with v3.")
    if len(x) < 2 or len(counts) != 2:
        raise DataError("Both classroom groups must be present.")
    x["notebook"] = workflow.eq("Notebook").astype(float)
    count_specs = {"prompts": ("C014", None), "attempted_crs": ("C015", plan["max_cr"]),
                   "completed_crs": ("C016", plan["max_cr"]),
                   "passed_tests": ("C017", None), "failed_tests": ("C018", None)}
    issues = []
    for name, (key, maximum) in count_specs.items():
        x[name] = clean_counts(x[key], maximum)
        bad = x[key].notna() & x[name].isna()
        for idx in x.index[bad]:
            issues.append({"csv_record": int(idx) + 2, "variable": name,
                           "reported_value": x.at[idx, key], "action": "derived_value_missing_row_retained"})
    x["completed_per_prompt"] = x.completed_crs / x.prompts.where(x.prompts.gt(0))
    tests_total = x.passed_tests + x.failed_tests
    x["test_success_ratio"] = x.passed_tests / tests_total.where(tests_total.gt(0))
    for idx in x.index[x.prompts.eq(0)]:
        issues.append({"csv_record": int(idx) + 2, "variable": "completed_per_prompt",
                       "reported_value": 0, "action": "zero_prompt_denominator_ratio_missing"})
    reliability = []
    for name in ["quality_gate", "human_ownership"]:
        definition = plan[name]
        x[name] = composite(x, definition["items"], definition["minimum_items"])
        reliability.append({"scale": name, "items": ";".join(definition["items"]),
                            "definition_status": definition["status"]}
                           | cronbach_alpha(x[definition["items"]]))
    cleaning = {"input_records": len(data), "included": len(x), "groups": counts,
                "primary_semantic_sha256": actual_fingerprint,
                "archived_snapshot_match": actual_fingerprint == expected_fingerprint,
                "fails_missingness": int((~pass_missing).sum()), "fails_entropy": int((~pass_entropy).sum()),
                "unknown_workflow": int(data.C002.map(plan["workflow_labels"]).isna().sum()),
                "derived_count_or_denominator_issues": len(issues),
                "screening_note": "Numeric columns C005..C143 are frozen for this reconstruction; "
                                  "no missingness/entropy exclusion occurs in either available v3 input.",
                "rows_are_not_removed_for_invalid_cr_counts": True}
    save_table(out, "exclusions", pd.DataFrame(exclusions, columns=["csv_record", "reason"]))
    save_table(out, "count_cleaning", pd.DataFrame(issues, columns=["csv_record", "variable", "reported_value", "action"]))
    save_table(out, "scale_reliability", reliability)
    write_json(out / "cleaning.json", cleaning)
    rows = []
    for outcome in plan["primary_outcomes"]:
        rows.append({"outcome": outcome} | independent_groups(
            x.loc[workflow.eq("Notebook"), outcome], x.loc[workflow.eq("Unstructured"), outcome]))
    primary = pd.DataFrame(rows)
    primary["p_holm"] = adjust(primary.p, "holm")
    primary["mann_whitney_p_holm_sensitivity"] = adjust(primary.mann_whitney_p, "holm")
    save_table(out, "primary_outcomes", primary)
    secondary_names = ["completed_crs", "prompts", "test_success_ratio", "human_ownership",
                       "C045", "C046", "C047", "C048", "C049", "C050", "C089", "C129", "C130", "C131"]
    secondary = []
    for outcome in secondary_names:
        secondary.append({"outcome": outcome, "mean_all": float(x[outcome].mean()),
                          "n_all": int(x[outcome].notna().sum())}
                         | independent_groups(x.loc[workflow.eq("Notebook"), outcome],
                                              x.loc[workflow.eq("Unstructured"), outcome]))
    secondary = pd.DataFrame(secondary)
    secondary["q_bh_new_secondary_family"] = adjust(secondary.p, "fdr_bh")
    save_table(out, "secondary_outcomes", secondary)
    associations = pd.DataFrame([
        {"x": "quality_gate", "y": target} | spearman(x.quality_gate, x[target])
        for target in ["C020", "C021", "test_success_ratio", "failed_tests"]])
    associations["q_bh_sensitivity_family"] = adjust(associations.p, "fdr_bh")
    save_table(out, "quality_gate_associations", associations)
    models = [regression(x, outcome, "notebook", plan["controls"]) for outcome in plan["primary_outcomes"]]
    model_table = pd.DataFrame(models)
    model_table["p_holm_sensitivity_family"] = adjust(model_table.p, "holm")
    save_table(out, "adjusted_primary_HC3", model_table)
    ownership = regression(x, "human_ownership", "notebook", plan["controls"])
    save_table(out, "adjusted_secondary_human_ownership_HC3", [ownership])
    metrics: dict[str, Any] = {"classroom_n": len(x)}
    for r in primary.to_dict("records"):
        for key, value in r.items():
            if isinstance(value, (int, float)):
                metrics[f"classroom.{r['outcome']}.{key}"] = value
    for r in reliability:
        metrics[f"classroom.{r['scale']}.alpha"] = r["alpha"]
    for r in associations.to_dict("records"):
        metrics[f"classroom.quality_gate:{r['y']}.rho"] = r["rho"]
    write_json(out / "metrics.json", metrics)
    return {"metrics": metrics, "cleaning": cleaning, "unresolved": [], "models": models + [ownership]}
