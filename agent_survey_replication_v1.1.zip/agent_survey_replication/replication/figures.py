from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def horizontal_rates(frame: pd.DataFrame, labels: list[str], output: Path, title: str,
                     xlabel: str = "Share of valid responses (%)") -> None:
    if len(frame) == 0:
        return
    fig, ax = plt.subplots(figsize=(10, max(4, 0.43 * len(frame) + 1.5)))
    values = frame.proportion.to_numpy() * 100
    positions = np.arange(len(frame))
    ax.barh(positions, values)
    ax.set_yticks(positions, labels=labels)
    ax.invert_yaxis()
    ax.set_xlim(0, 112)
    for y, value, n in zip(positions, values, frame.n):
        ax.text(value + 1, y, f"{value:.1f}% (n={int(n)})", va="center", fontsize=8)
    ax.set_xlabel(xlabel)
    ax.set_title(title)
    fig.tight_layout()
    fig.savefig(output, dpi=180, bbox_inches="tight")
    plt.close(fig)


def make_survey_figures(folder: Path, output: Path, plan: dict) -> None:
    output.mkdir(parents=True, exist_ok=True)
    frame = pd.read_csv(folder / "item_descriptives.csv").set_index("item")
    label = {
        "Q21": "Code/change volume increased", "Q22": "Senior review/repair per accepted change increased",
        "Q23": "Cross-module tasks need more correction", "Q17": "Specialized agents used",
        "Q18": "Orchestrator agent used", "Q19": "Scope and checks defined in advance",
        "Q26": "AI use/cost tracked", "Q27": "Cheaper agents for low-risk tasks",
        "Q28": "Frontier tools reserved for high-risk tasks", "Q29": "Capability-and-cost routing",
        "Q25": "Independent evidence required", "Q33": "Final responsibility remains human",
        "Q34": "Routine junior work reduced", "Q35": "Junior learning tasks preserved",
        "Q37": "Less confident without AI"}
    items = plan["survey"]["core_items"][:4] + ["Q18"] + plan["survey"]["core_items"][4:]
    horizontal_rates(frame.loc[items], [label[x] for x in items], output / "survey_core.png",
                     "Professional survey: agreement with core items")
    items = plan["survey"]["artifact_items"] + ["Q32_same", "Q32_human"]
    labels = ["Unit tests", "Backend tests", "Frontend tests", "Integration tests", "Pre/postconditions",
              "Runtime assertions", "Formal specifications", "Same AI generates code and tests", "Human reviews AI checks"]
    horizontal_rates(frame.loc[items], labels, output / "verification.png",
                     "AI-generated verification and review", "Often or almost always (% of valid responses)")
    items = plan["survey"]["hiring_items"]
    hiring = frame.loc[items].sort_values("proportion", ascending=False)
    labels = [text.split("[")[-1].rstrip("]") for text in hiring.label]
    horizontal_rates(hiring, labels, output / "hiring_priorities.png", "Junior-hiring priorities",
                     "Very important or essential (% of valid responses)")
    providers = pd.read_csv(folder / "provider_interruption_counts.csv")
    providers["proportion"] = providers["count"] / providers.n
    horizontal_rates(providers, providers.label.tolist(), output / "provider_interruptions.png",
                     "Delays due to AI service or quota limits")
    workforce = pd.read_csv(folder / "workforce_factors.csv")
    workforce = workforce[workforce.factor.isin([
        "Lower demand, revenue pressure, or market conditions", "Organizational restructuring or merger",
        "General cost reduction unrelated to AI", "AI-enabled productivity expectations",
        "Direct automation or replacement of tasks by AI systems"])]
    horizontal_rates(workforce, workforce.factor.tolist(), output / "workforce_factors.png",
                     "Factors reported by respondents with workforce reductions")
    make_manuscript_figures(folder, output, plan, label)


def make_manuscript_figures(folder: Path, output: Path, plan: dict, labels: dict) -> None:
    """Regenerate the exact named TeX assets from this run's aggregate tables."""
    frame = pd.read_csv(folder / "item_descriptives.csv").set_index("item")

    def finish(fig, name):
        fig.savefig(output / f"{name}.pdf", bbox_inches="tight")
        fig.savefig(output / f"{name}.png", dpi=160, bbox_inches="tight")
        plt.close(fig)

    keys = plan["survey"]["core_items"][:4] + ["Q18"] + plan["survey"]["core_items"][4:]
    z = frame.loc[keys]
    fig, ax = plt.subplots(figsize=(13, 8))
    values = z[[f"count_{j}" for j in range(1, 6)]].to_numpy() / z.n.to_numpy()[:, None] * 100
    starts = -values[:, :2].sum(axis=1) - values[:, 2] / 2
    y = np.arange(len(keys))
    colors = ["#963d49", "#d99199", "#d9dee3", "#8cbbc6", "#266678"]
    for j, (color, name) in enumerate(zip(colors, ["Strongly disagree", "Disagree", "Neutral", "Agree", "Strongly agree"])):
        ax.barh(y, values[:, j], left=starts, color=color, label=name, height=.7)
        starts += values[:, j]
    for i, (lo, hi) in enumerate(zip(z.disagree_proportion * 100, z.proportion * 100)):
        ax.text(-108, i, f"{lo:.1f}%", va="center", ha="right", fontsize=9)
        ax.text(108, i, f"{hi:.1f}%", va="center", fontsize=9)
    ax.set_yticks(y, [f"{labels[k]}  (n={int(z.loc[k, 'n'])})" for k in keys], fontsize=9)
    ax.invert_yaxis(); ax.axvline(0, color="#73818c", lw=.6)
    ax.set_xlim(-120, 120); ax.set_xticks([-100, -50, 0, 50, 100], ["100", "50", "0", "50", "100"])
    ax.set_xlabel("Percent of valid responses; neutral split at zero")
    ax.set_title("Professional survey, N=200 | disagreement and agreement", loc="left")
    ax.legend(ncol=3, loc="upper center", bbox_to_anchor=(.5, -.09), frameon=False)
    fig.tight_layout(); finish(fig, "fig_likert")

    def rates(ax, data, names, title):
        pos = np.arange(len(data)); vals = data.proportion.to_numpy() * 100
        ax.barh(pos, vals, color="#266678")
        ax.set_yticks(pos, names, fontsize=9); ax.invert_yaxis(); ax.set_xlim(0, 115)
        for i, (v, n) in enumerate(zip(vals, data.n)):
            ax.text(v + 1, i, f"{v:.1f}% (n={int(n)})", fontsize=8, va="center")
        ax.set_xlabel("Percent of valid responses"); ax.set_title(title, loc="left", fontsize=11)
    keys = plan["survey"]["artifact_items"] + ["Q32_same", "Q32_human"]
    names = ["Unit tests", "Backend tests", "Frontend tests", "Integration tests", "Pre/postconditions",
             "Runtime assertions", "Formal specifications", "Same AI generates code and tests", "Human reviews AI checks"]
    fig, ax = plt.subplots(figsize=(11, 6)); rates(ax, frame.loc[keys], names, "AI-generated artifacts and review | often or almost always")
    fig.tight_layout(); finish(fig, "fig_artifacts")
    z = frame.loc[plan["survey"]["hiring_items"]].sort_values("proportion", ascending=False)
    names = [s.split("[")[-1].rstrip("]") for s in z.label]
    fig, ax = plt.subplots(figsize=(13, 8)); rates(ax, z, names, "Junior hiring priorities | very important or essential")
    fig.tight_layout(); finish(fig, "fig_hiring")
    providers = pd.read_csv(folder / "provider_interruption_counts.csv")
    providers["proportion"] = providers["count"] / providers.n
    workforce = pd.read_csv(folder / "workforce_factors.csv")
    workforce = workforce[workforce.factor.isin(["Lower demand, revenue pressure, or market conditions",
        "Organizational restructuring or merger", "General cost reduction unrelated to AI",
        "AI-enabled productivity expectations", "Direct automation or replacement of tasks by AI systems"])]
    names = ["General non-AI cost reduction", "Market conditions / revenue pressure", "Restructuring / merger",
             "AI productivity expectations", "Direct AI task replacement"]
    fig, axes = plt.subplots(1, 2, figsize=(15, 4.5))
    rates(axes[0], providers, providers.label.tolist(), "Service / quota interruptions | Q30")
    rates(axes[1], workforce, names, "Reported workforce-reduction factors | Q10, n=99")
    fig.tight_layout(w_pad=3); finish(fig, "fig_resilience")
